import React from 'react';
import { shallow, mount, configure,expect, render } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

configure({ adapter: new Adapter() });
global.React = React;
global.expect = expect;
global.mount = mount;
global.render = render;
global.shallow = shallow;
global.commonProps = {
  configs : {
    title: 'title'
  }
};

global.commonState = {
  locale : {
    language : {
      key: 'ko',
      code: '001',
      name: '한국어'
    },
    timezone : {
      code: '186',
      name: 'UTC +9 Korea standard',
      offset: 540
    }
  },
  session : {
    adminUser: {
      email: '',
      userId: '',
      loginId: 'dssysadmin',
      tenantId: 'C60'
    }
  }
}
