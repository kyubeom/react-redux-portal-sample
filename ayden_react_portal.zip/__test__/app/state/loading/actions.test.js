import { loading as Actions } from 'AdminActions';
import { map } from 'lodash';

describe('actions', () => {
  it('should create actions', () => {
    const typeValues = map(Actions, (value, key) => key);
    const expectedActions = [
      Actions.loadingData().type,
      Actions.completeLoading().type,
      Actions.enforceLoadingRemoval().type
    ];
    expect(expectedActions).toEqual(typeValues);
  });
});
