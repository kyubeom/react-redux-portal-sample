import loading from 'redux/reducers/loading'
import { loading as Actions } from 'AdminActions';

describe('reducers', () => {

  let state;

  it('should return the initialState', () => {
    state = loading({}, {});
    expect(state).toHaveProperty('going', false);
  });

  it('should try fetch data', () => {
    state = loading(state, { type: Actions.LOADING_DATA, from: '/test' });
    expect(state).toHaveProperty('going', true);
  });

  it('should completed fetch data', () => {
    state = loading(state, { type: Actions.LOADING_COMPLETED, from: '/test' });
    expect(state).toHaveProperty('going', false);
  });

  it('try fetch A/B data, then complete B fetch', () => {
    state = loading(state, { type: Actions.LOADING_DATA, from: '/a' });
    state = loading(state, { type: Actions.LOADING_DATA, from: '/b' });
    state = loading(state, { type: Actions.LOADING_COMPLETED, from: '/b' });
    expect(state).toHaveProperty('going', true);
  });

  it('try fetch A/B data, then enforce stop loading', () => {
    state = loading(state, { type: Actions.LOADING_DATA, from: '/a' });
    state = loading(state, { type: Actions.LOADING_DATA, from: '/b' });
    state = loading(state, { type: Actions.ENFORCE_REMOVE_LOADING });
    expect(state).toHaveProperty('going', false);
  });
});
