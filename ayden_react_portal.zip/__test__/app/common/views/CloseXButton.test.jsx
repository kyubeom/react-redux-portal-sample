import CloseXButton from 'src/components/atoms/CloseXButton';

describe("<CloseXButton /> UI Component", () => {
   it("renders default close", () => {
       expect(
           mount(<CloseXButton click={ () => {} }/>)
           .find('button.close')
           .length
       ).toBe(1)
   })
});
