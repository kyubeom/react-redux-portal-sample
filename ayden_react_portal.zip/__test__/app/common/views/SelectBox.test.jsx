import SelectBox from 'common/views/SelectBox';

describe("<SelectBox /> UI Component", () => {
  const options = [
    {
      text: 'text1',
      value: 'value1'
    },
    {
      text: 'text2',
      value: 'value2'
    }
  ];
  const defaultValue = 'value1';
  const props = {
    options,
    defaultValue
  };
  const wrapper = mount(<SelectBox {...props} />);

  it('성공적으로 렌더링되어야 합니다.', () => {
    expect(wrapper.length).toBe(1);
  });

  it('전달받은 props이 존재해야합니다.', () => {
    const generatedProps = wrapper.props();
    expect(generatedProps.defaultValue).toBe(defaultValue);
    expect(generatedProps.options.length).toBe(2);
  });

  it('셀렉트박스 옵션이 존재해야합니다.', () => {
    expect(wrapper.find('option').length).toBeGreaterThanOrEqual(1);
  });

  it('디폴트 값이 셋팅되어있어야합니다.', () => {
    expect(wrapper.state().selectedValue).toBe(defaultValue);
  });

  it('값변경이 잘되야합니다.', () => {
    const changed = 'value2';
    const event = { target: { value: changed } };
    wrapper.find('select').simulate('change', event);
    expect(wrapper.state().selectedValue).toBe(changed);
  });

});
