import configureMockStore from 'redux-mock-store';
import { Provider } from 'react-redux';

import PublicLinkHistory from 'components/publicLInkHistory/PublicLinkHistory';
import { StatelessDatePicker } from 'common/views';
import moment from 'common/moment';

describe("<PublicLinkHistory /> Container Component", () => {

  const mockStore = configureMockStore();
  let store = mockStore(commonState);
  let component = null;

  it('renders correctly', () => {
    component = mount(
      <Provider store={store}>
        <PublicLinkHistory {...commonProps} />
      </Provider>
    );
  });

  it('초기 검색 시작일이 요건에 맞게 설정되었는가?', () => {
    const datePickers = component.find(StatelessDatePicker);
    const startDate = datePickers.at(0).props().selected;
    const expected = moment().utc().utcOffset(commonState.locale.timezone.offset).add(-90, 'days').startOf('day');
    expect(startDate.valueOf()).toBe(expected.valueOf());
  });

  it('초기 검색 종료일이 요건에 맞게 설정되었는가?', () => {
    const datePickers = component.find(StatelessDatePicker);
    const endDate = datePickers.at(1).props().selected;
    const expected = moment().utc().utcOffset(commonState.locale.timezone.offset).endOf('day');
    expect(endDate.valueOf()).toBe(expected.valueOf());
  });

  it('초기 로딩이 정상적으로 되었는가?', () => {
    // component.instance().componentDidMount();
    // const state = component.state();
    // console.log('state', state);
    // expect(endDate.valueOf()).toBe(expected.valueOf());
  });


});
