import 'bootstrap/dist/css/bootstrap.css';
import 'jquery';
import 'popper.js/dist/umd/popper';
import 'bootstrap/dist/js/bootstrap';
import { configure } from '@storybook/react';

import '@fortawesome/fontawesome-free/css/all.css';
import 'assets/styles/base.scss';
import 'assets/styles/bootstrap.scss';

// automatically import all files ending in *.stories.js
const req = require.context('./stories', true, /\.stories\.js$/);
function loadStories() {
    req.keys().forEach(filename => req(filename));
}

configure(loadStories, module);
