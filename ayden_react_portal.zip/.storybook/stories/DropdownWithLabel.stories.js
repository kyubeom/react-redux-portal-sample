import { withKnobs } from '@storybook/addon-knobs/react';
import { action } from '@storybook/addon-actions';
import { storiesOf } from '@storybook/react';
import React from 'react';
import DropdownWithLabel from 'molecules/dropdown/DropdownWithLabel';

const dropDownList = [{ key: '', message: '전체' }];

storiesOf('Dropdown', module)
    .addDecorator(withKnobs)
    .add('withLabel', () => <DropdownWithLabel list={dropDownList} selectCode="" onChange={action("change")} />)
;
