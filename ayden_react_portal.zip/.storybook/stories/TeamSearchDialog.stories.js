import { withKnobs } from '@storybook/addon-knobs/react';
import { storiesOf } from '@storybook/react';
import React from 'react';
import { action } from '@storybook/addon-actions';
import { IntlProvider, addLocaleData } from 'react-intl';
import ko from 'react-intl/locale-data/ko';
import resourceKO from 'src/i18n/ko';
import TeamSearch from 'organisms/popup/search/TeamSearch';


addLocaleData([...ko]);

storiesOf('TeamSearch', module)
    .addDecorator(withKnobs)
    .add('basic', () => <IntlProvider locale="ko" messages={resourceKO}><TeamSearch isOpen={true} handleSelect={action('select')} /></IntlProvider>)
    ;
