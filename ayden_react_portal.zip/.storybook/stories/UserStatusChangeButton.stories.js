import { withKnobs } from '@storybook/addon-knobs/react';
import { storiesOf } from '@storybook/react';
import React from 'react';
import { IntlProvider, addLocaleData } from 'react-intl';
import ko from 'react-intl/locale-data/ko';
import resourceKO from 'src/i18n/ko';

addLocaleData([...ko]);

import UserStatusChangeButton from 'organisms/button/UserStatusChangeButton';

storiesOf('UserStatusChangeButton', module)
    .addDecorator(withKnobs)
    .add('basic', () => <IntlProvider locale="ko" messages={resourceKO}><UserStatusChangeButton userIds={['20000000000000001']} tenantId={'10010'} /></IntlProvider>)
    ;
