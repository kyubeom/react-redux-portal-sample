import { withKnobs } from '@storybook/addon-knobs/react';
import { storiesOf } from '@storybook/react';
import React from 'react';

import Table from 'molecules/table/Table.jsx';

const columns = [
    { type: 'checkbox', dataKey: 'checked', onHeaderChange: checked => { console.log('header checked', checked); }, onChange: checked => { console.log('cell checked', checked); }},
    { label: 'Name', dataKey: 'name', width: 70, flexGrow: 0.1 },
    { label: 'Description', dataKey: 'description', flexGrow: 0.9 }
];
const list = [
    { checked: true, name: 'Brian Vaughn1', description: 'Software engineer' },
    { checked: false, name: 'Brian Vaughn2', description: 'Software engineer' },
    { checked: true, name: 'Brian Vaughn3', description: 'Software engineer' },
    { checked: false, name: 'Brian Vaughn4', description: 'Software engineer' },
    { checked: false, name: 'Brian Vaughn5', description: 'Software engineer' }
];

storiesOf('Table', module)
    .addDecorator(withKnobs)
    .add('Basic', () => <Table columns={columns} list={list} />);
