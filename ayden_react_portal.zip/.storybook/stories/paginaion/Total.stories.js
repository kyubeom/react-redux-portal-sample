import { withKnobs } from '@storybook/addon-knobs/react';
import { storiesOf } from '@storybook/react';
import React from 'react';
import { IntlProvider, addLocaleData } from 'react-intl';
import en from 'react-intl/locale-data/en';
import ko from 'react-intl/locale-data/ko';
import zh from 'react-intl/locale-data/zh';
import Total from 'molecules/pagination/Total.jsx';
import resourceKO from 'src/i18n/ko';

addLocaleData([...en, ...ko, ...zh]);

storiesOf('Total', module)
    .addDecorator(withKnobs)
    .add('basic', () => <IntlProvider locale="ko" messages={resourceKO}><Total total={100} /></IntlProvider>)
;
