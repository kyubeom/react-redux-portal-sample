import { withKnobs } from '@storybook/addon-knobs/react';
import { action } from '@storybook/addon-actions';
import { storiesOf } from '@storybook/react';
import React from 'react';
import { IntlProvider, addLocaleData } from 'react-intl';
import en from 'react-intl/locale-data/en';
import ko from 'react-intl/locale-data/ko';
import zh from 'react-intl/locale-data/zh';
import Pagination from 'molecules/pagination/Pagination.jsx';
import PaginationWithContainer from 'molecules/pagination/PaginationWithContainer.jsx';
import resourceKO from 'src/i18n/ko';

addLocaleData([...en, ...ko, ...zh]);

storiesOf('Pagination', module)
    .addDecorator(withKnobs)
    .add('Basic', () => <Pagination totalNum={100} pageLimitNum={5} selectedNum={1} pageActionFunc={action('pageActionFunc')} showingPageSize={10} />)
    .add('WithSummary', () => <IntlProvider locale="ko" messages={resourceKO}><PaginationWithContainer totalNum={100} pageLimitNum={5} selectedNum={1} pageActionFunc={action('pageActionFunc')} showingPageSize={10} /></IntlProvider>)
;
