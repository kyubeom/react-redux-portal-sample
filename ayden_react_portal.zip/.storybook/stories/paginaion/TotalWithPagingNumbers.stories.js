import { withKnobs } from '@storybook/addon-knobs/react';
import { storiesOf } from '@storybook/react';
import React from 'react';
import { IntlProvider, addLocaleData } from 'react-intl';
import ko from 'react-intl/locale-data/ko';
import TotalWithPagingNumbers from 'organisms/TotalWithPagingSize';
import resourceKO from 'src/i18n/ko';

addLocaleData([...ko]);

const change = num => {
    alert(`${num} 으로 바꿔!`);
};

storiesOf('TotalWithPagingNumbers', module)
    .addDecorator(withKnobs)
    .add('basic', () => <IntlProvider locale="ko" messages={resourceKO}><TotalWithPagingNumbers onChange={change} total={20} /></IntlProvider>)
;
