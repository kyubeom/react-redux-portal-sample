import { withKnobs } from '@storybook/addon-knobs/react';
import { storiesOf } from '@storybook/react';
import React from 'react';
import { IntlProvider, addLocaleData } from 'react-intl';
import ko from 'react-intl/locale-data/ko';
import PagingNumbers from 'organisms/dropdown/PagingSize.jsx';
import resourceKO from 'src/i18n/ko';

addLocaleData([...ko]);

const change = num => {
    alert(`${num} 으로 바꿔!`);
};

storiesOf('PagingNumbers', module)
    .addDecorator(withKnobs)
    .add('basic', () => <IntlProvider locale="ko" messages={resourceKO}><PagingNumbers onChange={change} /></IntlProvider>)
;
