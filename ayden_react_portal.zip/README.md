# Admin webapp

Admin Portal React Project

- [Install](#install)
- [Start](#start)
- [Build](#build)
- [Es-lint](#es-lint)
- [Naming Convention](#naming)
- [Folder Structure](#structure)
- [HOC](#hoc)
- [Redux](#redux)
- [Configs by route](#configs-by-route) : 화면별 제공되는 구성정보 (권한/제목..)
- [Shared popup](#shared)


## <a name='Environment'>Environment</a>

    node >= 8 veresion
    npm >= 6 version


## <a name='installation'>Installation</a>

    Using [npm](https://www.npmjs.com/):
    $ npm install
    $ npm config set strict-ssl false
    
## <a name='start'>Start server</a>
    $ npm start

## <a name='build'>Build</a>
mode : development + (es-lint)

    $ npm run dev

mode : production
 
    $ npm run build

## <a name='es-lint'>Es-Lint</a>
    $ npm run lint
    config file : root 경로의 .eslintrc.json
    report path : build 후 dist folder
    file format : eslint-report-xxx.html

## <a name='naming'>Naming Convention</a>

    Folder Naming: Lower case
    File Naming: Pascal Case
    Route URI Naming: kebab case
    
    
## Internationalization

    다국어서비스 : https://182.193.17.35/resource/#/search/W07/SEARCH/
    EFL_ADMIN_WEB 카테고리 화면에서 EXPORT
    다운받은 파일을 압축해제 후, 언어별 압축파일을 다시 해제하고
    해당 폴더를 모두 src>i18n폴더 밑에 복사붙여넣기하여 사용