const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');
const path = require('path');
const LodashModuleReplacementPlugin = require('lodash-webpack-plugin');
const BASE_PATH = path.join(__dirname, '..');
const DIST_PATH = path.join(BASE_PATH, '/dist');
const SRC_PATH = path.join(BASE_PATH, '/src');
const ASSETS_PATH = path.join(BASE_PATH, '/assets');

const EXCEPT_CSS_MODULE_LOADER = [
    path.resolve(SRC_PATH, 'components/molecules/numberInput/NumberInput'),
    path.resolve(SRC_PATH, 'components/molecules/pagination'),
    path.resolve(SRC_PATH, 'components/molecules/category'),
    path.resolve(SRC_PATH, 'components/molecules/table'),
    path.resolve(SRC_PATH, 'components/organisms/header/Gnb'),
    path.resolve(SRC_PATH, 'components/organisms/navigation/Lnb'),
    path.resolve(SRC_PATH, 'components/pages/home/Home'),
    path.resolve(ASSETS_PATH, 'styles')
];

module.exports = {
    mode: 'development',
    entry: {
        app: ['@babel/polyfill', path.join(SRC_PATH, '/index.jsx')]
    },
    output: {
        path: path.join(DIST_PATH),
        filename: '[name].js',
        chunkFilename: '[name].chunk.js',
        publicPath: '/'
    },
    module: {
        noParse: /jquery/,
        rules: [
            {
                test: /\.(jsx|js)$/,
                loader: 'babel-loader',
                include: [SRC_PATH]
            },
            {
                test: /\.(scss|css)$/,
                use: [
                    'style-loader',
                    {
                        loader: 'css-loader',
                        options: {
                            importLoaders: 1,
                            modules: true,
                            localIdentName: '[path][name]__[local]--[hash:base64:5]'
                        }
                    },
                    {
                        loader: 'postcss-loader',
                        options: {
                            plugins: () => [
                                require('autoprefixer')({
                                    browsers: ['> 1%', 'last 2 versions']
                                })
                            ]
                        }
                    },
                    'sass-loader'
                ],
                exclude: [/node_modules/, EXCEPT_CSS_MODULE_LOADER]
            },
            {
                test: /\.(scss|css)$/,
                use: [
                    'style-loader',
                    'css-loader',
                    {
                        loader: 'postcss-loader',
                        options: {
                            plugins: () => [
                                require('autoprefixer')({
                                    browsers: ['> 1%', 'last 2 versions']
                                })
                            ]
                        }
                    },
                    'sass-loader'
                ],
                include: [/node_modules/, EXCEPT_CSS_MODULE_LOADER]
            },
            {
                test: /\.(png|jpg|gif)$/,
                use: {
                    loader: 'url-loader?publicPath=assets/images',
                    options: {
                        limit: 10000,
                        outputPath: 'assets/images',
                        name: '[name]_[hash].[ext]'
                    }
                },
                exclude: /node_modules/
            },
            {
                test: /\.(ttf|eot|svg|woff(2)?)(\?[a-z0-9]+)?$/,
                loader: 'file-loader'
            },
            {
                test: /\.(jsx|js)$/,
                loader: 'eslint-loader',
                exclude: /(node_modules)/,
                options: {
                    eslint: {
                        configFile: './.eslintrc.json',
                        cache: false
                    }
                },
                enforce: 'pre'
            }
        ]
    },
    plugins: [
        new webpack.HotModuleReplacementPlugin(),
        new CleanWebpackPlugin(['dist'], { root: BASE_PATH, verbose: true }),
        new LodashModuleReplacementPlugin({
            paths: true,
            caching: true,
            cloning: true,
            memoizing: true,
            collections: true,
            shorthands: true,
            currying: true
        }),
        new webpack.ContextReplacementPlugin(/moment[\\\/]locale$/, /^\.\/(en|ko|zh-cn)$/),
        new HtmlWebpackPlugin({
            template: path.join(SRC_PATH, '/index.html'),
            favicon: path.join(BASE_PATH, '/assets/favicon.ico'),
            inject: true,
            filename: path.join(DIST_PATH, '/index.html')
        })
    ],
    optimization: {
        splitChunks: {
            chunks: 'all'
        }
    },
    devtool: 'eval-source-map',
    performance: {
        hints: false
    },
    resolve: {
        extensions: ['.js', '.jsx']
    },
    devServer: {
        contentBase: path.join(__dirname, './dist'),
        compress: true,
        port: 9000,
        hotOnly: true,
        historyApiFallback: true,
        proxy: [
            {
                context: ['/auth', '/adm', '/common', '/drive'],
                target: 'https://efl-admin-dev.efss.samsung.net',
                secure: false,
                changeOrigin: true
            }
        ]
    }
};
