const merge = require('webpack-merge');
const common = require('./config.js');

module.exports = merge(common, {
    mode: 'development',
    module: {
        rules:[{
            test: /\.(jsx|js)$/,
            loader: 'eslint-loader',
            exclude: /(node_modules)/,
            options: {
                emitWarning: true,
                eslint: {
                    configFile: './.eslintrc.json',
                    cache: false
                },
                outputReport: {
                    filePath: 'eslint-report-[name].html',
                    formatter: require('eslint/lib/formatters/html')
                }
            },
            enforce: 'pre'
        }]
    }
});
