const path = require('path');
const webpack = require('webpack');
const merge = require('webpack-merge');
const common = require('./config.js');

module.exports = merge(common, {
    mode: 'development',
    devtool: 'inline-source-map',
    module: {
        rules: [
            {
                test: /\.(jsx|js)$/,
                loader: 'eslint-loader',
                exclude: /(node_modules)/,
                options: {
                    eslint: {
                        configFile: './.eslintrc.json',
                        cache: false
                    }
                    // outputReport: {
                    //     filePath: 'eslint-report-[name]-[hash].html',
                    //     formatter: require('eslint/lib/formatters/html')
                    // }
                },
                enforce: 'pre'
            }
        ]
    },
    plugins: [new webpack.HotModuleReplacementPlugin()],
    devServer: {
        contentBase: path.join(__dirname, './dist'),
        compress: true,
        port: 9000,
        hot: true,
        inline: true,
        historyApiFallback: true,
        proxy: [{
            context: ['/auth', '/adm', '/common', '/drive'],
            target: 'https://efl-admin-dev.efss.samsung.net',
            secure: false,
            changeOrigin: true
        }]
    }
});
