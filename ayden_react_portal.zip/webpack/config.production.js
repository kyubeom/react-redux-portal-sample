const webpack = require('webpack');
const merge = require('webpack-merge');
const common = require('./config.js');
const UglifyJSPlugin = require('uglifyjs-webpack-plugin');
const CompressionPlugin = require('compression-webpack-plugin');
const WorkboxPlugin = require('workbox-webpack-plugin');

const publicPath = '/adminweb/';
const mode = 'production';

module.exports = merge(common, {
    output: {
        publicPath: publicPath
    },
    mode: mode,
    devtool: 'source-map',
    plugins: [
        new webpack.EnvironmentPlugin({
            NODE_ENV: mode,
            ROUTER_BASENAME: publicPath
        }),
        new UglifyJSPlugin({ sourceMap: true }),
        new WorkboxPlugin.GenerateSW({
            swDest: 'sw.js',
            clientsClaim: true,
            skipWaiting: true,
            exclude: [/^vendor.*\.js$/, /^app.*\.js$/, /^pages.*\.js$/, /^i18n.*\.js$/, /\.map$/, /index\.html$/]
        }),
        new CompressionPlugin({
            test: /\.(js|css)$/
        })
    ]
});
