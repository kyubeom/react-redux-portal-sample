const merge = require('webpack-merge');
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;
const basic = require('./config.js');

const analyze = {
    mode: 'production',
    plugins: [new BundleAnalyzerPlugin()]
};

module.exports = merge(basic, analyze);