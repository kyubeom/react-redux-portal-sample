import React, { Component } from 'react';
import _ from 'lodash';
import PropTypes from 'prop-types';

class Timer extends Component {
    constructor(props) {
        super(props);

        this.state = {
            renderedTime: '',
            initTimer: false // eslint-disable-line react/no-unused-state
        };
        const { operatingTime } = this.props;
        this.currentLeftSeconds = operatingTime;
    }

    componentDidMount() {
        this.setTimer();
    }

    componentDidUpdate(prevProps) {
        const { operatingTime, forceInitUUID } = this.props;
        if (operatingTime !== prevProps.operatingTime || forceInitUUID !== prevProps.forceInitUUID) {
            this.currentLeftSeconds = operatingTime + 1;
        }
    }

    componentWillUnmount() {
        clearInterval(this.intervalObject);
    }

    setTimer = () => {
        this.intervalObject = setInterval(() => {
            if (this.currentLeftSeconds === 0) {
                this.stopTimer();
                const { whenTimeZeroFunction } = this.props;
                whenTimeZeroFunction();
                return;
            }
            this.currentLeftSeconds = this.currentLeftSeconds - 1;
            this.setState({ renderedTime: Timer.renderTime(this.currentLeftSeconds) });
        }, 1000);
    };

    stopTimer() {
        if (!_.isNil(this.intervalObject)) {
            clearInterval(this.intervalObject);
        }
    }

    static renderTime(leftSeconds) {
        // TODO timeFormat 어떤 게 있는거지....
        let minutes = Math.floor(leftSeconds / 60);
        let seconds = leftSeconds % 60;
        if (minutes < 10) {
            minutes = `0${minutes}`;
        }
        if (seconds < 10) {
            seconds = `0${seconds}`;
        }
        return `${minutes}:${seconds}`;
    }

    render() {
        const { className } = this.props;
        const { renderedTime } = this.state;
        return <span className={className}>{renderedTime}</span>;
    }
}

export default Timer;

Timer.propTypes = {
    operatingTime: PropTypes.oneOfType([PropTypes.number, PropTypes.object]),
    forceInitUUID: PropTypes.string,
    whenTimeZeroFunction: PropTypes.func,
    className: PropTypes.string
};

Timer.defaultProps = {
    operatingTime: 60,
    forceInitUUID: undefined,
    whenTimeZeroFunction: _.noop,
    className: ''
};
