import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames/bind';

import styles from './CloseXButton.scss';

const cx = classNames.bind(styles);

const CloseXButton = props => {
    const { click } = props;
    return (
        <button type="button" className={`close ${cx('close-button')}`} onClick={click}>
            <span aria-hidden="true">×</span>
            <span className="sr-only">Close</span>
        </button>
    );
};

export default CloseXButton;

CloseXButton.propTypes = {
    click: PropTypes.func.isRequired
};
