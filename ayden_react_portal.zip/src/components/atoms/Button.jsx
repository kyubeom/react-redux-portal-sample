import React from 'react';
import { Button as BootstrapButton } from 'reactstrap';
import _ from 'lodash';

const Button = props => {
    const newProps = { ...props };
    const variant = _.get(props, 'variant');
    if (_.isNil(variant)) {
        const className = _.get(newProps, 'className', '');
        newProps.className = `btn btn-default ${className}`;
    }
    return <BootstrapButton {...newProps} />;
};

export default Button;
