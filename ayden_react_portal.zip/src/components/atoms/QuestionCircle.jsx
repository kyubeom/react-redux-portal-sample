import React from 'react';
import PropTypes from 'prop-types';

const QuestionCircle = ({ title }) => <i className="fas fa-question-circle" style={{ cursor: 'pointer' }} title={title} />;

export default QuestionCircle;

QuestionCircle.propTypes = {
    title: PropTypes.string
};

QuestionCircle.defaultProps = {
    title: ''
};
