import _ from 'lodash';
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';

const StyledButton = styled.button`
    border-top-left-radius: 0;
    border-bottom-right-radius: 0;
    width: 30px;
    border-left: 0;
    right: 10%;
    height: 100%;
    padding: 0px;
    margin: 0px;
    cursor: pointer;
    box-shadow: none;
`;

const StyledInput = styled.input`
    cursor: pointer;
    width: ${props => (props.width !== 'auto' ? [props.width, ' !important'].join('') : 'auto')};
    margin-right: 5px;
`;

class DatePickerInputBox extends PureComponent {
    render() {
        const { value, onClick, disabled, className, inputWidth } = this.props;
        return (
            <div className={`input-group date ${className}`} onClick={onClick} role="presentation">
                <StyledInput type="text" className="form-control width-default" value={value} disabled={disabled} onChange={_.noop} width={inputWidth} />
                <div className="input-group-addon">
                    <StyledButton className="btn btn-default" type="button" disabled={disabled}>
                        <i className="fas fa-calendar-alt fa-lg" aria-hidden="true" style={{ verticalAlign: 'middle' }} />
                    </StyledButton>
                </div>
            </div>
        );
    }
}

DatePickerInputBox.propTypes = {
    value: PropTypes.string,
    onClick: PropTypes.func,
    disabled: PropTypes.bool,
    className: PropTypes.string,
    inputWidth: PropTypes.string
};

DatePickerInputBox.defaultProps = {
    value: '',
    onClick: undefined,
    disabled: false,
    className: '',
    inputWidth: 'auto'
};

export default DatePickerInputBox;
