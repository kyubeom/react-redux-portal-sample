import React from 'react';
import styled from 'styled-components';

const VerticalDividerSpan = styled.span`
    content: '';
    display: inline-block;
    background: #ccd1d7;
    height: 34px;
    width: 1px;
`;

const VerticalDivider = props => <VerticalDividerSpan {...props} />;

export default VerticalDivider;
