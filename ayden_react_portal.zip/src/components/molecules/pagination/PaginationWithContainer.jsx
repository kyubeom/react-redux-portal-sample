import React from 'react';
import PropTypes from 'prop-types';

import styled from 'styled-components';
import Pagination from './Pagination';

const CenteringDiv = styled.div`
    display: flex;
    flex-direction: row;
    justify-content: center;

    > div:first-child {
        margin-top: 8px;
    }
`;

const PaginationWithContainer = props => {
    const { totalNum, pageLimitNum, selectedNum, forceAction, pageActionFunc } = props;
    const newProps = {
        totalNum,
        pageLimitNum,
        selectedNum,
        forceAction,
        pageActionFunc
    };

    return (
        <CenteringDiv>
            <Pagination {...newProps} />
        </CenteringDiv>
    );
};

PaginationWithContainer.propTypes = {
    totalNum: PropTypes.number,
    pageLimitNum: PropTypes.number,
    selectedNum: PropTypes.number,
    forceAction: PropTypes.bool,
    pageActionFunc: PropTypes.func
};

PaginationWithContainer.defaultProps = {
    totalNum: 1,
    pageLimitNum: 10,
    selectedNum: 1,
    forceAction: false,
    pageActionFunc: undefined
};

export default PaginationWithContainer;
