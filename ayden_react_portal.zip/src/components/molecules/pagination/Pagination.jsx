import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Pagination as PaginationBootstrap, PaginationItem, PaginationLink } from 'reactstrap';

import './Pagination.scss';

class Pagination extends Component {
    constructor(props) {
        super(props);
        const { forceAction, pageActionFunc } = props;
        this.forceAction = forceAction;
        this.pageActionFunc = pageActionFunc;
        this.pageClickEvent = this.pageClickEvent.bind(this);
        this.pageForwardMoveEvent = this.pageForwardMoveEvent.bind(this);
        this.pageBackworkMoveEvent = this.pageBackworkMoveEvent.bind(this);
    }

    getPageItems() {
        const totalPageCount = this.calculateTotalPageNum();
        const showPage = this.caculateShowPageNum(totalPageCount);

        const { selectedNum } = this.props;
        const items = [];

        items.push(
            <PaginationItem disabled={selectedNum === 1} onClick={() => this.pageBackworkMoveEvent(true)} key="first">
                <PaginationLink first={true} />
            </PaginationItem>
        );
        items.push(
            <PaginationItem disabled={selectedNum === 1} onClick={() => this.pageBackworkMoveEvent()} key="previous">
                <PaginationLink previous={true} />
            </PaginationItem>
        );

        for (let number = showPage.pageShowStartNum; number <= showPage.pageShowLastNum; number += 1) {
            items.push(
                <PaginationItem
                    active={selectedNum === number}
                    onClick={() => {
                        this.pageClickEvent(number);
                    }}
                    key={number}>
                    <PaginationLink>{number}</PaginationLink>
                </PaginationItem>
            );
        }

        items.push(
            <PaginationItem disabled={selectedNum === totalPageCount} onClick={() => this.pageForwardMoveEvent(totalPageCount)} key="next">
                <PaginationLink next={true} />
            </PaginationItem>
        );
        items.push(
            <PaginationItem disabled={selectedNum === totalPageCount} onClick={() => this.pageForwardMoveEvent(totalPageCount, true)} key="last">
                <PaginationLink last={true} />
            </PaginationItem>
        );

        return items;
    }

    pageClickEvent(key) {
        const { selectedNum } = this.props;

        if (selectedNum !== key || this.forceAction) {
            this.pageActionFunc(key);
        }
    }

    pageForwardMoveEvent(totalPageCount, toLast) {
        const { selectedNum } = this.props;

        if (totalPageCount > selectedNum) {
            if (toLast) {
                this.pageActionFunc(totalPageCount);
            } else {
                this.pageActionFunc(selectedNum + 1);
            }
        }
    }

    pageBackworkMoveEvent(toFirst) {
        const { selectedNum } = this.props;

        if (selectedNum > 1) {
            if (toFirst) {
                this.pageActionFunc(1);
            } else {
                this.pageActionFunc(selectedNum - 1);
            }
        }
    }

    calculateTotalPageNum() {
        const { totalNum, pageLimitNum } = this.props;
        const totalPageCount = Math.ceil(totalNum / pageLimitNum);
        // 조회 총수가 아예 없을때에 페이지 1은 보여준다.
        return totalPageCount < 1 ? 1 : totalPageCount;
    }

    caculateShowPageNum(totalPageCount) {
        const { selectedNum, showingPageSize } = this.props;
        const halfPageSize = Math.floor(showingPageSize / 2);
        // 보여지는 페이지 숫자가 총 페이지 수를 넘지 않는다.
        let pageShowStartNum = selectedNum - halfPageSize + 1 < 1 ? 1 : selectedNum - halfPageSize + 1;
        const pageShowLastNum = pageShowStartNum + showingPageSize - 1 > totalPageCount ? totalPageCount : pageShowStartNum + showingPageSize - 1;
        if (pageShowLastNum - pageShowStartNum + 1 < showingPageSize) {
            pageShowStartNum = pageShowLastNum - showingPageSize + 1 < 1 ? 1 : pageShowLastNum - showingPageSize + 1;
        }
        return {
            pageShowStartNum,
            pageShowLastNum
        };
    }

    render() {
        const pageItems = this.getPageItems();
        return <PaginationBootstrap style={{ margin: 0 }}>{pageItems}</PaginationBootstrap>;
    }
}

// totalNum : 페이지 대상 카운트 총 수
// pageLimitNum : 한페이지 당 보여줄 갯수
// selectedNum : 현재 페이지 선택 번호
// forceAction : 같은 page 번호 눌러도 동작할것인가 여부
// pageActionFunc : 페이지 클릭시 동작 함수
Pagination.propTypes = {
    totalNum: PropTypes.number,
    pageLimitNum: PropTypes.number,
    selectedNum: PropTypes.number,
    forceAction: PropTypes.bool,
    pageActionFunc: PropTypes.func,
    showingPageSize: PropTypes.number
};

// selectedNum : 최초 선택 번호 : 1, 버튼클릭시
// Force action : false (같은 page 번호 눌러도 동작할것인가 여부)
Pagination.defaultProps = {
    totalNum: 1,
    pageLimitNum: 10,
    selectedNum: 1,
    forceAction: false,
    pageActionFunc: undefined,
    showingPageSize: 10
};

export default Pagination;
