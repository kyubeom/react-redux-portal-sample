import React from 'react';
import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';

const Total = props => {
    const { total, style } = props;
    return (
        <span style={style}>
            <FormattedMessage id="com.total" />
            &nbsp;
            {total}
        </span>
    );
};

Total.propTypes = {
    total: PropTypes.number,
    style: PropTypes.object
};

Total.defaultProps = {
    total: 0,
    style: {}
};

export default Total;
