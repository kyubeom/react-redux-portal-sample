import { bool, any, func } from 'prop-types';
import React from 'react';
import _ from 'lodash';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { Button, Modal, ModalBody, ModalFooter } from 'reactstrap';
import { globalPopup as actions } from 'actions';

const Alert = props => {
    const { isOpen, message, closeAlert } = props;
    return (
        <Modal isOpen={isOpen} style={{ width: '450px' }} centered autoFocus={false}>
            <ModalBody style={{ minHeight: '80px' }}>{_.isObject(message) ? <FormattedMessage id={message.id} values={message.values} /> : message}</ModalBody>
            <ModalFooter style={{ padding: '10px' }}>
                <Button color="primary" onClick={closeAlert} autoFocus={true}>
                    <FormattedMessage id="com.check" />
                </Button>
            </ModalFooter>
        </Modal>
    );
};

Alert.propTypes = {
    isOpen: bool.isRequired,
    message: any.isRequired,
    closeAlert: func.isRequired
};

const mapStateToProps = state => ({
    isOpen: state.globalPopup.alert.isOpen,
    message: state.globalPopup.alert.message
});

const connected = connect(
    mapStateToProps,
    { closeAlert: actions.closeAlert }
)(Alert);

export default connected;
