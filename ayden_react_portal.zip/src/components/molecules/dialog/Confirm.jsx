import { bool, any, func } from 'prop-types';
import React from 'react';
import _ from 'lodash';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { Button, Modal, ModalBody, ModalFooter } from 'reactstrap';
import { globalPopup as actions } from 'actions';

const Confirm = props => {
    const { isOpen, message, closeConfirm } = props;
    return (
        <Modal isOpen={isOpen} style={{ width: '450px' }} centered>
            <ModalBody style={{ minHeight: '80px' }}>{_.isObject(message) ? <FormattedMessage id={message.id} values={message.value} /> : message}</ModalBody>
            <ModalFooter style={{ padding: '10px' }}>
                <Button outline color="secondary" onClick={() => closeConfirm(false)}>
                    <FormattedMessage id="com.cancel" />
                </Button>
                <Button color="primary" onClick={() => closeConfirm(true)}>
                    <FormattedMessage id="com.check" />
                </Button>
            </ModalFooter>
        </Modal>
    );
};

Confirm.propTypes = {
    isOpen: bool.isRequired,
    message: any.isRequired,
    closeConfirm: func.isRequired
};

const mapStateToProps = state => ({
    isOpen: state.globalPopup.confirm.isOpen,
    message: state.globalPopup.confirm.message
});

const connected = connect(
    mapStateToProps,
    { closeConfirm: actions.closeConfirm }
)(Confirm);

export default connected;
