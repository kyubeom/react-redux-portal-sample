import { bool, any, func } from 'prop-types';
import React from 'react';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { Button, Modal, ModalBody, ModalFooter } from 'reactstrap';
import { error as actions } from 'actions';

const Exception = props => {
    const { isOpen, message, closeErrorAlert } = props;
    return (
        <Modal isOpen={isOpen} style={{ width: '600px', height: '100%' }} centered autoFocus={false}>
            <ModalBody style={{ color: '#800000', fontSize: '20px' }}>
                <i className="fas fa-exclamation-triangle" />
                <br />
                {`  ${message}`}
            </ModalBody>
            <ModalFooter style={{ padding: '10px' }}>
                <Button color="primary" onClick={closeErrorAlert} autoFocus={true}>
                    <FormattedMessage id="com.check" />
                </Button>
            </ModalFooter>
        </Modal>
    );
};

Exception.propTypes = {
    isOpen: bool.isRequired,
    message: any.isRequired,
    closeErrorAlert: func.isRequired
};

const mapStateToProps = state => ({
    isOpen: state.error.isOpen,
    message: state.error.message
});

const connected = connect(
    mapStateToProps,
    { closeErrorAlert: actions.closeErrorAlert }
)(Exception);

export default connected;
