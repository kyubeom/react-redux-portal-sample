import React from 'react';
import PropTypes from 'prop-types';
import { Input } from 'reactstrap';
import _ from 'lodash';

const NOT_PHONE_FORMAT_REG = /[^0-9-+]/g;

const PhoneNumberInput = props => {
    const handleKeyDown = event => {
        const refinedEvent = event;
        refinedEvent.target.value = refinedEvent.target.value.replace(NOT_PHONE_FORMAT_REG, '');
        const { onKeyDown } = props;
        onKeyDown(refinedEvent);
    };

    const handleKeyUp = event => {
        const updated = event;
        updated.target.value = updated.target.value.replace(NOT_PHONE_FORMAT_REG, '');

        const keyCode = event.which || event.keyCode;
        const allowedKey = (keyCode >= 48 && keyCode <= 57) || (keyCode >= 96 && keyCode <= 105) || _.includes([0, 8, 36, 37, 39, 45, 46, 61, 107, 109, 187, 189], keyCode);
        if (allowedKey) {
            const { onKeyUp } = props;
            onKeyUp(updated);
        }
    };

    const omitted = _.omit(props, ['onKeyUp', 'onKeyDown']);
    return <Input onKeyUp={handleKeyUp} onKeyDown={handleKeyDown} {...omitted} style={{ imeMode: 'disabled' }} />;
};

PhoneNumberInput.propTypes = {
    onKeyUp: PropTypes.func,
    onKeyDown: PropTypes.func
};

PhoneNumberInput.defaultProps = {
    onKeyUp: _.noop,
    onKeyDown: _.noop
};

export default PhoneNumberInput;
