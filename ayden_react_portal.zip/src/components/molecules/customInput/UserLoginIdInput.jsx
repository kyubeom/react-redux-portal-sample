import { If } from 'jsx-control-statements';
import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import { FormFeedback, Input } from 'reactstrap';

class UserLoginIdInput extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            value: '',
            valid: false,
            invalid: false
        };
    }

    checkRegexp = value => {
        const { regexpString } = this.props;
        const inputRegexp = new RegExp(regexpString);
        let valid = inputRegexp.test(value);
        const invalid = !valid;
        if (valid && _.isEmpty(value)) {
            valid = false;
        }
        this.setState({ value, valid, invalid });
    };

    handleBlur = event => {
        this.checkRegexp(event.target.value);
        const { onBlur } = this.props;
        onBlur(event);
    };

    handleChange = event => {
        const { type } = this.props;
        if (type === 'select') this.checkRegexp(event.target.value);
        if (_.isEmpty(event.target.value)) this.checkRegexp(event.target.value);
        const { onChange } = this.props;
        onChange(event);
    };

    render() {
        const { value: stateValue } = this.state;
        const { value = stateValue, readOnly, disabled, isIdDupChecked } = this.props;
        const { feedbackMessage } = this.props;
        const toChildProps = _.omit(this.props, ['regexpString', 'feedbackMessage', 'isIdDupChecked']);

        let { valid, invalid } = this.state;
        if (!isIdDupChecked && !_.isEmpty(value)) {
            valid = false;
            invalid = true;
        }
        if (readOnly && !_.isEmpty(value)) {
            valid = true;
            invalid = false;
        }
        if (disabled) {
            valid = false;
            invalid = false;
        }

        return (
            <>
                <Input {...toChildProps} valid={valid} invalid={invalid} onChange={this.handleChange} onBlur={this.handleBlur} />
                <If condition={!_.isEmpty(feedbackMessage)}>
                    <FormFeedback>{feedbackMessage}</FormFeedback>
                </If>
            </>
        );
    }
}

UserLoginIdInput.propTypes = {
    type: PropTypes.string.isRequired,
    innerRef: PropTypes.object,
    regexpString: PropTypes.string,
    feedbackMessage: PropTypes.string,
    value: PropTypes.string,
    onBlur: PropTypes.func,
    onChange: PropTypes.func,
    readOnly: PropTypes.bool,
    disabled: PropTypes.bool,
    isIdDupChecked: PropTypes.bool.isRequired
};

UserLoginIdInput.defaultProps = {
    innerRef: undefined,
    regexpString: '.*', // any at least length 0
    feedbackMessage: '',
    value: undefined,
    onBlur: _.noop,
    onChange: _.noop,
    readOnly: false,
    disabled: false
};

export default UserLoginIdInput;
