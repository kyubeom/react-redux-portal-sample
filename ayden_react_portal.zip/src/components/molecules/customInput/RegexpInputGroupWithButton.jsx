import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { InputGroup, FormFeedback, InputGroupAddon, Button } from 'reactstrap';
import RegexpInput from 'molecules/customInput/RegexpInput';

class RegexpInputGroupWithButton extends React.PureComponent {
    render() {
        const { feedbackMessage, buttonName, onButtonClick } = this.props;
        const inputProps = _.omit(this.props, ['feedbackMessage', 'buttonName', 'onButtonClick']);
        return (
            <>
                <InputGroup>
                    <RegexpInput {...inputProps} />
                    <InputGroupAddon addonType="append">
                        <Button color="secondary" onClick={onButtonClick}>
                            {buttonName}
                        </Button>
                    </InputGroupAddon>
                    {!_.isEmpty(feedbackMessage) && <FormFeedback>{feedbackMessage}</FormFeedback>}
                </InputGroup>
            </>
        );
    }
}

RegexpInputGroupWithButton.propTypes = {
    regexpString: PropTypes.any,
    feedbackMessage: PropTypes.string,
    buttonName: PropTypes.string,
    required: PropTypes.bool,
    onButtonClick: PropTypes.func
};

RegexpInputGroupWithButton.defaultProps = {
    regexpString: '.*', // any at least length 0
    feedbackMessage: '',
    buttonName: undefined,
    required: false,
    onButtonClick: _.noop
};

export default RegexpInputGroupWithButton;
