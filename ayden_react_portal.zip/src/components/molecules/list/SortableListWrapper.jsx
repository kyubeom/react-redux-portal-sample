import React, { Component } from 'react';
import PropTypes from 'prop-types';

import _ from 'lodash';
import { arrayMove as ArrayMove } from 'utils/ArrayMove';
import { SortableContainer, SortableElement, SortableHandle } from 'react-sortable-hoc';
import './sortable.scss';

const Handle = SortableHandle(() => <i className="fas fa-bars" style={{ margin: '0 10px 0 10px', float: 'right', cursor: 'row-resize' }} />);
const SortableItem = SortableElement(({ value }) => {
    return (
        <div style={{ height: '25px', marginLeft: '5px', display: 'flex' }} title={value}>
            <div style={{ width: '500px', textOverflow: 'ellipsis', whiteSpace: 'nowrap', overflow: 'hidden', wordWrap: 'normal' }}>{value}</div>
            <Handle />
        </div>
    );
});

const SortableList = SortableContainer(({ items }) => {
    return (
        <div style={{ margin: '10px 0 0 0' }}>
            {items.map((value, index) => (
                <SortableItem key={value.key} index={index} value={value.value} />
            ))}
        </div>
    );
});

class SortableListWrapper extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isSorting: false,
            items: props.list
        };
    }

    static getDerivedStateFromProps(nextProps, prevState) {
        if (prevState.items !== nextProps.list) {
            return { items: nextProps.list };
        }
        return null;
    }

    onSortEnd = ({ oldIndex, newIndex }) => {
        const { onSortEnd } = this.props;
        const { items } = this.state;
        this.setState({ isSorting: false, items: ArrayMove(items, oldIndex, newIndex) });

        document.body.style.cursor = '';
        onSortEnd(ArrayMove(items, oldIndex, newIndex));
    };

    render() {
        const { isSorting, items } = this.state;
        const props = {
            isSorting,
            items,
            onSortEnd: this.onSortEnd,
            shouldUseDragHandle: true,
            useDragHandle: true
        };
        return <div style={{ height: '250px', width: '500px', overflow: 'auto', borderRadius: 0, border: '1px solid #ced4da' }}>{!_.isEmpty(items) && <SortableList {...props} />}</div>;
    }
}

SortableListWrapper.propTypes = {
    list: PropTypes.array.isRequired,
    onSortStart: PropTypes.func,
    onSortEnd: PropTypes.func
};

SortableListWrapper.defaultProps = {
    onSortStart: _.noop,
    onSortEnd: _.noop
};

export default SortableListWrapper;
