import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import _ from 'lodash';

// NoRows
const NoRows = styled.div`
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1em;
    color: #bdbdbd;
`;
const NoRowsRenderer = () => <NoRows>No data</NoRows>;

// CheckBoxRender
const CheckBoxRender = ({ row, onChange, headerCheckboxRef, list }) => (
    <input
        type="checkbox"
        checked={!!row.cellData}
        onChange={e => {
            const { checked } = e.target;
            onChange({
                checked,
                index: row.rowIndex
            });

            if (_.isObject(_.get(headerCheckboxRef, 'current')) && headerCheckboxRef.current.checked !== checked) {
                headerCheckboxRef.current.checked = checked ? _.every(list, item => item.checked) : false; // eslint-disable-line
            }
        }}
    />
);

CheckBoxRender.propTypes = {
    row: PropTypes.object,
    onChange: PropTypes.func,
    headerCheckboxRef: PropTypes.object.isRequired,
    list: PropTypes.arrayOf(PropTypes.object).isRequired
};

CheckBoxRender.defaultProps = {
    row: {},
    onChange: _.noop
};

// HeaderCheckBoxRender
const HeaderCheckBoxRender = ({ onHeaderChange, ref }) => (
    <input
        type="checkbox"
        ref={ref}
        onChange={e => {
            onHeaderChange(e.target.checked);
        }}
    />
);
HeaderCheckBoxRender.propTypes = {
    onHeaderChange: PropTypes.func,
    ref: PropTypes.any
};
HeaderCheckBoxRender.defaultProps = {
    onHeaderChange: _.noop,
    ref: undefined
};

// export
export { NoRowsRenderer, CheckBoxRender, HeaderCheckBoxRender };
