import React from 'react';
import PropTypes from 'prop-types';
import './table.scss';
import _ from 'lodash';
import uuidV4 from 'uuid/v4';
import { AutoSizer, Column, Table } from 'react-virtualized';
import { CheckBoxRender, HeaderCheckBoxRender, NoRowsRenderer } from './TableRenderer';

const GenerateCheckClassName = ({ list, index }) => (_.get(list, `[${index}].checked`) === true ? 'ReactVirtualized__Table_CheckedRow' : null);

const refineColumn = ({ column, index, list }) => {
    if (index === 0 && column.type === 'checkbox') {
        const refined = column;
        const onChange = _.get(column, 'onChange', _.noop);
        refined.ref = refined.ref || React.createRef(); // eslint-disable-line
        refined.cellRenderer = data => CheckBoxRender({ row: data, onChange, headerCheckboxRef: refined.ref, list });
        refined.headerRenderer = () => HeaderCheckBoxRender(refined);
        return <Column {...refined} key={uuidV4()} readOnly={true} />;
    }
    return <Column {...column} key={column.key || uuidV4()} />;
};

refineColumn.propTypes = {
    column: PropTypes.arrayOf(PropTypes.object).isRequired,
    list: PropTypes.arrayOf(PropTypes.object).isRequired,
    index: PropTypes.number
};

refineColumn.defaultProps = {
    index: 0
};

const DEFAULT_TABLE_OPTIONS = { height: 600, headerHeight: 40, rowHeight: 40, overscanRowCount: 100 };

const AdminTable = props => {
    const { columns, list, tableOptions, onRowDoubleClick } = props;
    const options = Object.assign({}, DEFAULT_TABLE_OPTIONS, tableOptions);
    options.height = _.size(list) < 10 ? 400 : options.rowHeight * _.size(list) + options.headerHeight;
    const noDisplayData = _.get(tableOptions, 'noDisplayData', true);
    return (
        <AutoSizer disableHeight={true}>
            {({ width }) => (
                <Table
                    width={width}
                    rowCount={list.length}
                    rowGetter={({ index }) => list[index]}
                    noRowsRenderer={noDisplayData ? _.noop : NoRowsRenderer}
                    rowClassName={({ index }) => GenerateCheckClassName({ list, index })}
                    onRowDoubleClick={onRowDoubleClick}
                    {...options}>
                    {columns.map((column, index) => refineColumn({ column, index, list }))}
                </Table>
            )}
        </AutoSizer>
    );
};

AdminTable.propTypes = {
    columns: PropTypes.arrayOf(PropTypes.object).isRequired,
    list: PropTypes.arrayOf(PropTypes.object).isRequired,
    tableOptions: PropTypes.object,
    onRowDoubleClick: PropTypes.func
};

AdminTable.defaultProps = {
    tableOptions: { headerHeight: 40, rowHeight: 40 },
    onRowDoubleClick: _.noop
};

export default AdminTable;
