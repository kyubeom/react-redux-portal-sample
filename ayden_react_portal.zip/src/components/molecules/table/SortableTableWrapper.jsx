import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';
import { Column, Table, AutoSizer, defaultTableRowRenderer } from 'react-virtualized';
import { SortableContainer, SortableElement } from 'react-sortable-hoc';

import arrayMove from 'array-move';
import _ from 'lodash';
import uuidV4 from 'uuid/v4';
import { CheckBoxRender, HeaderCheckBoxRender, NoRowsRenderer } from 'molecules/table/TableRenderer';

const DEFAULT_TABLE_OPTIONS = { height: 650, headerHeight: 40, rowHeight: 40 };
const SortableRowRenderer = SortableElement(({ index, ...props }) => {
    return defaultTableRowRenderer({ ...props, index });
});
const SortableTable = SortableContainer(Table, { withRef: true });
const GenerateCheckClassName = ({ columns, list, index }) => (_.get(columns, '[0].type') === 'checkbox' && _.get(list, `[${index}].checked`) === true ? 'ReactVirtualized__Table_CheckedRow' : null);

const refineColumn = ({ column, index, list }) => {
    if (index === 0 && column.type === 'checkbox') {
        const refined = _.cloneDeep(column);
        const onChange = _.get(column, 'onChange', _.noop);
        refined.ref = refined.ref || React.createRef(); // eslint-disable-line
        refined.cellRenderer = data => CheckBoxRender({ row: data, onChange, headerCheckboxRef: refined.ref, list });
        refined.headerRenderer = () => HeaderCheckBoxRender(refined);
        return <Column {...refined} key={uuidV4()} readOnly={true} />;
    }
    return <Column {...column} key={column.key || uuidV4()} />;
};

refineColumn.propTypes = {
    column: PropTypes.arrayOf(PropTypes.object).isRequired,
    list: PropTypes.arrayOf(PropTypes.object).isRequired,
    index: PropTypes.number
};

refineColumn.defaultProps = {
    index: 0
};

class SortableTableWrapper extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isSorting: false
        };
    }

    onSortStart = () => {
        const { onSortStart } = this.props;
        this.setState({ isSorting: true });

        document.body.style.cursor = 'grabbing';

        onSortStart();
    };

    onSortEnd = ({ oldIndex, newIndex }) => {
        const { onSortEnd, list } = this.props;
        this.setState({
            isSorting: false
        });

        document.body.style.cursor = '';

        onSortEnd(arrayMove(list, oldIndex, newIndex));
    };

    render() {
        const { columns, list, tableOptions, onRowDoubleClickCallback } = this.props;
        const { isSorting } = this.state;
        const options = { ...DEFAULT_TABLE_OPTIONS, ...tableOptions };
        const noDisplayData = _.get(tableOptions, 'noDisplayData', false);
        return (
            <AutoSizer disableHeight>
                {({ width }) => (
                    <SortableTable
                        getContainer={wrappedInstance => ReactDOM.findDOMNode(wrappedInstance.Grid)} // eslint-disable-line
                        distance={10}
                        lockAxis="y"
                        width={width}
                        onSortStart={this.onSortStart}
                        onSortEnd={this.onSortEnd}
                        isSorting={isSorting}
                        rowCount={list.length}
                        onRowDoubleClick={({ index }) => onRowDoubleClickCallback(index)}
                        rowGetter={({ index }) => list[index]}
                        rowRenderer={({ index, ...props }) => <SortableRowRenderer index={index} {...props} />}
                        noRowsRenderer={noDisplayData ? _.noop : NoRowsRenderer}
                        rowClassName={({ index }) => GenerateCheckClassName({ columns, list, index })}
                        {...options}>
                        {columns.map((column, index) => refineColumn({ column, index, list }))}
                    </SortableTable>
                )}
            </AutoSizer>
        );
    }
}

SortableTableWrapper.propTypes = {
    columns: PropTypes.arrayOf(PropTypes.object).isRequired,
    list: PropTypes.arrayOf(PropTypes.object).isRequired,
    tableOptions: PropTypes.object,
    onSortEnd: PropTypes.func,
    onSortStart: PropTypes.func,
    onRowDoubleClickCallback: PropTypes.func
};

SortableTableWrapper.defaultProps = {
    tableOptions: { height: 650, headerHeight: 40, rowHeight: 40 },
    onSortEnd: _.noop,
    onSortStart: _.noop,
    onRowDoubleClickCallback: _.noop
};

export default SortableTableWrapper;
