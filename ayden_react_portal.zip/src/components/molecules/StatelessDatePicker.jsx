import { LOCALE_KEY } from 'constants/Locale';
import moment from 'moment';
import PropTypes from 'prop-types';
import React from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { connect } from 'react-redux';
import DatePickerInputBox from '../atoms/DatePickerInputBox';

const StatelessDatePicker = props => {
    const { disabled, onChange, langCode, timezoneDiff, addOffset, minDate, maxDate, selected } = props;
    const handleChange = date => {
        const offset = timezoneDiff;
        const dateWithOffsetOption = addOffset ? moment(date).utcOffset(offset) : date;
        onChange(dateWithOffsetOption);
    };

    return (
        <DatePicker
            customInput={<DatePickerInputBox disabled={disabled} />}
            locale={LOCALE_KEY[langCode]}
            {...props}
            minDate={minDate.toDate()}
            maxDate={maxDate.toDate()}
            selected={selected.toDate()}
            onChange={handleChange}
        />
    );
};

StatelessDatePicker.propTypes = {
    dateFormat: PropTypes.string,
    disabled: PropTypes.bool,
    onChange: PropTypes.func,
    langCode: PropTypes.string,
    timezoneDiff: PropTypes.number,
    addOffset: PropTypes.bool,
    minDate: PropTypes.object,
    maxDate: PropTypes.object,
    selected: PropTypes.object
};

StatelessDatePicker.defaultProps = {
    dateFormat: 'yyyy-MM-dd',
    disabled: false,
    onChange: () => {},
    langCode: '001',
    timezoneDiff: 0,
    addOffset: true,
    minDate: moment(new Date()),
    maxDate: moment(new Date('9999-12-31T00:00:00+0000')),
    selected: moment(new Date())
};

const mapStateToProps = state => ({
    langCode: state.session.locale.langCode,
    timezoneDiff: state.session.locale.timezoneDiff
});

const connected = connect(
    mapStateToProps,
    null
)(StatelessDatePicker);

export default connected;
