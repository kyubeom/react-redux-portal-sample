import React from 'react';
import PropTypes from 'prop-types';

import SearchInputBox from './SearchInputBox';

const divStyle = {
    display: 'flex'
};

const spanStyle = {
    minWidth: '40px',
    fontWeight: 'bold',
    margin: '6px 0 0 0',
    paddingRight: '10px',
    height: '25px'
};

const SearchInputBoxWithLabel = props => {
    const { title, search, onChangeKeyword, minKeyWordLength } = props;
    return (
        <div style={divStyle}>
            <span style={spanStyle}>{title}</span> <SearchInputBox searchActionFunc={search} watchInputKeyword={onChangeKeyword} minKeyWordLength={minKeyWordLength} />
        </div>
    );
};

export default SearchInputBoxWithLabel;

SearchInputBoxWithLabel.propTypes = {
    title: PropTypes.string.isRequired,
    search: PropTypes.func.isRequired,
    onChangeKeyword: PropTypes.func,
    minKeyWordLength: PropTypes.number
};

SearchInputBoxWithLabel.defaultProps = {
    minKeyWordLength: 2,
    onChangeKeyword: f => f
};
