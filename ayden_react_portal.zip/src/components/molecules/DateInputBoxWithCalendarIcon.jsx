import React from 'react';
import _ from 'lodash';
import PropTypes from 'prop-types';
import { InputGroup, Input, InputGroupAddon, Button } from 'reactstrap';

// can not use stateless-function (ref error)
// eslint-disable-next-line react/prefer-stateless-function
class DateInputBoxWithCalendarIcon extends React.Component {
    render() {
        const { value, onClick } = this.props;
        return (
            <InputGroup>
                <Input type="text" style={{ cursor: 'pointer', width: '100px' }} value={value} disabled={true} />
                <InputGroupAddon addonType="append">
                    <Button onClick={onClick} style={{ zIndex: 0 }}>
                        <i className="fas fa-calendar-alt" aria-hidden="true" />
                    </Button>
                </InputGroupAddon>
            </InputGroup>
        );
    }
}

DateInputBoxWithCalendarIcon.propTypes = {
    value: PropTypes.any,
    onClick: PropTypes.func
};

DateInputBoxWithCalendarIcon.defaultProps = {
    value: '',
    onClick: _.noop
};

export default DateInputBoxWithCalendarIcon;
