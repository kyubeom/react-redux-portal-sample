import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Button, Input, InputGroup, InputGroupAddon } from 'reactstrap';
import { injectIntl } from 'react-intl';
import { withDialog } from '../hocs/index';

class SearchInputBox extends Component {
    constructor(props) {
        super(props);
        this.searchKeyword = '';

        const { watchInputKeyword, minKeyWordLength, searchActionFunc, styles, maxLength, dialog } = props;
        this.watchInputKeyword = watchInputKeyword;
        this.minKeyWordLength = minKeyWordLength;
        this.searchActionFunc = searchActionFunc;
        this.styles = styles;
        this.maxLength = maxLength;
        this.dialog = dialog;

        this.inputOnChange = this.inputOnChange.bind(this);
        this.inputKeyDownEvent = this.inputKeyDownEvent.bind(this);
        this.doSearchEvent = this.doSearchEvent.bind(this);
    }

    shouldComponentUpdate(nextProps) {
        const { searchActionFunc, styles } = nextProps;
        if (searchActionFunc !== this.searchActionFunc) {
            return true;
        }

        if (styles !== this.styles) {
            return true;
        }

        return false;
    }

    inputOnChange(e) {
        this.searchKeyword = e.target.value;

        if (typeof this.watchInputKeyword === 'function') {
            this.watchInputKeyword(this.searchKeyword);
        }
    }

    inputKeyDownEvent(e) {
        if (e.keyCode === 13) this.doSearchEvent();
    }

    doSearchEvent() {
        const { intl } = this.props;
        if (this.searchKeyword.length < this.minKeyWordLength) {
            this.dialog.alert(intl.formatMessage({ id: 'views.searchInputBox.shortKeyword' }));
        } else {
            this.searchActionFunc(this.searchKeyword);
        }
    }

    render() {
        const { containerStyles } = this.props;
        return (
            <div style={containerStyles}>
                <InputGroup>
                    <Input type="text" style={this.styles} maxLength={this.maxLength} onChange={e => this.inputOnChange(e)} onKeyUp={e => this.inputKeyDownEvent(e)} />
                    <InputGroupAddon addonType="append">
                        <Button color="secondary" onClick={this.doSearchEvent}>
                            <i className="fas fa-search fa-lg search_icon" aria-hidden="true" />
                        </Button>
                    </InputGroupAddon>
                </InputGroup>
            </div>
        );
    }
}

// searchActionFunc : 찾기 동작시 수행할 함수 (키워드값을 파라미터로 받는다.)
SearchInputBox.propTypes = {
    searchActionFunc: PropTypes.func.isRequired,
    minKeyWordLength: PropTypes.number,
    styles: PropTypes.object,
    containerStyles: PropTypes.object,
    maxLength: PropTypes.number,
    watchInputKeyword: PropTypes.func
};

// maxLength : input 값 최대 크기
// input style Object
// minKeyWordLength : 최소 검색 입력 글자 수
SearchInputBox.defaultProps = {
    maxLength: 100,
    styles: { width: 'auto' },
    containerStyles: {},
    minKeyWordLength: 2,
    watchInputKeyword: undefined
};

export default withDialog(injectIntl(SearchInputBox));
