import React from 'react';
import PropTypes from 'prop-types';

import styles from './spinner.scss';

const Spinner = props => {
    const { isLoading } = props;
    if (isLoading) {
        return (
            <div className={styles['spinner-dim']}>
                <div className={styles['lds-spinner']}>
                    <div />
                    <div />
                    <div />
                    <div />
                    <div />
                    <div />
                    <div />
                    <div />
                    <div />
                    <div />
                    <div />
                    <div />
                </div>
            </div>
        );
    }
    return <React.Fragment />;
};

Spinner.propTypes = {
    isLoading: PropTypes.bool
};
Spinner.defaultProps = {
    isLoading: false
};

export default Spinner;
