import React from 'react';
import PropTypes from 'prop-types';
import './NumberInput.scss';

class NumberInput extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            value: props.value
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleBlur = this.handleBlur.bind(this);
        this.increment = this.increment.bind(this);
        this.decrement = this.decrement.bind(this);
    }

    static getDerivedStateFromProps(nextProps, prevState) {
        if (prevState.value !== nextProps.value) {
            return { value: nextProps.value };
        }
        return null;
    }

    /**
     * 값의 변경을 처리하는 함수
     * @param event
     * @param event
     */
    handleChange(event) {
        const { onChange } = this.props;

        // value 정리
        const value = Number(event.target.value);
        if (Number.isNaN(value) || Math.abs(value) > 2 ** 53) return;

        // setState 적용
        this.setState({
            value
        });

        // 전달받은 callback 실행
        onChange(event.target.value);
    }

    /**
     * Focus blur를 처리하는 함수
     */
    handleBlur() {
        const { onChange, min, max } = this.props;
        const { value } = this.state;

        let nextValue = Number(value);
        if (nextValue < Number(min)) nextValue = Number(min);
        else if (nextValue > Number(max)) nextValue = Number(max);

        if (nextValue === Number(value)) return;

        this.setState({
            value: nextValue
        });

        onChange(nextValue);
    }

    increment() {
        const { readonly, onChange, min, max, chgUnit } = this.props;
        const { value } = this.state;

        // 읽기 전용인 경우 아무것도 하지 않음
        if (readonly) return;

        // 최대 최소값의 범위를 초과한 경우
        let nextValue = Number(value) + Number(chgUnit);
        if (nextValue < Number(min)) nextValue = min;
        else if (nextValue > Number(max)) nextValue = max;

        this.setState({
            value: nextValue || 0
        });

        onChange(nextValue);
    }

    decrement() {
        const { readonly, onChange, min, max, chgUnit } = this.props;
        const { value } = this.state;

        // 읽기 전용인 경우 아무것도 하지 않음
        if (readonly) return;

        // 최대 최소값의 범위를 초과한 경우
        let nextValue = Number(value) - Number(chgUnit);
        if (nextValue < Number(min)) nextValue = min;
        else if (nextValue > Number(max)) nextValue = max;

        this.setState({
            value: nextValue || 0
        });

        onChange(nextValue);
    }

    render() {
        const { readonly, error, className } = this.props;
        const { value } = this.state;

        return (
            <div className={`numberInputWrap${error ? ' error' : ''} ${className}`}>
                <div className="btnWrap">
                    <button type="button" onClick={this.increment}>
                        <i className="fas fa-chevron-up" />
                    </button>
                    <button type="button" onClick={this.decrement}>
                        <i className="fas fa-chevron-down" />
                    </button>
                </div>
                <div className="inputWrap">
                    <input type="text" value={value} onChange={this.handleChange} onBlur={this.handleBlur} readOnly={readonly} />
                </div>
            </div>
        );
    }
}

/**
 * propTypes 설정
 */
NumberInput.propTypes = {
    value: PropTypes.any,
    min: PropTypes.any,
    max: PropTypes.any,
    chgUnit: PropTypes.any,
    readonly: PropTypes.bool,
    error: PropTypes.bool,
    onChange: PropTypes.func,
    className: PropTypes.any
};

/**
 * props 기본값 설정
 */
NumberInput.defaultProps = {
    value: 0,
    min: -Infinity,
    max: Infinity,
    chgUnit: 1,
    readonly: false,
    error: false,
    onChange: () => {},
    className: ''
};

export default NumberInput;
