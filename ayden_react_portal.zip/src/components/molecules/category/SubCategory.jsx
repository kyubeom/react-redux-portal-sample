import React from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import { ListGroupItem } from 'reactstrap';
import { FormattedMessage } from 'react-intl';
import './SubCategory.scss';

const SubCategory = props => {
    const { subCategory, selectSubCategory, location } = props;
    const selected = location.pathname === subCategory.url;
    const listGroupItemClass = `sub-category ${selected ? 'selected list-group-item' : 'list-group-item'}`;
    return (
        <ListGroupItem className={listGroupItemClass} key={subCategory.id} onClick={() => selectSubCategory(subCategory)}>
            <p className="text" id={subCategory.url.substr(1)}>
                <FormattedMessage id={subCategory.title || 'empty id'} />
            </p>
        </ListGroupItem>
    );
};

SubCategory.propTypes = {
    subCategory: PropTypes.object.isRequired,
    selectSubCategory: PropTypes.func.isRequired,
    location: PropTypes.object.isRequired
};

export default withRouter(SubCategory);
