import React from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import { ListGroup } from 'reactstrap';
import { find, size, isNil, isEmpty } from 'lodash';
import { FormattedMessage } from 'react-intl';

import './Category.scss';
import SubCategory from './SubCategory';

const Category = props => {
    const { category, clickCategory, selectSubCategory, selectedCategoryId, location } = props;
    const lnbCategoryIcon = `${category.css} whiteImage`;

    const path = location.pathname;
    const isCurrentCategoryByRoute = !!find(category.child, item => item.url === path);

    const isSelected = selectedCategoryId === category.id;
    const isFirstAccess = isNil(selectedCategoryId);
    const unfold = isFirstAccess ? isCurrentCategoryByRoute : isSelected;
    const height = unfold ? size(category.child) * 35 : 0;
    const categoryStyle = {
        height: `${height}px`
    };

    const activeClass = (isFirstAccess && isCurrentCategoryByRoute) || isSelected ? 'active' : '';
    return (
        <div className="category" key={category.id || category.title}>
            <div className={activeClass} onClick={() => clickCategory(category.id)} role="menuitem" tabIndex={category.index}>
                <div className={lnbCategoryIcon} aria-hidden="true" />
                <div className="fas fa-sort-down whiteImage rightAsign" aria-hidden="true" />
                <div className="text">
                    <FormattedMessage id={category.title} />
                </div>
            </div>

            <ListGroup className={`sub-category-group list-group ${activeClass}`} style={categoryStyle}>
                {!isEmpty(category) &&
                    !isEmpty(category.child) &&
                    category.child.map(subCategory => <SubCategory key={subCategory.id} subCategory={subCategory} selectSubCategory={selectSubCategory} />)}
            </ListGroup>
        </div>
    );
};

Category.propTypes = {
    clickCategory: PropTypes.func.isRequired,
    selectSubCategory: PropTypes.func.isRequired,
    category: PropTypes.object.isRequired,
    selectedCategoryId: PropTypes.string,
    location: PropTypes.object.isRequired
};

Category.defaultProps = {
    selectedCategoryId: null
};

export default withRouter(Category);
