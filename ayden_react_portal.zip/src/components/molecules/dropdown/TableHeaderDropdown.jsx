import React from 'react';
import PropTypes from 'prop-types';
import { injectIntl } from 'react-intl';
import Dropdown from 'molecules/dropdown/Dropdown';

const TableHeaderDropdown = props => {
    const { dropdownSize, list, selectCode, onChange, defaultMessage, dropdownMenuModifiers, disabled, intl } = props;
    const title = defaultMessage || intl.formatMessage({ id: 'com.all' });
    return (
        <Dropdown
            list={list}
            defaultMessage={title}
            dropdownSize={dropdownSize}
            selectCode={selectCode}
            onChange={onChange}
            dropdownStyles={{ height: '25px', position: 'inherit', maxWidth: '80px' }}
            dropdownToggleStyles={{ fontSize: '11px', lineHeight: '2px' }}
            dropdownMenuModifiers={dropdownMenuModifiers}
            disabled={disabled}
        />
    );
};

TableHeaderDropdown.propTypes = {
    list: PropTypes.array,
    selectCode: PropTypes.any,
    onChange: PropTypes.func,
    dropdownSize: PropTypes.string,
    defaultMessage: PropTypes.string,
    dropdownMenuModifiers: PropTypes.object,
    disabled: PropTypes.bool
};

TableHeaderDropdown.defaultProps = {
    list: [],
    selectCode: undefined,
    dropdownSize: 'sm',
    onChange: () => {},
    defaultMessage: undefined,
    dropdownMenuModifiers: {},
    disabled: false
};

export default injectIntl(TableHeaderDropdown);
