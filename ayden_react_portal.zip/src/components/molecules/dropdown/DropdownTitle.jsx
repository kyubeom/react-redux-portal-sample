import React from 'react';
import _ from 'lodash';

const ELLIPSIS_STYLE = {
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    wordWrap: 'normal'
};

const DropdownTitle = ({ children, style }) => {
    if (_.includes(style, 'flex')) {
        return <div style={ELLIPSIS_STYLE}>{children}</div>;
    }

    return children;
};

export default DropdownTitle;
