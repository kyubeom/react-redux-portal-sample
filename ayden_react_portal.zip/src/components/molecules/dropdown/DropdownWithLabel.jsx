import React from 'react';
import PropTypes from 'prop-types';

import Dropdown from 'molecules/dropdown/Dropdown';

const DropdownWithLabel = props => {
    const { dropdownSize, columnSize, label, list, selectCode, onChange, containerStyles, defaultMessage, isVertical, dropdownStyles } = props;
    const divClassname = `col_${columnSize}`;

    return (
        <div className={divClassname} style={containerStyles}>
            {isVertical ? <div>{label}</div> : <span style={{ paddingRight: '7px' }}>{label}</span>}
            <Dropdown id={`dropdown-size-${dropdownSize}`} list={list} selectCode={selectCode} onSelect={event => onChange(event)} dropdownStyles={dropdownStyles} defaultMessage={defaultMessage} />
        </div>
    );
};

DropdownWithLabel.propTypes = {
    list: PropTypes.array.isRequired,
    selectCode: PropTypes.string,
    onChange: PropTypes.func,
    label: PropTypes.string,
    columnSize: PropTypes.number,
    dropdownSize: PropTypes.string,
    containerStyles: PropTypes.object,
    dropdownStyles: PropTypes.object,
    defaultMessage: PropTypes.string,
    isVertical: PropTypes.bool
};

DropdownWithLabel.defaultProps = {
    selectCode: '',
    label: '',
    columnSize: 25,
    dropdownSize: 'sm',
    onChange: () => {},
    containerStyles: {},
    dropdownStyles: {},
    defaultMessage: 'All',
    isVertical: false
};

export default DropdownWithLabel;
