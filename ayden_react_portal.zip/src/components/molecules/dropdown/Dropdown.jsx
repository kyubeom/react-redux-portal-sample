import React, { useEffect, useState } from 'react';
import _ from 'lodash';
import PropTypes from 'prop-types';
import { DropdownItem, DropdownMenu, DropdownToggle, UncontrolledButtonDropdown } from 'reactstrap';
import DropdownTitle from 'molecules/dropdown/DropdownTitle';

const ELLIPSIS_STYLE = {
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    wordWrap: 'normal'
};

const Dropdown = props => {
    const { dropdownSize, list, selectCode, onChange, defaultMessage, dropdownStyles, dropdownToggleStyles, dropdownMenuModifiers, disabled } = props;
    const [title, setTitle] = useState(defaultMessage);
    useEffect(() => {
        const selectedItem = _.find(list, l => l.key === selectCode);
        setTitle(_.get(selectedItem, 'message', defaultMessage));
    }, [selectCode, list, defaultMessage]);
    const toggleStyle = _.assignIn({ display: 'inline-block' }, dropdownToggleStyles);
    let itemStyle;
    if (_.has(dropdownToggleStyles, 'maxWidth')) {
        itemStyle = _.clone(ELLIPSIS_STYLE);
        itemStyle.maxWidth = dropdownToggleStyles.maxWidth;
    }

    return (
        <UncontrolledButtonDropdown id={`dropdown-size-${dropdownSize}`} title={title} onSelect={event => onChange(event)} style={dropdownStyles}>
            <DropdownToggle caret={!disabled} style={toggleStyle} disabled={disabled}>
                <DropdownTitle style={toggleStyle}>{title}</DropdownTitle>
            </DropdownToggle>
            <DropdownMenu modifiers={dropdownMenuModifiers}>
                {list.map(item => {
                    return (
                        <DropdownItem key={`${item.key} ${item.message}`} onClick={() => onChange(item.key)} style={itemStyle} title={item.message}>
                            {_.isEmpty(item.message) ? item.key : item.message}
                        </DropdownItem>
                    );
                })}
            </DropdownMenu>
        </UncontrolledButtonDropdown>
    );
};

Dropdown.propTypes = {
    list: PropTypes.array,
    selectCode: PropTypes.any,
    onChange: PropTypes.func,
    dropdownSize: PropTypes.string,
    dropdownStyles: PropTypes.object,
    defaultMessage: PropTypes.string,
    dropdownToggleStyles: PropTypes.object,
    dropdownMenuModifiers: PropTypes.object,
    disabled: PropTypes.bool
};

Dropdown.defaultProps = {
    list: [],
    selectCode: undefined,
    dropdownSize: 'sm',
    onChange: () => {},
    dropdownStyles: {},
    defaultMessage: 'All',
    dropdownToggleStyles: {},
    dropdownMenuModifiers: {},
    disabled: false
};

export default Dropdown;
