import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import DatePicker from 'react-datepicker';
import moment from 'moment';

import DateInputBoxWithCalendarIcon from 'molecules/DateInputBoxWithCalendarIcon';

const WrappedDatePicker = props => {
    const { selected, onChange, dateFormat, maxDate, disabled } = props;
    return <DatePicker selected={selected} dateFormat={dateFormat} maxDate={maxDate} onChange={onChange} customInput={<DateInputBoxWithCalendarIcon />} disabled={disabled} />;
};

WrappedDatePicker.propTypes = {
    selected: PropTypes.any,
    onChange: PropTypes.func,
    dateFormat: PropTypes.string,
    maxDate: PropTypes.object,
    disabled: PropTypes.bool
};

WrappedDatePicker.defaultProps = {
    selected: new Date(),
    onChange: _.noop,
    dateFormat: 'yyyy-MM-dd',
    maxDate: moment(new Date('9999-12-31T00:00:00+0000')),
    disabled: false
};

export default WrappedDatePicker;
