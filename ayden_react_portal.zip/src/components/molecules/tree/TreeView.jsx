import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Treebeard } from 'react-treebeard';
// https://github.com/TimothyRHuertas/react-treebeard/blob/master/example/app.js

import Decorators from './Decorators';
import TreeTheme from './TreeTheme';

class TreeView extends Component {
    constructor(props) {
        super(props);
        this.state = {
            cursor: null
        };
        this.nodeNameClick = false;
    }

    onToggle = (node, toggled) => {
        const { cursor } = this.state;
        if (cursor) {
            cursor.active = false;
        }
        const selected = node;
        if (selected.children && !this.nodeNameClick) {
            selected.toggled = toggled;
        }
        selected.active = true;
        this.setState({ cursor: selected });
        this.nodeNameClick = false;

        const { onSelect } = this.props;
        onSelect(node);
    };

    onClickNodeName = node => {
        this.nodeNameClick = true;
        const { onSelect } = this.props;
        onSelect(node);
    };

    render() {
        const { treeData } = this.props;
        return <Treebeard data={treeData} onToggle={this.onToggle} style={TreeTheme} decorators={Decorators(this.onClickNodeName)} />;
    }
}

export default TreeView;

TreeView.propTypes = {
    treeData: PropTypes.array.isRequired,
    onSelect: PropTypes.func
};

TreeView.defaultProps = {
    onSelect: f => f
};
