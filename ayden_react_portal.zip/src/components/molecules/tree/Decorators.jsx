import React from 'react';
import PropTypes from 'prop-types';
import { decorators } from 'react-treebeard';

const modifiedDecorators = onClickNodeName => {
    const Header = ({ node, style }) => (
        <div role="button" style={style.base} onClick={e => onClickNodeName(node, e)}>
            <div style={style.title}>{node.name}</div>
        </div>
    );

    Header.propTypes = {
        style: PropTypes.object.isRequired,
        node: PropTypes.object.isRequired
    };

    return Object.assign({}, decorators, { Header });
};

export default modifiedDecorators;
