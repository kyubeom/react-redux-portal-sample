import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { isNil, isEmpty, size, get } from 'lodash';
import TreeView from './TreeView';

let prevKeyword = '';

const defaultMatcher = (filterText, node) => !isNil(node.name) && node.name.toLowerCase().indexOf(filterText.toLowerCase()) !== -1;

const findNode = (node, filter, matcher) => matcher(filter, node) || (node.children && node.children.length && !!node.children.find(child => findNode(child, filter, matcher)));

const filterTree = (node, filter, matcher = defaultMatcher) => {
    // If im an exact match then all my children get to stay
    if (matcher(filter, node) || !node.children) {
        return node;
    }
    // If not then only keep the ones that match or have matching descendants
    const filtered = node.children.filter(child => findNode(child, filter, matcher)).map(child => filterTree(child, filter, matcher));
    return Object.assign({}, node, { children: filtered });
};

const expandFilteredNodes = (node, filter, matcher = defaultMatcher) => {
    let { children } = node;
    if (!children || children.length === 0) {
        return Object.assign({}, node, { toggled: false });
    }
    const childrenWithMatches = node.children.filter(child => findNode(child, filter, matcher));
    const shouldExpand = childrenWithMatches.length > 0;
    // If im going to expand, go through all the matches and see if thier children need to expand
    if (shouldExpand) {
        children = childrenWithMatches.map(child => expandFilteredNodes(child, filter, matcher));
    }
    return Object.assign({}, node, {
        children,
        toggled: shouldExpand
    });
};

const filter = (keyword, treeData) => {
    if (keyword) {
        let filtered = filterTree({ children: treeData }, keyword);
        filtered = expandFilteredNodes(filtered, keyword);
        return get(filtered, 'children', []);
    }
    return treeData;
};

class TreeViewWithKeyword extends Component {
    constructor(props) {
        super(props);
        const { treeData } = props;
        this.state = {
            data: treeData
        };
    }

    static getDerivedStateFromProps(nextProps, currentStatus) {
        const state = {};
        if (size(currentStatus.data) === 0) {
            state.data = nextProps.treeData;
        } else if (nextProps.searchKeyword !== prevKeyword) {
            state.data = filter(nextProps.searchKeyword, nextProps.treeData);
            prevKeyword = nextProps.searchKeyword;
        }

        if (!isEmpty(state)) {
            return state;
        }

        return null;
    }

    render() {
        const { data } = this.state;
        const { onSelect } = this.props;
        return <TreeView treeData={data} onSelect={onSelect} />;
    }
}

export default TreeViewWithKeyword;

TreeViewWithKeyword.propTypes = {
    treeData: PropTypes.array.isRequired,
    onSelect: PropTypes.func
};

TreeViewWithKeyword.defaultProps = {
    onSelect: f => f
};
