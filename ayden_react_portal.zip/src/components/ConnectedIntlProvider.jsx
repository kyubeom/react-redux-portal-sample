import { connect } from 'react-redux';
import { IntlProvider, addLocaleData } from 'react-intl';
import en from 'react-intl/locale-data/en';
import ko from 'react-intl/locale-data/ko';
import zh from 'react-intl/locale-data/zh';
import _ from 'lodash';

import { LOCALE_KEY } from 'constants/Locale';
import i18nMessages from 'src/i18n'; // 추후 동적 로딩 방법을 고려해보자...

addLocaleData([...en, ...ko, ...zh]);

function mapStateToProps(state) {
    const key = LOCALE_KEY[_.get(state, 'session.locale.langCode', '001')];
    return {
        locale: key,
        messages: i18nMessages[key]
    };
}
export default connect(mapStateToProps)(IntlProvider);
