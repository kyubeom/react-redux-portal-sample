import React, { useState, Suspense } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import TeamSearch from 'organisms/popup/search/LazyTeamSearch';
import { Button, Input, InputGroup, InputGroupAddon } from 'reactstrap';

const TeamSearchBox = props => {
    const [isOpen, setOpen] = useState(false);
    const [name, setName] = useState(undefined);
    const { handleSelect, defaultValue } = props;

    function onSelect(team) {
        setName(team.name);
        handleSelect(team);
    }

    function stopEvent(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    function openModal(e) {
        setOpen(true);
        if (e) {
            stopEvent(e);
        }
    }

    return (
        <>
            <InputGroup onClick={openModal}>
                <Input disabled={true} type="text" value={name} defaultValue={defaultValue} style={{ cursor: 'pointer' }} key={defaultValue} />
                <InputGroupAddon addonType="append">
                    <Button onClick={openModal}>
                        <i className="fas fa-search fa-lg search_icon" />
                    </Button>
                </InputGroupAddon>
            </InputGroup>
            <Suspense fallback={<React.Fragment />}>
                <TeamSearch isOpen={isOpen} handleSelect={onSelect} handleClose={() => setOpen(false)} />
            </Suspense>
        </>
    );
};

TeamSearchBox.propTypes = {
    handleSelect: PropTypes.func,
    defaultValue: PropTypes.string
};

TeamSearchBox.defaultProps = {
    handleSelect: _.noop,
    defaultValue: ''
};

export default TeamSearchBox;
