import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';

import WhiteLabelingRest from 'apis/WhiteLabelingRest';

const BrandImage = props => {
    const { locale } = props;
    const lang = locale.langCode;
    const [label, setLabel] = useState();

    useEffect(() => {
        WhiteLabelingRest.retrieveSolutionName(lang).then(setLabel);
    }, [lang]);

    return <div className="brand">{label}</div>;
};

BrandImage.propTypes = {
    locale: PropTypes.object.isRequired
};

const mapStateToProps = state => ({
    locale: state.session.locale
});

const connected = connect(mapStateToProps)(BrandImage);

export default connected;
