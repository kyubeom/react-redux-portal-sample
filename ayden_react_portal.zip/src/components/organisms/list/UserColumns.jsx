/* eslint-disable */
import React from 'react';
import { FormattedMessage } from 'react-intl';
import _ from 'lodash';
import CloseXButton from 'atoms/CloseXButton';

const columns = [
    {
        dataKey: 'userLangCdNm',
        width: 100,
        flexGrow: 0.1,
        headerRenderer: () => <FormattedMessage id="com.name" />
    },
    {
        dataKey: 'deptLangCdNm',
        width: 100,
        flexGrow: 0.1,
        headerRenderer: () => <FormattedMessage id="com.department" />
    },
    {
        dataKey: 'userLangCdCopNm',
        width: 80,
        flexGrow: 0.1,
        headerRenderer: () => <FormattedMessage id="com.position" />
    },
    {
        dataKey: 'userLoginId',
        width: 200,
        flexGrow: 0.2,
        headerRenderer: () => (
            <>
                <FormattedMessage id="com.email" />
                <FormattedMessage id="com.address" />
            </>
        )
    },
    {
        dataKey: 'userTelno',
        width: 150,
        flexGrow: 0.1,
        headerRenderer: () => <FormattedMessage id="com.phonenumber" />
    }
];

function getColumnsWithClose(close) {
    const clone = _.cloneDeep(columns);
    const withClose = _.last(clone);
    withClose.cellRenderer = (
        { cellData, rowData } // eslint-disable-line
    ) => (
        <>
            {cellData}
            <CloseXButton click={() => close(rowData)} />
        </>
    );
    clone[columns.length - 1] = withClose;
    return clone;
}

function replaceLastColumnsByComponentWithClose({ close, component: Component, selectConfig }) {
    const clone = _.cloneDeep(columns);
    const withClose = _.last(clone);

    withClose.className = 'dropdown';
    withClose.cellRenderer = (
        { rowData } // eslint-disable-line
    ) => (
        <>
            <Component selectConfig={({ key, value }) => selectConfig({ id: rowData.userId, key, value })} />
            <CloseXButton click={() => close(rowData)} />
        </>
    );

    clone[columns.length - 1] = withClose;
    return clone;
}

export default columns;

export { getColumnsWithClose, replaceLastColumnsByComponentWithClose };
