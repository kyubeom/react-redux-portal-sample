import PropTypes from 'prop-types';
import React, { useState, useEffect } from 'react';
import _ from 'lodash';
import { injectIntl } from 'react-intl';
import { withDialog } from 'hocs';
import { PaginationWithContainer, SearchInputBoxWithLabel, Table } from 'molecules';
import UserRest from 'apis/UserRest';
import styled from 'styled-components';
import UserColumns from './UserColumns';

const Div = styled.div`
    > * {
        margin-bottom: 10px;
    }
`;
const noDrag = { msUserSelect: 'none', mozUserSelect: '-moz-none', webkitUserSelect: 'none', khtmlUserSelect: 'none', userSelect: 'none' };

const limit = 5;
const UserListWithSearch = props => {
    const { onClick, onDoubleClick, intl } = props;
    const [keyword, setKeyword] = useState('');
    const [page, setPage] = useState(0);
    const [total, setTotal] = useState(0);
    const [list, setList] = useState([]);

    function setKeywordAndSearch(name) {
        setPage(0);
        setKeyword(name);
    }

    function onRowClick({ rowData }) {
        onClick(rowData);
        const { userId } = rowData;
        const changed = _.map(list, draft => {
            draft.checked = draft.userId === userId;
            return draft;
        });
        setList(changed);
    }

    function onRowDoubleClick({ rowData }) {
        onDoubleClick(rowData);
    }

    function changePageArgs(num) {
        setPage(num - 1);
    }

    useEffect(() => {
        function searchUsers() {
            const offset = page === 0 ? page : page * limit;
            UserRest.findUsers({ userNm: keyword, limit, offset }).then(res => {
                setTotal(res.total);
                if (_.isArray(res.data)) {
                    setList(res.data);
                }
            });
        }
        searchUsers();
    }, [keyword, page]);

    return (
        <Div>
            <SearchInputBoxWithLabel title={intl.formatMessage({ id: 'com.name' })} search={setKeywordAndSearch} minKeyWordLength={0} />
            <Table columns={UserColumns} list={list} tableOptions={{ height: 240, maxHeight: 240, headerHeight: 40, onRowClick, onRowDoubleClick, rowStyle: noDrag }} />
            <PaginationWithContainer totalNum={total} pageLimitNum={limit} selectedNum={page + 1} showingPageSize={5} pageActionFunc={changePageArgs} />
        </Div>
    );
};

UserListWithSearch.propTypes = {
    onClick: PropTypes.func,
    onDoubleClick: PropTypes.func
};

UserListWithSearch.defaultProps = {
    onClick: _.noop,
    onDoubleClick: _.noop
};

export default withDialog(injectIntl(UserListWithSearch));
