import React, { useState, Suspense } from 'react';
import PropTypes from 'prop-types';
import { Button } from 'reactstrap';
import _ from 'lodash';
import DialogService from 'utils/DialogService';
import { injectIntl } from 'react-intl';

const LazyLoad = React.lazy(() => import(/* webpackChunkName: "access_policy_edit_popup" */ 'organisms/popup/accessPolicy/AccessPolicyEditPopup.jsx'));
/* eslint-disable */
const AccessPolicyEditButton = props => {
    const { type, buttonName, successCallback, selectedItem, intl } = props;
    const [isOpen, setOpen] = useState(false);

    const headerTitle = `${intl.formatMessage({ id: 'admin.title.tntConPolicy' })} ${intl.formatMessage({ id: 'com.add' })}`;

    const togglePopup = () => {
        if (type === 'copy') {
            if (_.isEmpty(selectedItem)) {
                DialogService.alert({ id: 'com.alert.noSelectedItem' });
                return;
            }

            if (selectedItem.length > 1) {
                DialogService.alert({ id: 'admin.alert.tntConPolicy.copy.only.one' });
                return;
            }
        }
        setOpen(!isOpen);
    };

    const closeCallback = () => {
        setOpen(false);
    };

    const success = () => {
        successCallback();
        setOpen(false);
    };

    const refinedSelectedItem = () => {
        const item = _.get(selectedItem, '0', {});
        return {
            permYn: item.permYn,
            actorType: item.actrTypCd,
            deptValue: item.actrTypCd === '002' ? item.actrVal : '',
            deptValueName: item.actrTypCd === '002' ? item.actrValNm : '',
            accountValue: item.actrTypCd === '001' ? item.actrVal : '',
            application: item.appCd,
            actionType: item.actionTypCd,
            networkTypeForExplorer: item.appCd === '102' ? item.pstnVal : '',
            networkTypeForWEB: item.appCd === '101' ? item.pstnVal : ''
        };
    };

    return (
        <>
            <Button onClick={togglePopup}>{buttonName}</Button>
            {isOpen ? (
                <Suspense fallback={<></>}>
                    <LazyLoad
                        isOpen={isOpen}
                        headerTitle={headerTitle}
                        closeCallback={closeCallback}
                        successCallback={success}
                        type={type}
                        selectedItem={type === 'copy' ? refinedSelectedItem() : selectedItem}
                    />
                </Suspense>
            ) : (
                <></>
            )}
        </>
    );
};

AccessPolicyEditButton.propTypes = {
    buttonName: PropTypes.string.isRequired,
    type: PropTypes.oneOf(['add', 'copy']).isRequired,
    successCallback: PropTypes.func,
    selectedItem: PropTypes.array
};

AccessPolicyEditButton.defaultProps = {
    successCallback: _.noop,
    selectedItem: []
};

export default injectIntl(AccessPolicyEditButton);
