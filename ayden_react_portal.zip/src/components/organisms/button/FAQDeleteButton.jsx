import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import { FormattedMessage } from 'react-intl';
import { Button } from 'reactstrap';
import DialogService from 'utils/DialogService';
import FAQRest from 'apis/FAQRest';

const FAQDeleteButton = props => {
    const { selectedItem, afterSave } = props;

    const deleteFAQ = selectIds => {
        FAQRest.remove(selectIds).then(resolve => {
            const { resultCode, data, message } = resolve;
            if (resultCode === 200 && data === _.get(selectedItem, 'length')) {
                DialogService.alert({ id: 'com.alert.removed' }).then(() => afterSave());
            } else {
                DialogService.alert(`저장 실패하였습니다. ${message}`);
            }
        });
    };

    const onClick = () => {
        DialogService.confirm({ id: 'com.confirm.removal' }).then(result => {
            if (result) {
                if (_.isEmpty(selectedItem)) {
                    DialogService.alert({ id: 'com.alert.noSelectedItem' });
                } else {
                    const selectIds = _.map(selectedItem, value => {
                        return value.faqId;
                    });

                    if (_.isEmpty(selectIds)) {
                        DialogService.alert({ id: 'com.alert.noSelectedItem' });
                    } else {
                        deleteFAQ(selectIds);
                    }
                }
            }
        });
    };

    return (
        <Button onClick={onClick}>
            <FormattedMessage id="com.delete" />
        </Button>
    );
};

FAQDeleteButton.propTypes = {
    selectedItem: PropTypes.array,
    afterSave: PropTypes.func
};

FAQDeleteButton.defaultProps = {
    selectedItem: [],
    afterSave: _.noop
};

export default FAQDeleteButton;
