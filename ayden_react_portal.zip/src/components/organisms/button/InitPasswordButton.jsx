import React from 'react';
import _ from 'lodash';
import { Button } from 'reactstrap';
import PropTypes from 'prop-types';
import { withDialog } from 'components/hocs';
import { injectIntl } from 'react-intl';

import UserRest from 'apis/UserRest';

const ERROR_MESSAGES = {
    10542: 'admin.alert.changePassword.cannotChangeForLinkedAccount'
};

const InitPasswordButton = props => {
    const { name, users, dialog, intl, onSuccessCallback } = props;
    const buttonName = name || intl.formatMessage({ id: 'com.password' }) + intl.formatMessage({ id: 'com.reset' });
    const onClick = () => {
        if (_.isEmpty(users)) {
            dialog.alert({ id: 'admin.alert.userAccount.noSelectedUser' });
            return;
        }

        if (_.some(users, user => user.isLinkedOtherService)) {
            dialog.alert({ id: 'admin.alert.userAccount.unresetable' });
            return;
        }

        dialog.confirm({ id: 'admin.confirm.userAccount.reset' }).then(result => {
            if (result) {
                const userIds = _.map(users, user => user.userId);
                UserRest.initPassword({ userIds }).then(res => {
                    if (res.resultCode === 200) {
                        dialog.alert({ id: 'admin.toast.userAccount.tempPassword' }).then(() => {
                            onSuccessCallback();
                        });
                    } else {
                        const id = ERROR_MESSAGES[res.resultCode] || ' com.alert.unexpected-error';
                        dialog.alert({ id, values: { message: res.message } });
                    }
                });
            }
        });
    };

    return <Button onClick={onClick}>{buttonName}</Button>;
};

export default withDialog(injectIntl(InitPasswordButton));

InitPasswordButton.propTypes = {
    name: PropTypes.string,
    users: PropTypes.array,
    // users: PropTypes.arrayOf(
    //     PropTypes.shape({
    //         userId: PropTypes.string.isRequired,
    //         isLinkedOtherService: PropTypes.bool.isRequired
    //     })
    // ),
    onSuccessCallback: PropTypes.func
};

InitPasswordButton.defaultProps = {
    name: undefined,
    users: [],
    onSuccessCallback: _.noop
};
