import React, { useState, Suspense } from 'react';
import { Button } from 'reactstrap';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { connect } from 'react-redux';
import { injectIntl } from 'react-intl';

const LazyChangeUserStatus = React.lazy(() => import(/* webpackChunkName: "change_user_status_dialog" */ 'organisms/popup/user/ChangeUserStatus.jsx'));

const UserStatusChangeButton = props => {
    const [isOpen, setOpen] = useState(false);
    const { name, handleClose, handleSuccess, userIds, tenantId, adminUser, intl } = props;
    const buttonName = name || `${intl.formatMessage({ id: 'com.status' })} ${intl.formatMessage({ id: 'com.change' })}`;
    const closeCallback = () => {
        handleClose();
        setOpen(false);
    };

    const successCallback = () => {
        handleSuccess();
        setOpen(false);
    };

    const toggleOpenState = () => {
        setOpen(!isOpen);
    };

    const newTenantId = tenantId || adminUser.tenantId;

    return (
        <>
            <Button onClick={toggleOpenState}>{buttonName}</Button>
            <Suspense fallback={<React.Fragment />}>
                <LazyChangeUserStatus isOpen={isOpen} handleClose={closeCallback} handleSuccess={successCallback} userIds={userIds} tenantId={newTenantId} />
            </Suspense>
        </>
    );
};

const mapStateToProps = state => ({
    adminUser: state.session.adminUser
});
const connected = connect(mapStateToProps)(UserStatusChangeButton);

export default injectIntl(connected);

UserStatusChangeButton.propTypes = {
    name: PropTypes.string,
    userIds: PropTypes.array.isRequired,
    tenantId: PropTypes.string,
    handleClose: PropTypes.func,
    handleSuccess: PropTypes.func,
    adminUser: PropTypes.object.isRequired
};

UserStatusChangeButton.defaultProps = {
    name: undefined,
    tenantId: undefined,
    handleClose: _.noop,
    handleSuccess: _.noop
};
