import _ from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import { Button } from 'reactstrap';
import DialogService from 'utils/DialogService';
import FAQRest from 'apis/FAQRest';

const FAQStatusChangeButton = props => {
    const { selectedItem, buttonName, toStatus, afterSave } = props;

    const changeStatus = selectIds => {
        FAQRest.changeStatus(selectIds, toStatus).then(resolve => {
            const { resultCode, data, message } = resolve;
            if (resultCode === 200 && data === _.get(selectedItem, 'length')) {
                const status = _.lowerCase(toStatus);
                DialogService.alert({ id: `admin.alert.faq.status.change.${status}` }).then(afterSave);
            } else {
                DialogService.alert({ id: 'com.alert.unexpected-error', values: { code: `${resultCode} / ${message}` } });
            }
        });
    };

    const checkSameStatus = () => {
        const selectItemsLength = _.get(selectedItem, 'length');
        const sameStatusLength = _.reduce(
            selectedItem,
            (result, value) => {
                return value.faqStatCd === toStatus ? result + 1 : result;
            },
            0
        );
        if (selectItemsLength === sameStatusLength) {
            DialogService.alert({ id: 'admin.alert.faq.status.same' });
            return false;
        }
        return true;
    };

    const onClick = () => {
        if (_.isEmpty(selectedItem)) {
            return DialogService.alert({ id: 'com.alert.noSelectedItem' });
        }

        if (!checkSameStatus()) {
            return _.noop();
        }

        const selectIds = _.map(selectedItem, value => {
            return _.get(value, 'faqId', null);
        });

        if (_.isEmpty(selectIds)) {
            return DialogService.alert({ id: 'com.alert.noSelectedItem' });
        }

        return changeStatus(selectIds);
    };

    return <Button onClick={onClick}>{buttonName || toStatus}</Button>;
};

FAQStatusChangeButton.propTypes = {
    selectedItem: PropTypes.array,
    buttonName: PropTypes.string,
    toStatus: PropTypes.oneOf(['ACTIVE', 'DELETED']),
    afterSave: PropTypes.func
};

FAQStatusChangeButton.defaultProps = {
    selectedItem: [],
    buttonName: '',
    toStatus: 'ACTIVE',
    afterSave: _.noop
};

export default FAQStatusChangeButton;
