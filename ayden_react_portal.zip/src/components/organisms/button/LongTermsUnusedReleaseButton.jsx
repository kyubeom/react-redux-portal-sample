import React from 'react';
import _ from 'lodash';
import { Button } from 'reactstrap';
import PropTypes from 'prop-types';
import { injectIntl } from 'react-intl';

import { withDialog } from 'components/hocs';
import UserRest from 'apis/UserRest';
import { connect } from 'react-redux';

const LongTermsUnusedReleaseButton = props => {
    const { name, users, dialog, intl, adminUser, onSuccessCallback } = props;

    const buttonName = name || `${intl.formatMessage({ id: 'com.long-terms-unused' })} ${intl.formatMessage({ id: 'com.release' })}`;

    const onClick = () => {
        if (_.isEmpty(users)) {
            dialog.alert({ id: 'admin.alert.userAccount.noSelectedUser' });
            return;
        }

        const userIds = _.map(users, user => user.userId);
        UserRest.releaseLongTermsUnusedStatus({ userIds, requesterId: adminUser.adminId, tenantId: adminUser.tenantId }).then(() =>
            dialog.alert({ id: 'com.alert.saved' }).then(() => {
                onSuccessCallback();
            })
        );
    };

    return <Button onClick={onClick}>{buttonName}</Button>;
};

const mapStateToProps = state => ({
    adminUser: state.session.adminUser
});
const connected = connect(mapStateToProps)(LongTermsUnusedReleaseButton);

export default withDialog(injectIntl(connected));

LongTermsUnusedReleaseButton.propTypes = {
    name: PropTypes.string,
    users: PropTypes.array,
    // users: PropTypes.arrayOf(
    //     PropTypes.shape({
    //         userId: PropTypes.string.isRequired,
    //         status: PropTypes.string.isRequired,
    //         isLongTermsUnused: PropTypes.bool.isRequired
    //     })
    // ),
    adminUser: PropTypes.object.isRequired,
    onSuccessCallback: PropTypes.func
};

LongTermsUnusedReleaseButton.defaultProps = {
    name: undefined,
    users: [],
    onSuccessCallback: _.noop
};
