import React, { Component } from 'react';
import PropTypes from 'prop-types';
import ReactQuill from 'react-quill';
import _ from 'lodash';
import uuidV4 from 'uuid/v4';
import classNames from 'classnames/bind';
import 'react-quill/dist/quill.snow.css';
import styles from 'organisms/editor/editorStyles.css';

const IS_MSIE = navigator.userAgent.match(/Trident/i);

const cx = classNames.bind(styles);

class Editor extends Component {
    constructor(props) {
        super(props);
        this.state = { text: '' };
        this.handleChange = this.handleChange.bind(this);
    }

    componentDidMount() {
        this.init();
    }

    componentDidUpdate(prevProps) {
        const { html } = this.props;
        if (prevProps.html !== html) {
            this.init();
        }
    }

    init = () => {
        const { html } = this.props;
        let text = html;
        if (_.isEmpty(html)) {
            text = IS_MSIE ? '<p>&nbsp;</p>' : '';
        }
        this.setState({
            key: uuidV4(),
            text
        });
    };

    modules = {
        toolbar: {
            container: [
                ['bold', 'italic', 'underline'],
                [{ size: ['small', false, 'large', 'huge'] }, { color: [] }],
                [{ list: 'ordered' }, { list: 'bullet' }, { indent: '-1' }, { indent: '+1' }, { align: [] }],
                ['link', 'image']
            ]
        },
        clipboard: { matchVisual: false }
    };

    formats = ['header', 'bold', 'italic', 'underline', 'size', 'color', 'list', 'bullet', 'indent', 'link', 'image', 'align'];

    handleChange = (value, editor) => {
        let contents = value;
        if (IS_MSIE) {
            if (_.includes(contents, '<p><br></p>')) {
                contents = contents.replace(/<p><br><\/p>/gi, '<p>&nbsp;</p>');
            }
        }
        const { getHTML, isEmpty } = this.props;
        const empty =
            editor.getText().trim().length === 0 &&
            !_.find(editor.getContents().ops, temp => {
                const { insert } = temp;
                const { image } = insert;
                return image;
            });
        this.setState({ text: contents }, () => {
            getHTML(contents);
            isEmpty(empty);
        });
    };

    render() {
        const { text, key } = this.state;
        return (
            <div className={cx('editor-quill')}>
                <ReactQuill
                    style={{ height: 'calc(100% - 35px)', width: '100%' }}
                    key={key}
                    defaultValue={text}
                    formats={this.formats}
                    modules={this.modules}
                    onChange={(content, delta, source, editor) => this.handleChange(content, editor)}
                />
            </div>
        );
    }
}

Editor.propTypes = {
    html: PropTypes.node,
    getHTML: PropTypes.func,
    isEmpty: PropTypes.func
};

Editor.defaultProps = {
    html: '',
    getHTML: _.noop,
    isEmpty: _.noop
};

export default Editor;
