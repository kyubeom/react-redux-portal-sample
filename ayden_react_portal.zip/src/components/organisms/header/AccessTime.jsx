import React from 'react';
import { get, toNumber } from 'lodash';
import moment from 'moment';
import { NavItem } from 'reactstrap';
import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';

const AccessTime = props => {
    const { session } = props;
    const { locale } = session;
    return (
        <NavItem>
            <FormattedMessage id="admin.text.gnb.recentLogin" />{' '}
            {moment
                .utc(toNumber(get(session, 'access.utc', moment().valueOf())))
                .utcOffset(locale.timezoneDiff)
                .format('YYYY-MM-DD a hh:mm:ss')}
        </NavItem>
    );
};

export default AccessTime;

AccessTime.propTypes = {
    session: PropTypes.object.isRequired
};
