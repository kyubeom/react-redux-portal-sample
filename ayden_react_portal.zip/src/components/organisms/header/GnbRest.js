import { $http } from 'modules/index';

class GnbRest {
    static getAdminTimeoutValue() {
        return $http.get('/auth/v1/codes/timezone');
    }
}

export default GnbRest;
