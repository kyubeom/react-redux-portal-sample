import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Navbar, Nav, DropdownToggle, UncontrolledButtonDropdown, DropdownMenu, DropdownItem } from 'reactstrap';
import { isEmpty, noop } from 'lodash';
import { injectIntl, FormattedMessage } from 'react-intl';
import axios from 'axios';

import { session as sessionOperations } from 'actions';
import { withDialog } from 'components/hocs';
import { AuthenticationRest } from 'apis';
import AuthenticationService from 'utils/AuthenticationService';
import FileService from 'utils/FileService';
import MyTenantsDropdown from 'organisms/dropdown/MyTenantsDropdown';
import AccessTime from './AccessTime';
import SessionExtender from './SessionExtender';
import ChangePassword from '../popup/password/ChangePassword';

import './Gnb.scss';

class Gnb extends Component {
    constructor(props) {
        super(props);
        this.state = {
            openDialogForChangePassword: false
        };
        this.dialog = props.dialog;
    }

    handleSelect = eventKey => {
        switch (eventKey) {
            case 'changePassword':
                this.openChangePassword();
                break;
            case 'goToManualSite':
                this.openManual();
                break;
            case 'logout':
                this.logout();
                break;
            default:
                break;
        }
    };

    openChangePassword = () => {
        this.setState({ openDialogForChangePassword: true });
    };

    closeChangePassword = () => {
        this.setState({ openDialogForChangePassword: false });
    };

    openManual = () => {
        const manualPath = 'manual/[EFSS LITE] Admin_Manual.docx';
        axios.get(manualPath, { responseType: 'blob' }).then(res => {
            FileService.saveOrOpenBlob(res, '[EFSS_LITE] Admin_Manual', 'docx');
        });
    };

    logout = () => {
        const { intl } = this.props;
        this.dialog.confirm(intl.formatMessage({ id: 'admin.confirm.gnb.logout' })).then(result => {
            if (result) {
                AuthenticationRest.logout().then(() => {
                    const { removeSession } = this.props;
                    removeSession();
                    AuthenticationService.remove();
                });
            }
        });
    };

    changeTenant = tenantId => {
        AuthenticationRest.changeTenant(tenantId).then(({ data }) => {
            const changed = { tenantId: data.tenantId, companyId: data.coId, companyName: data.coNm };

            // session value change (sessionStorage)
            const { changeTenantWithinSession } = this.props;
            changeTenantWithinSession(changed);

            AuthenticationService.changeTenantWithinSession(changed);
            setTimeout(() => {
                window.location.reload();
            }, 300);
        });
    };

    render() {
        const { session } = this.props;

        if (isEmpty(session.adminUser)) {
            return <React.Fragment />;
        }

        const { closeChangePassword } = this;
        const { openDialogForChangePassword } = this.state;
        const { removeSession } = this.props;
        const { adminUser } = session;
        return (
            <header>
                <Navbar className="gnb">
                    <Nav className="container">
                        <MyTenantsDropdown onChange={this.changeTenant} initValue={adminUser.tenantId} />
                        <AccessTime i18n={{ t: this.t }} session={session} />
                        <SessionExtender i18n={{ t: this.t }} operatingTime={session.access.expirationTime} removeSession={removeSession} />
                        <UncontrolledButtonDropdown id="basic-nav-dropdown1">
                            <DropdownToggle tag="a" className="nav-link" caret={true} style={{ cursor: 'pointer' }}>
                                {adminUser.loginId}
                            </DropdownToggle>
                            <DropdownMenu right>
                                <DropdownItem onClick={() => this.handleSelect('changePassword')}>
                                    <FormattedMessage id="admin.text.gnb.changePassword" />
                                </DropdownItem>
                                <DropdownItem onClick={() => this.handleSelect('goToManualSite')}>
                                    <FormattedMessage id="admin.text.gnb.manual" />
                                </DropdownItem>
                                <DropdownItem onClick={() => this.handleSelect('logout')}>
                                    <FormattedMessage id="admin.text.gnb.logout" />
                                </DropdownItem>
                            </DropdownMenu>
                        </UncontrolledButtonDropdown>
                    </Nav>
                    <ChangePassword openDialogForChangePassword={openDialogForChangePassword} closePasswordPopEvent={closeChangePassword} />
                </Navbar>
            </header>
        );
    }
}

Gnb.propTypes = {
    intl: PropTypes.object.isRequired,
    session: PropTypes.object.isRequired,
    removeSession: PropTypes.func,
    changeTenantWithinSession: PropTypes.func
};

Gnb.defaultProps = {
    removeSession: noop,
    changeTenantWithinSession: noop
};

const mapDispatchToProps = dispatch => ({
    removeSession(session) {
        dispatch(sessionOperations.removeSession(session));
    },
    changeTenantWithinSession(session, id) {
        dispatch(sessionOperations.changeTenantWithinSession(session, id));
    }
});

const mapStateToProps = state => ({
    session: state.session
});

const I18nGnb = injectIntl(Gnb);
const connected = connect(
    mapStateToProps,
    mapDispatchToProps
)(I18nGnb);
const GnbWithHOC = withRouter(withDialog(connected));

export default GnbWithHOC;
