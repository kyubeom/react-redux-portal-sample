import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { NavItem } from 'reactstrap';
import { FormattedMessage } from 'react-intl';
import { connect } from 'react-redux';

import { Button } from 'atoms';
import GnbRest from 'organisms/header/GnbRest';
import Timer from '../../atoms/Timer';

const SessionExtender = props => {
    const { operatingTime, removeSession, forceInitUUID } = props;
    const [time, setTime] = useState(operatingTime);

    useEffect(() => {
        setTime(operatingTime);
    }, [forceInitUUID, operatingTime]);

    const extendSession = () => {
        // 세션 연장용으로 api 호출
        GnbRest.getAdminTimeoutValue();
        setTime(operatingTime);
    };

    return (
        <NavItem style={{ display: 'inline-flex' }}>
            <div style={{ paddingRight: '9px', lineHeight: 2 }}>
                <FormattedMessage id="admin.text.gnb.remainTime" /> <Timer operatingTime={time} whenTimeZeroFunction={removeSession} className="gnbTimer" forceInitUUID={forceInitUUID} />
            </div>
            <Button size="sm" onClick={extendSession}>
                <FormattedMessage id="admin.button.gnb.extend" />
            </Button>
        </NavItem>
    );
};

const mapStateToProps = state => ({
    forceInitUUID: state.loading.uuid
});

export default connect(mapStateToProps)(SessionExtender);

SessionExtender.propTypes = {
    operatingTime: PropTypes.oneOfType([PropTypes.number, PropTypes.object]),
    removeSession: PropTypes.func.isRequired,
    forceInitUUID: PropTypes.any
};

SessionExtender.defaultProps = {
    operatingTime: 3600,
    forceInitUUID: undefined
};
