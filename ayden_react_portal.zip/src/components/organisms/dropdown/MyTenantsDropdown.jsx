import React, { useState } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { Get } from 'react-axios';

import Dropdown from 'molecules/dropdown/Dropdown';

const MyTenantsDropdown = props => {
    const { onChange, dropdownStyles, dropdownToggleStyles, initValue } = props;
    const [selected, setStatus] = useState(initValue);
    const sanitizedOnChange = status => {
        onChange(status);
        setStatus(status);
    };
    let list = [];
    return (
        <Get url="/adm/v1/user/tenants">
            {(error, response, isLoading) => {
                if (isLoading || error || !response) {
                    return <React.Fragment />;
                }

                const { resultCode, data } = response;
                if (resultCode === 200 && !_.isEmpty(data)) {
                    list = _.map(data, t => ({ key: t.tenantId, message: t.name }));
                    if (_.isNil(initValue)) {
                        setStatus(_.get(data, '[0].tenantId'));
                    }
                }
                return <Dropdown {...props} list={list} dropdownStyles={dropdownStyles} dropdownToggleStyles={dropdownToggleStyles} selectCode={selected} onChange={sanitizedOnChange} />;
            }}
        </Get>
    );
};

MyTenantsDropdown.propTypes = {
    onChange: PropTypes.func,
    dropdownStyles: PropTypes.object,
    dropdownToggleStyles: PropTypes.object,
    initValue: PropTypes.string
};

MyTenantsDropdown.defaultProps = {
    onChange: _.noop,
    dropdownStyles: {},
    dropdownToggleStyles: {},
    initValue: undefined
};

export default MyTenantsDropdown;
