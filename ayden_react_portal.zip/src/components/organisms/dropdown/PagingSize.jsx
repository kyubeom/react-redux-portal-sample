import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { injectIntl } from 'react-intl';
import Dropdown from 'molecules/dropdown/Dropdown';

const PagingSize = props => {
    const { onChange, intl, size } = props;
    const list = [
        { key: 20, message: intl.formatMessage({ id: 'com.20views' }) },
        { key: 50, message: intl.formatMessage({ id: 'com.50views' }) },
        { key: 100, message: intl.formatMessage({ id: 'com.100views' }) }
    ];
    return <Dropdown onChange={onChange} list={list} selectCode={size} />;
};

PagingSize.propTypes = {
    onChange: PropTypes.func,
    size: PropTypes.number
};
PagingSize.defaultProps = {
    onChange: _.noop,
    size: 20
};

export default injectIntl(PagingSize);
