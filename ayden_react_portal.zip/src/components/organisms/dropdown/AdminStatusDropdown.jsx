import React, { useState } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { Dropdown, TableHeaderDropdown } from 'molecules';
import { Get } from 'react-axios';
import { injectIntl } from 'react-intl';

const AdminStatusDropdown = props => {
    const { onChange, dropdownStyles, dropdownToggleStyles, initValue, isTableHeader, intl } = props;
    const [selected, setStatus] = useState(initValue);
    const sanitizedOnChange = status => {
        setStatus(status);
        onChange(status);
    };
    const list = [];
    return (
        <Get url="/auth/v1/codes/2000004">
            {(error, response, isLoading) => {
                if (isLoading || error || !response) {
                    return <React.Fragment />;
                }

                const { resultCode, data } = response;
                if (resultCode === 200 && !_.isEmpty(data)) {
                    if (isTableHeader) {
                        list.push({ key: '', message: intl.formatMessage({ id: 'com.all' }) });
                    }
                    list.push(..._.map(data, s => ({ key: s.codeValidVal, message: s.thCdValidValNm })));
                    if (_.isNil(initValue)) {
                        setStatus(_.get(data, '[0].codeValidVal'));
                    }
                }
                if (isTableHeader) {
                    return (
                        <TableHeaderDropdown list={list} onChange={sanitizedOnChange} dropdownStyles={dropdownStyles} dropdownToggleStyles={dropdownToggleStyles} selectCode={selected} {...props} />
                    );
                }
                return <Dropdown list={list} onChange={sanitizedOnChange} dropdownStyles={dropdownStyles} dropdownToggleStyles={dropdownToggleStyles} selectCode={selected} {...props} />;
            }}
        </Get>
    );
};

AdminStatusDropdown.propTypes = {
    onChange: PropTypes.func,
    dropdownStyles: PropTypes.object,
    dropdownToggleStyles: PropTypes.object,
    initValue: PropTypes.string,
    isTableHeader: PropTypes.bool
};

AdminStatusDropdown.defaultProps = {
    onChange: _.noop,
    dropdownStyles: {},
    dropdownToggleStyles: {},
    initValue: '',
    isTableHeader: false
};

export default injectIntl(AdminStatusDropdown);
