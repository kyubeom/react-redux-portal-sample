import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import Dropdown from 'molecules/dropdown/Dropdown';
import UserRest from 'apis/UserRest';

const UserStatusDropdown = props => {
    const { onChange, dropdownStyles, dropdownToggleStyles, initValue } = props;
    const [selected, setStatus] = useState(initValue);
    const [statusList, setList] = useState([]);
    const sanitizedOnChange = status => {
        setStatus(status);
        onChange(status);
    };

    useEffect(() => {
        UserRest.getUserStatus().then(res => {
            const { data } = res;
            const list = _.map(data, draft => ({
                key: draft.codeValidVal,
                message: draft.thCdValidValNm
            }));
            setList(list);
        });
    }, [initValue]);

    return <Dropdown {...props} list={statusList} dropdownStyles={dropdownStyles} dropdownToggleStyles={dropdownToggleStyles} selectCode={selected} onChange={sanitizedOnChange} />;
};

UserStatusDropdown.propTypes = {
    onChange: PropTypes.func,
    dropdownStyles: PropTypes.object,
    dropdownToggleStyles: PropTypes.object,
    initValue: PropTypes.string
};

UserStatusDropdown.defaultProps = {
    onChange: _.noop,
    dropdownStyles: {},
    dropdownToggleStyles: {},
    initValue: 'A'
};

export default UserStatusDropdown;
