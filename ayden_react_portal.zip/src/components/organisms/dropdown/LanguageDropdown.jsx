import React, { useState } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { Get } from 'react-axios';

import LocaleRest from 'apis/LocaleRest';
import Dropdown from 'molecules/dropdown/Dropdown';

const LanguageDropdown = props => {
    const { onChange, dropdownStyles, dropdownToggleStyles, initValue } = props;
    const [selected, setStatus] = useState(initValue);
    const sanitizedOnChange = status => {
        onChange(status);
        setStatus(status);
    };
    let list = [];
    return (
        <Get url={LocaleRest.GET_LANGUAGES}>
            {(error, response, isLoading) => {
                if (isLoading || error || !response) {
                    return <React.Fragment />;
                }

                const { resultCode, data } = response;
                if (resultCode === 200 && !_.isEmpty(data)) {
                    list = _.map(data, t => ({ key: t.code, message: t.name }));
                    if (_.isNil(initValue)) {
                        setStatus(_.get(data, '[0].code'));
                    }
                }
                return <Dropdown {...props} list={list} dropdownStyles={dropdownStyles} dropdownToggleStyles={dropdownToggleStyles} selectCode={selected} onChange={sanitizedOnChange} />;
            }}
        </Get>
    );
};

LanguageDropdown.propTypes = {
    onChange: PropTypes.func,
    dropdownStyles: PropTypes.object,
    dropdownToggleStyles: PropTypes.object,
    initValue: PropTypes.string
};

LanguageDropdown.defaultProps = {
    onChange: _.noop,
    dropdownStyles: {},
    dropdownToggleStyles: {},
    initValue: undefined
};

export default LanguageDropdown;
