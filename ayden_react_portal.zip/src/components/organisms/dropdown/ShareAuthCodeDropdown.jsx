import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { injectIntl } from 'react-intl';
import Dropdown from 'molecules/dropdown/Dropdown';
import { TableHeaderDropdown } from 'molecules';

const ShareAuthCodeDropdown = props => {
    const { onChange, intl, selectCode, isTableHeader, includeAll } = props;
    const list = [];
    if (includeAll) {
        list.push({ key: '', message: intl.formatMessage({ id: 'com.all' }) });
    }
    list.push({ key: 'U20VIEW', message: intl.formatMessage({ id: 'com.viewable' }) });
    list.push({ key: 'U40COPY', message: intl.formatMessage({ id: 'com.copyable' }) });
    list.push({ key: 'U60EDIT', message: intl.formatMessage({ id: 'com.editable' }) });

    if (isTableHeader) {
        return <TableHeaderDropdown list={list} onChange={onChange} selectCode={selectCode} {...props} />;
    }
    return <Dropdown onChange={onChange} list={list} selectCode={selectCode} />;
};

ShareAuthCodeDropdown.propTypes = {
    onChange: PropTypes.func,
    isTableHeader: PropTypes.bool,
    selectCode: PropTypes.any,
    includeAll: PropTypes.bool
};
ShareAuthCodeDropdown.defaultProps = {
    onChange: _.noop,
    isTableHeader: false,
    selectCode: '',
    includeAll: true
};

export default injectIntl(ShareAuthCodeDropdown);
