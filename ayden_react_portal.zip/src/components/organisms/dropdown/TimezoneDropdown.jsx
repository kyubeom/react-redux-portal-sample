import React, { useState } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { Get } from 'react-axios';

import Dropdown from 'molecules/dropdown/Dropdown';

const TimezoneDropdown = props => {
    let list = [];
    const { onChange, dropdownStyles, dropdownToggleStyles, initValue, selectedValue } = props;
    const [selected, setStatus] = useState(initValue);
    const sanitizedOnChange = selectedCode => {
        onChange(_.find(list, t => t.key === selectedCode));
        setStatus(selectedCode);
    };

    const modifiers = {
        setMaxHeight: {
            enabled: true,
            fn: data => {
                return {
                    ...data,
                    styles: {
                        ...data.styles,
                        overflow: 'auto',
                        maxHeight: 250
                    }
                };
            }
        }
    };

    return (
        <Get url="/auth/v1/codes/timezone">
            {(error, response, isLoading) => {
                if (isLoading || error || !response) {
                    return <React.Fragment />;
                }

                const { resultCode, data } = response;
                if (resultCode === 200 && !_.isEmpty(data)) {
                    list = _.map(data, t => ({ key: t.code, message: t.name, timeDiff: t.value }));
                    if (_.isNil(initValue)) {
                        setStatus(_.get(data, '[0].value'));
                    }
                }
                return (
                    <Dropdown
                        {...props}
                        list={list}
                        dropdownStyles={dropdownStyles}
                        dropdownToggleStyles={dropdownToggleStyles}
                        selectCode={selectedValue || selected}
                        onChange={sanitizedOnChange}
                        dropdownMenuModifiers={modifiers}
                    />
                );
            }}
        </Get>
    );
};

TimezoneDropdown.propTypes = {
    onChange: PropTypes.func,
    dropdownStyles: PropTypes.object,
    dropdownToggleStyles: PropTypes.object,
    initValue: PropTypes.string,
    selectedValue: PropTypes.string
};

TimezoneDropdown.defaultProps = {
    onChange: _.noop,
    dropdownStyles: {},
    dropdownToggleStyles: {},
    initValue: undefined,
    selectedValue: undefined
};

export default TimezoneDropdown;
