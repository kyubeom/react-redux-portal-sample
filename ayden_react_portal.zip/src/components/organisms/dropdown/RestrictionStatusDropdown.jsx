import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { injectIntl } from 'react-intl';
import Dropdown from 'molecules/dropdown/Dropdown';
import { TableHeaderDropdown } from 'molecules';

const RestrictionStatusDropdown = props => {
    const { onChange, intl, selectCode, isTableHeader, includeAll } = props;
    const list = [];
    if (includeAll) {
        list.push({ key: '', message: intl.formatMessage({ id: 'com.all' }) });
    }
    list.push({ key: 'Y', message: intl.formatMessage({ id: 'com.in-use' }) });
    list.push({ key: 'N', message: intl.formatMessage({ id: 'com.not-inuse' }) });

    if (isTableHeader) {
        return <TableHeaderDropdown list={list} onChange={onChange} selectCode={selectCode} {...props} />;
    }
    return <Dropdown onChange={onChange} list={list} selectCode={selectCode} />;
};

RestrictionStatusDropdown.propTypes = {
    onChange: PropTypes.func,
    isTableHeader: PropTypes.bool,
    selectCode: PropTypes.any,
    includeAll: PropTypes.bool
};
RestrictionStatusDropdown.defaultProps = {
    onChange: _.noop,
    isTableHeader: false,
    selectCode: '',
    includeAll: true
};

export default injectIntl(RestrictionStatusDropdown);
