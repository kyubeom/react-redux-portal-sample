import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';
import _ from 'lodash';
import CustomScroll from 'react-custom-scroll';
import Category from 'molecules/category/Category';

import BrandImage from 'organisms/BrandImage';
import './Lnb.scss';

class Lnb extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedId: null,
            selectedCategoryId: null
        };
    }

    selectSubCategory = category => {
        const { selectedId } = this.state;
        if (_.isNil(selectedId) || selectedId === category.id) {
            this.reloadCurrentRoute(category);
        } else {
            const { history } = this.props;
            this.setState({ selectedId: category.id });
            history.push(category.url);
        }
    };

    clickCategory = id => {
        this.setState({ selectedCategoryId: id });
    };

    reloadCurrentRoute(category) {
        const { history } = this.props;
        history.push('/empty'); // 동일 메뉴 클릭시, 임시로 리로드를 하기위한 껍데기 라우터..
        setTimeout(() => {
            history.replace(category.url);
        });
    }

    render() {
        const { selectedId, selectedCategoryId } = this.state;
        const { selectSubCategory, clickCategory } = this;
        const { categories } = this.props;
        const props = {
            selectSubCategory,
            clickCategory,
            selectedId,
            selectedCategoryId
        };
        return (
            <div className="lnb">
                <CustomScroll flex="1" heightRelativeToParent="100vh">
                    <BrandImage />
                    <div className="categoryWrap">
                        {categories.map(category => (
                            <Category key={category.id || category.title} category={category} {...props} />
                        ))}
                    </div>
                </CustomScroll>
            </div>
        );
    }
}

export default withRouter(Lnb);

Lnb.propTypes = {
    history: PropTypes.object.isRequired,
    categories: PropTypes.array.isRequired,
    location: PropTypes.object.isRequired
};
