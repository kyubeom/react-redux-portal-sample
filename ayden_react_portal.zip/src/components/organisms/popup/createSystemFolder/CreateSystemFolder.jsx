import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { withDialog } from 'components/hocs';
import { ModalTemplate } from 'templates';
import { Button, Row, Col, Label, Input, Form, FormGroup, Modal, ModalBody, ModalFooter, ModalHeader } from 'reactstrap';
import { FormattedMessage, injectIntl } from 'react-intl';
import SystemFolderRest from '../../../../apis/SystemFolderRest';

const defaultState = { name: '', size: 1 };

class CreateSystemFolder extends Component {
    constructor(props) {
        super(props);
        this.state = { ...defaultState };
    }

    handleOnNameChange = ({ target }) => {
        const { value } = target;
        this.setState({ name: value });
    };

    handleOnSizeChange = ({ target }) => {
        const { value } = target;
        this.setState({ size: value });
    };

    handleSave = async () => {
        const { dialog } = this.props;
        const { name, size } = this.state;
        const { resultCode, data } = await SystemFolderRest.createSystemFolder(name, size * 1024 ** 3);
        if (resultCode === 200) {
            dialog.alert('폴더가 생성되었습니다.').then(() => this.handleClose(data));
        } else {
            dialog.alert(data || '폴더 생성을 실패했습니다.');
        }
    };

    handleClose = () => {
        const { handleCancel } = this.props;
        this.setState({ ...defaultState });
        handleCancel();
    };

    render() {
        const { show } = this.props;
        const { name, size } = this.state;
        return (
            <Modal isOpen={show} style={{ width: '100%', maxWidth: '400px' }} centered={true}>
                <ModalTemplate>
                    <ModalHeader>시스템 폴더 생성</ModalHeader>
                    <ModalBody>
                        <Form onSubmit={e => e.preventDefault()}>
                            <Row form>
                                <Col>
                                    <FormGroup row>
                                        <Label for="folderName" sm={3}>
                                            폴더이름
                                        </Label>
                                        <Col sm={9}>
                                            <Input type="text" value={name} onChange={this.handleOnNameChange} />
                                        </Col>
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Row form>
                                <Col>
                                    <FormGroup row>
                                        <Label for="folderName" sm={3}>
                                            용량(GB)
                                        </Label>
                                        <Col sm={9}>
                                            <Input type="number" value={size} onChange={this.handleOnSizeChange} />
                                        </Col>
                                    </FormGroup>
                                </Col>
                            </Row>
                        </Form>
                    </ModalBody>
                    <ModalFooter>
                        <Button color="secondary" onClick={this.handleClose}>
                            <FormattedMessage id="com.cancel" />
                        </Button>
                        <Button color="primary" onClick={this.handleSave}>
                            <FormattedMessage id="com.save" />
                        </Button>
                    </ModalFooter>
                </ModalTemplate>
            </Modal>
        );
    }
}

CreateSystemFolder.propTypes = {
    show: PropTypes.bool.isRequired,
    handleCancel: PropTypes.func.isRequired
};

export default withDialog(injectIntl(CreateSystemFolder));
