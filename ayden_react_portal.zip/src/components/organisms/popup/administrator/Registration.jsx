import React, { Component } from 'react';
import { Button, Col, Form, FormFeedback, FormGroup, Input, Label, Modal, ModalBody, ModalFooter, ModalHeader, Row, InputGroup, InputGroupAddon } from 'reactstrap';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { FormattedMessage, injectIntl } from 'react-intl';

import { AdminStatusDropdown } from 'organisms';
import ModalTemplate from 'templates/ModalTemplate';
import { withDialog } from 'components/hocs';
import { AdminAccountRest, AdminRoleRest } from 'apis';
import { Dropdown } from 'molecules';
import REGEX from 'src/constants/Regex';
import TeamSearchBox from 'organisms/input/TeamSearchBox';
import PhoneNumberInput from 'molecules/customInput/PhoneNumberInput';

const ColThenFormGroup = ({ children }) => {
    return (
        <Col md={6}>
            <FormGroup row>
                {children[0]}
                {children[1]}
            </FormGroup>
        </Col>
    );
};

ColThenFormGroup.propTypes = {
    children: PropTypes.array.isRequired
};

class Registration extends Component {
    constructor(props) {
        super(props);
        this.state = this.getInitState();
    }

    getInitState = assigned => {
        return _.assign(
            {
                administrator: { adminStatCd: 'S', roleId: this.defaultRoleId },
                checkedDuplicatedID: this.isModifyMode()
            },
            assigned
        );
    };

    isModifyMode() {
        const { mode } = this.props;
        return _.isEqual(mode, 'modify');
    }

    isAddMode() {
        const { mode } = this.props;
        return _.isEqual(mode, 'add');
    }

    async init() {
        const { administrator } = this.state;
        const { adminUserId } = this.props;
        if (this.isModifyMode() && _.isString(adminUserId)) {
            this.setState(this.getInitState());
            const admin = await AdminAccountRest.selectOne({ adminUserId });
            this.initAdmin = admin;
            this.setState({
                administrator: _.assignIn({}, administrator, admin),
                checkedDuplicatedID: this.isModifyMode()
            });
        } else {
            this.setState(this.getInitState());
        }
    }

    async componentDidMount() {
        const { data } = await AdminRoleRest.selectAdminRoles(0, 100);
        const { administrator } = this.state;
        this.defaultRoleId = _.get(data, 'list.[0].roleId', '');
        administrator.roleId = this.defaultRoleId;
        this.setState(
            {
                roles: _.map(data.list, role => ({ key: role.roleId, message: role.roleNm })),
                administrator
            },
            this.init
        );
    }

    componentDidUpdate(prevProps) {
        const { show } = this.props;
        if (show && prevProps.show !== show) {
            this.init();
        }
    }

    checkIDIfDuplicate = () => {
        const { administrator } = this.state;
        const { dialog, intl } = this.props;
        if (_.isEmpty(administrator.adminLoginId)) {
            dialog.alert({ id: 'com.check.necessary-input', values: { value: intl.formatMessage({ id: 'com.admin' }) + intl.formatMessage({ id: 'com.id' }) } });
            return;
        }
        AdminAccountRest.selectOne({ adminLoginId: administrator.adminLoginId }).then(data => {
            if (_.isEmpty(data)) {
                this.setState({ checkedDuplicatedID: true });
            } else {
                dialog.alert({ id: 'com.check.duplicated', values: { value: intl.formatMessage({ id: 'com.id' }) } });
            }
        });
    };

    uncheckIDIfDuplicate = () => {
        this.setState(draft => {
            draft.checkedDuplicatedID = false;
            return draft;
        });
    };

    changeRole = id => {
        const { administrator } = this.state;
        administrator.roleId = id;
        this.setState({ administrator });
    };

    changeStatus = status => {
        this.setState(draft => {
            draft.administrator.adminStatCd = status;
            return draft;
        });
    };

    handleKeydown = (event, key) => {
        const value = _.get(event, 'target.value');
        this.setState(draft => {
            draft.administrator[key] = value;
            return draft;
        });
    };

    save = () => {
        const { checkedDuplicatedID, administrator } = this.state;
        const { dialog } = this.props;
        if (!checkedDuplicatedID) {
            dialog.alert({ id: 'admin.alert.admAccAdd.doCheckDuplicatedId' });
            return;
        }

        if (this.isModifyMode() && !this.hasAdminChanged()) {
            // 변경사항 체크
            dialog.alert({ id: 'com.alert.noChanges' });
            return;
        }

        const callApi = this.isModifyMode() ? AdminAccountRest.changeAdministrator : AdminAccountRest.createAdministrator;
        callApi(administrator).then(() => {
            const { handleSuccess } = this.props;
            dialog.alert({ id: 'com.alert.saved' }).then(handleSuccess);
        });
    };

    close = () => {
        if (this.isAddMode()) {
            this.setState(this.getInitState());
        } else {
            this.setState({
                checkedDuplicatedID: true
            });
        }
        const { handleClose } = this.props;
        handleClose();
    };

    isValidEmail = () => {
        const { administrator } = this.state;
        return REGEX.EMAIL.test(administrator.adminEmailAddr);
    };

    isInvalidEmail = () => {
        return !this.isValidEmail();
    };

    isDisableToSave = () => {
        const { administrator } = this.state;
        return this.isInvalidEmail() || _.isNil(administrator.adminLoginId) || _.isNil(administrator.roleId);
    };

    selectTeam = team => {
        this.setState(draft => {
            draft.administrator.adminDeptId = team.id;
            draft.administrator.adminDeptNm = team.name;
            return draft;
        });
    };

    hasAdminChanged = () => {
        const { adminTelno: initTelno, adminCopNm: initCopNm, adminStatCd: initStatCd, adminDeptId: initDeptId, roleId: initRoleId, adminNm: initAdminNm } = this.initAdmin;
        const { administrator } = this.state;
        const { adminTelno, adminCopNm, adminStatCd, adminDeptId, roleId, adminNm } = administrator;
        return initTelno !== adminTelno || initCopNm !== adminCopNm || initStatCd !== adminStatCd || initDeptId !== adminDeptId || initRoleId !== roleId || initAdminNm !== adminNm;
    };

    render() {
        const { show, adminUserId } = this.props;
        const { roles, administrator, checkedDuplicatedID } = this.state;
        return (
            <Modal isOpen={show} style={{ width: '60%', maxWidth: '700px' }} centered={true}>
                <ModalTemplate>
                    <ModalHeader>{this.isAddMode() ? <FormattedMessage id="admin.title.admAccAdd.add" /> : <FormattedMessage id="admin.title.admAccAdd.edit" />}</ModalHeader>
                    <ModalBody>
                        <Form key={adminUserId || ''}>
                            <Row form>
                                <ColThenFormGroup>
                                    <Label for="adminLoginId" sm={4}>
                                        *<FormattedMessage id="com.admin" />
                                        <FormattedMessage id="com.id" />
                                    </Label>
                                    <Col sm={8}>
                                        {this.isModifyMode() ? (
                                            <Input
                                                type="text"
                                                name="adminLoginId"
                                                id="adminLoginId"
                                                disabled={true}
                                                style={{ backgroundColor: checkedDuplicatedID ? 'whitesmoke' : 'inherit' }}
                                                maxLength={100}
                                                onKeyUp={e => this.handleKeydown(e, 'adminLoginId')}
                                                defaultValue={administrator.adminLoginId}
                                            />
                                        ) : (
                                            <InputGroup>
                                                <Input
                                                    type="text"
                                                    name="adminLoginId"
                                                    id="adminLoginId"
                                                    disabled={checkedDuplicatedID}
                                                    style={{ backgroundColor: checkedDuplicatedID ? 'whitesmoke' : 'inherit' }}
                                                    maxLength={100}
                                                    onKeyUp={e => this.handleKeydown(e, 'adminLoginId')}
                                                    defaultValue={administrator.adminLoginId}
                                                />
                                                <InputGroupAddon addonType="append">
                                                    {checkedDuplicatedID ? (
                                                        <Button color="secondary" onClick={this.uncheckIDIfDuplicate}>
                                                            <FormattedMessage id="com.release" />
                                                        </Button>
                                                    ) : (
                                                        <Button color="secondary" onClick={this.checkIDIfDuplicate}>
                                                            <FormattedMessage id="com.text.checkDup" />
                                                        </Button>
                                                    )}
                                                </InputGroupAddon>
                                            </InputGroup>
                                        )}
                                    </Col>
                                </ColThenFormGroup>

                                <ColThenFormGroup>
                                    <Label for="name" sm={4}>
                                        <FormattedMessage id="com.name" />
                                    </Label>
                                    <Col sm={8}>
                                        <Input type="text" name="name" id="name" maxLength={100} onKeyUp={e => this.handleKeydown(e, 'adminNm')} defaultValue={administrator.adminNm} />
                                    </Col>
                                </ColThenFormGroup>

                                <ColThenFormGroup>
                                    <Label for="adminEmailAddr" sm={4}>
                                        *<FormattedMessage id="com.email" />
                                        <FormattedMessage id="com.address" />
                                    </Label>
                                    <Col sm={8}>
                                        <Input
                                            type="email"
                                            name="adminEmailAddr"
                                            id="adminEmailAddr"
                                            maxLength={200}
                                            onKeyUp={e => this.handleKeydown(e, 'adminEmailAddr')}
                                            invalid={_.isString(administrator.adminEmailAddr) && this.isInvalidEmail()}
                                            disabled={this.isModifyMode()}
                                            defaultValue={administrator.adminEmailAddr}
                                        />
                                        <FormFeedback>
                                            <FormattedMessage id="admin.alert.admAcc.invalidEmailAddress" />
                                        </FormFeedback>
                                    </Col>
                                </ColThenFormGroup>
                                <ColThenFormGroup>
                                    <Label for="adminTelno" sm={4}>
                                        <FormattedMessage id="com.phonenumber" />
                                    </Label>
                                    <Col sm={8}>
                                        <PhoneNumberInput
                                            type="text"
                                            name="adminTelno"
                                            id="adminTelno"
                                            maxLength={100}
                                            onKeyUp={e => this.handleKeydown(e, 'adminTelno')}
                                            defaultValue={administrator.adminTelno}
                                        />
                                    </Col>
                                </ColThenFormGroup>
                                <ColThenFormGroup>
                                    <Label sm={4}>
                                        <FormattedMessage id="com.department" />
                                    </Label>
                                    <Col sm={8}>
                                        <TeamSearchBox handleSelect={this.selectTeam} defaultValue={administrator.adminDeptNm} />
                                    </Col>
                                </ColThenFormGroup>
                                <ColThenFormGroup>
                                    <Label for="adminCopNm" sm={4}>
                                        <FormattedMessage id="com.position" />
                                    </Label>
                                    <Col sm={8}>
                                        <Input
                                            type="text"
                                            name="adminCopNm"
                                            id="adminCopNm"
                                            maxLength={100}
                                            onKeyUp={e => this.handleKeydown(e, 'adminCopNm')}
                                            defaultValue={administrator.adminCopNm}
                                        />
                                    </Col>
                                </ColThenFormGroup>
                            </Row>

                            <Row form>
                                <ColThenFormGroup>
                                    <Label for="exampleEmail" sm={4}>
                                        *<FormattedMessage id="com.text.role" />
                                    </Label>
                                    <Col sm={8}>
                                        {_.isArray(roles) && (
                                            <Dropdown list={roles} onChange={this.changeRole} selectCode={administrator.roleId} dropdownToggleStyles={{ minWidth: '70px', maxWidth: '203px' }} />
                                        )}
                                    </Col>
                                </ColThenFormGroup>
                                <ColThenFormGroup>
                                    <Label for="name" sm={4}>
                                        <FormattedMessage id="com.status" />
                                    </Label>
                                    <Col sm={8}>
                                        <AdminStatusDropdown
                                            onChange={this.changeStatus}
                                            initValue={administrator.adminStatCd}
                                            disabled={this.isAddMode()}
                                            dropdownToggleStyles={{ minWidth: '70px' }}
                                            selectCode={administrator.adminStatCd}
                                        />
                                    </Col>
                                </ColThenFormGroup>
                            </Row>
                        </Form>
                    </ModalBody>
                    <ModalFooter>
                        <Button color="secondary" onClick={this.close}>
                            <FormattedMessage id="com.cancel" />
                        </Button>
                        <Button color="primary" onClick={this.save} disabled={this.isDisableToSave()}>
                            <FormattedMessage id="com.save" />
                        </Button>
                    </ModalFooter>
                </ModalTemplate>
            </Modal>
        );
    }
}

export default withDialog(injectIntl(Registration));

Registration.propTypes = {
    show: PropTypes.bool.isRequired,
    handleClose: PropTypes.func.isRequired,
    handleSuccess: PropTypes.func.isRequired,
    mode: PropTypes.string,
    adminUserId: PropTypes.string
};

Registration.defaultProps = {
    mode: 'add',
    adminUserId: undefined
};
