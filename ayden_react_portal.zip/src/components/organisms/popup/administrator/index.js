import React from 'react';

const Registration = React.lazy(() => import(/* webpackChunkName: "admin_registration" */ './Registration.jsx'));

export { Registration }; // eslint-disable-line
