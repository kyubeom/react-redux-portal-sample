import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Button, Col, Row, Form, FormGroup, Label, Modal, ModalBody, ModalFooter, ModalHeader, InputGroup, InputGroupAddon, CustomInput } from 'reactstrap';
import _ from 'lodash';
import { FormattedMessage, injectIntl } from 'react-intl';

import NetworkRest from 'apis/NetworkRest';
import CodeRest from 'apis/CodeRest';
import { ModalTemplate } from 'templates';
import TeamSearch from 'organisms/popup/search/TeamSearch';
import { Dropdown } from 'molecules';
import { ACCOUNT_TYPE } from 'constants/Dropdown';
import AccessPolicyRest from 'apis/AccessPolicyRest';
import DialogService from 'utils/DialogService';

const getList = (list, intl) => {
    return [
        { key: '', message: intl.formatMessage({ id: 'com.all' }) },
        ..._.map(list, network => {
            return {
                message: network.ipNm,
                key: network.ipId
            };
        })
    ];
};

const DEAFULT_SELECTED_ITEM = {
    permYn: 'Y',
    actorType: '000',
    deptValue: '',
    deptValueName: '',
    accountValue: '',
    application: '000',
    actionType: '001',
    networkTypeForExplorer: '',
    networkTypeForWEB: ''
};

const DEFAULT_DROPDOWN_TOGGLE_STYPE = { height: '30px', maxWidth: '450px', display: 'flex', alignItems: 'center' };

const getSaveAPI = type => {
    if (type === 'add' || type === 'copy') {
        return AccessPolicyRest.create;
    }

    if (type === 'modify') {
        return AccessPolicyRest.modify;
    }
    return _.noop;
};

const getDeviceCode = application => {
    switch (application) {
        case '101':
        case '102':
            return '002';
        case '201':
        case '202':
            return '003';
        default:
            return '000';
    }
};

const AccessPolicyEditPopup = props => {
    const { isOpen, headerTitle, closeCallback, successCallback, type, selectedItem, intl } = props;
    const refinedSelectedItem = type === 'add' ? { ...DEAFULT_SELECTED_ITEM } : { ...DEAFULT_SELECTED_ITEM, ...selectedItem };
    const [permYn, setPermYn] = useState(refinedSelectedItem.permYn);
    const [actorType, setActorType] = useState(refinedSelectedItem.actorType);
    const [deptValue, setDeptValue] = useState(refinedSelectedItem.deptValue);
    const [deptValueName, setDeptValueName] = useState(refinedSelectedItem.deptValueName);
    const [accountValue, setAccountValue] = useState(refinedSelectedItem.accountValue);
    const [application, setApplication] = useState(refinedSelectedItem.application);
    const [actionType, setActionType] = useState(refinedSelectedItem.actionType);
    const [openTeamSearch, setOpenTeamSearch] = useState(false);
    const [networkTypeForExplorer, setNetworkTypeForExplorer] = useState(refinedSelectedItem.networkTypeForExplorer);
    const [networkTypeForWEB, setNetworkTypeForWEB] = useState(refinedSelectedItem.networkTypeForWEB);

    // GET 공통코드
    const [networkList, setNetworkList] = useState([]);
    const [actorTypeList, setActorTypeList] = useState([]);
    const [applicationTypeList, setApplicationTypeList] = useState([]);
    const [actionTypeList, setActionTypeList] = useState([]);

    useEffect(() => {
        if (isOpen) {
            // 네트워크 리스트
            NetworkRest.retrieveAll().then(list => {
                setNetworkList(getList(list, intl));
            });
            // 만약 타입 코드가 바뀐다면 프론트도 수정되어야함. 코드에 따라 선택할 수 있는 값이 다름.
            // 대상 리스트 ActorType
            CodeRest.select(3000001).then(codeList => {
                setActorTypeList(
                    _.map(codeList, actor => {
                        return { value: actor.codeValidVal, name: actor.thCdValidValNm };
                    })
                );
            });
            // 단말/서비스(어플리케이션)리스트 ApplicationCd
            CodeRest.select(3000007).then(codeList => {
                setApplicationTypeList(
                    _.map(codeList, app => {
                        return { value: app.codeValidVal, name: app.thCdValidValNm };
                    })
                );
            });
            // 활동 리스트 ActionType
            CodeRest.select(3000008).then(codeList => {
                const refined = _.map(codeList, action => {
                    return { value: action.codeValidVal, name: action.thCdValidValNm };
                });
                setActionTypeList(refined);
            });
        }
    }, []);

    const selectTeamSearch = team => {
        const { id, name } = team;
        setDeptValue(id);
        setDeptValueName(name);
    };

    const selectActor = value => {
        if (value !== '002') {
            setDeptValue('');
            setDeptValueName('');
        }

        if (value !== '001') {
            setAccountValue('');
        }

        setActorType(value);
    };

    const selectApplication = value => {
        if (application !== value) {
            if (value !== '001') {
                setNetworkTypeForWEB('');
            }
            if (value !== '002') {
                setNetworkTypeForExplorer('');
            }
        }

        setApplication(value);
    };

    const onChangeNetwork = (value, applicationCode) => {
        if (applicationCode === '101') {
            setNetworkTypeForWEB(value);
        }

        if (applicationCode === '102') {
            setNetworkTypeForExplorer(value);
        }
    };

    const getActorValue = () => {
        switch (actorType) {
            case '001':
                return accountValue;
            case '002':
                return deptValue;
            default:
                return '';
        }
    };

    const getParameter = () => {
        const { controlPolicyId } = selectedItem;
        const param = {
            actrTypCd: actorType,
            actrVal: getActorValue(),
            actionTypCd: actionType,
            deviceCd: getDeviceCode(application),
            appCd: application,
            pstnTypCd: _.isEmpty(networkTypeForExplorer) && _.isEmpty(networkTypeForWEB) ? '000' : '001',
            pstnVal: networkTypeForExplorer || networkTypeForWEB,
            permYn,
            controlPolicyId
        };

        if (type === 'add' || type === 'copy') {
            return param;
        }

        return { ...param, controlPolicyId: selectedItem.controlPolicyId };
    };

    const onSave = () => {
        const params = getParameter();
        const sanitized = type === 'modify' ? [params] : params;
        getSaveAPI(type)(sanitized).then(resolve => {
            const { resultCode, data, message } = resolve;
            if (data && resultCode === 200) {
                DialogService.alert({ id: 'com.alert.saved' }).then(() => successCallback());
            } else if (resultCode === 10352) {
                DialogService.alert({ id: 'com.alert.duplicatedDataFound' });
            } else {
                DialogService.alert({ id: 'com.alert.unexpected-error', values: { code: `${resultCode} / ${message}` } });
            }
        });
    };

    const checkSaveCondition = () => {
        // 부서선택후 부서 미지정시
        // 사용자 유형 선택 후 유형 미선택시
        if (actorType === '002' && _.isEmpty(deptValue)) {
            return true;
        }

        if ((application === '000' || application === '102') && actionType !== '001') {
            return true;
        }

        return actorType === '001' && _.isEmpty(accountValue);
    };

    const checkAction = action => {
        //  단말을 전체, PC 탐색기를 선택한 경우는 활동에서 로그인만 선택 가능
        if (application === '000' || application === '102') {
            if (action !== '001') {
                return true;
            }
        }
        return false;
    };

    return (
        <>
            <Modal isOpen={isOpen} style={{ width: '60%', maxWidth: '800px' }} centered={true}>
                <ModalTemplate>
                    <ModalHeader>{headerTitle}</ModalHeader>
                    <ModalBody>
                        <Form>
                            <FormGroup>
                                <Row>
                                    <Col md={2}>
                                        <Label for="permYn">
                                            <FormattedMessage id="admin.text.tntConPolicy.item" />
                                        </Label>
                                    </Col>
                                    <Col md={3}>
                                        <CustomInput
                                            type="radio"
                                            color="primary"
                                            label={intl.formatMessage({ id: 'admin.text.tntConPolicy.allow' })}
                                            name="permYn"
                                            id="Y"
                                            onChange={() => setPermYn('Y')}
                                            value="Y"
                                            checked={permYn === 'Y'}
                                        />
                                    </Col>
                                    <Col md={3}>
                                        <CustomInput
                                            type="radio"
                                            color="primary"
                                            label={intl.formatMessage({ id: 'admin.text.tntConPolicy.block' })}
                                            name="permYn"
                                            id="N"
                                            onChange={() => setPermYn('N')}
                                            value="N"
                                            checked={permYn === 'N'}
                                        />
                                    </Col>
                                </Row>
                            </FormGroup>
                            <FormGroup>
                                <Row>
                                    <Col md={2}>
                                        <Label for="actorType">
                                            <FormattedMessage id="admin.text.tntConPolicy.target" />
                                        </Label>
                                    </Col>
                                    <Col md={6}>
                                        {!_.isEmpty(actorTypeList) &&
                                            actorTypeList.map(actor => {
                                                return (
                                                    <FormGroup>
                                                        <Row md={2}>
                                                            <Col md={4}>
                                                                <CustomInput
                                                                    type="radio"
                                                                    color="primary"
                                                                    bsSize="lg"
                                                                    label={actor.name}
                                                                    name="actorType"
                                                                    id={`actor_${actor.value}`}
                                                                    key={actor.value}
                                                                    onChange={() => selectActor(actor.value)}
                                                                    value={actor.value}
                                                                    checked={actorType === actor.value}
                                                                />
                                                            </Col>
                                                            <Col md={8}>
                                                                {actor.value === '001' && (
                                                                    <Dropdown
                                                                        dropdownToggleStyles={{ height: '30px', maxWidth: '450px' }}
                                                                        list={ACCOUNT_TYPE}
                                                                        selectCode={accountValue}
                                                                        onChange={setAccountValue}
                                                                        defaultMessage={intl.formatMessage({ id: 'com.text.select' })}
                                                                        disabled={actorType !== actor.value}
                                                                    />
                                                                )}
                                                                {actor.value === '002' && (
                                                                    <InputGroup size="sm" style={{ display: 'inline-flex' }}>
                                                                        <input type="text" style={{ background: 'none' }} value={deptValueName} disabled />
                                                                        <InputGroupAddon addonType="append">
                                                                            <Button style={{ height: '30px' }} disabled={actorType !== actor.value} onClick={() => setOpenTeamSearch(!openTeamSearch)}>
                                                                                <i role="button" className="fas fa-search" style={{ cursor: 'pointer' }} />
                                                                            </Button>
                                                                        </InputGroupAddon>
                                                                        <TeamSearch isOpen={openTeamSearch} handleSelect={selectTeamSearch} handleClose={() => setOpenTeamSearch(false)} />
                                                                    </InputGroup>
                                                                )}
                                                            </Col>
                                                        </Row>
                                                    </FormGroup>
                                                );
                                            })}
                                    </Col>
                                </Row>
                            </FormGroup>
                            <FormGroup>
                                <Row>
                                    <Col md={2}>
                                        <Label for="application">
                                            <FormattedMessage id="admin.text.admin.text.tntConPolicy.deviceService" />
                                        </Label>
                                    </Col>
                                    <Col md={6}>
                                        {!_.isEmpty(applicationTypeList) &&
                                            applicationTypeList.map(app => {
                                                return (
                                                    <FormGroup>
                                                        <Row md={2}>
                                                            <Col md={4}>
                                                                <CustomInput
                                                                    type="radio"
                                                                    color="primary"
                                                                    label={app.name}
                                                                    name="application"
                                                                    id={`application_${app.value}`}
                                                                    key={app.value}
                                                                    onChange={() => selectApplication(app.value)}
                                                                    value={app.value}
                                                                    checked={application === app.value}
                                                                />
                                                            </Col>
                                                            <Col md={8}>
                                                                {app.value === '102' && (
                                                                    <Dropdown
                                                                        dropdownToggleStyles={DEFAULT_DROPDOWN_TOGGLE_STYPE}
                                                                        list={networkList}
                                                                        selectCode={networkTypeForExplorer}
                                                                        onChange={value => onChangeNetwork(value, app.value)}
                                                                        disabled={application !== app.value}
                                                                    />
                                                                )}
                                                                {app.value === '101' && (
                                                                    <Dropdown
                                                                        dropdownToggleStyles={DEFAULT_DROPDOWN_TOGGLE_STYPE}
                                                                        list={networkList}
                                                                        selectCode={networkTypeForWEB}
                                                                        onChange={value => onChangeNetwork(value, app.value)}
                                                                        disabled={application !== app.value}
                                                                    />
                                                                )}
                                                            </Col>
                                                        </Row>
                                                    </FormGroup>
                                                );
                                            })}
                                    </Col>
                                </Row>
                            </FormGroup>
                            <FormGroup>
                                <Row>
                                    <Col md={2}>
                                        <Label for="actionType">
                                            <FormattedMessage id="admin.text.tntConPolicy.activity" />
                                        </Label>
                                    </Col>
                                    {!_.isEmpty(actionTypeList) &&
                                        actionTypeList.map(action => {
                                            return (
                                                <Col md={2}>
                                                    <CustomInput
                                                        type="radio"
                                                        color="primary"
                                                        label={action.name}
                                                        name="actionType"
                                                        id={`actionType_${action.value}`}
                                                        onChange={() => setActionType(action.value)}
                                                        value={action.value}
                                                        disabled={checkAction(action.value)}
                                                        checked={actionType === action.value}
                                                    />
                                                </Col>
                                            );
                                        })}
                                </Row>
                            </FormGroup>
                        </Form>
                    </ModalBody>
                    <ModalFooter>
                        <Button onClick={closeCallback}>
                            <FormattedMessage id="com.cancel" />
                        </Button>
                        <Button color="primary" disabled={checkSaveCondition()} onClick={onSave}>
                            <FormattedMessage id="com.save" />
                        </Button>
                    </ModalFooter>
                </ModalTemplate>
            </Modal>
        </>
    );
};

AccessPolicyEditPopup.propTypes = {
    isOpen: PropTypes.bool,
    headerTitle: PropTypes.string,
    closeCallback: PropTypes.func.isRequired,
    successCallback: PropTypes.func,
    type: PropTypes.oneOf(['add', 'modify', 'copy']).isRequired,
    selectedItem: PropTypes.object
};

AccessPolicyEditPopup.defaultProps = {
    isOpen: false,
    headerTitle: '',
    successCallback: _.noop,
    selectedItem: {}
};

export default injectIntl(AccessPolicyEditPopup);
