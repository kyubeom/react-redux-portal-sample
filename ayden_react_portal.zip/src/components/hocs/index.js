import withDialog from './dialog/index';

export { withDialog }; // eslint-disable-line
