import React, { Component } from 'react';
import PropTypes from 'prop-types';
import DialogService from 'utils/DialogService';

class DialogComponent extends Component {
    constructor(props) {
        super(props);
        this.alert = this.alert.bind(this);
        this.confirm = this.confirm.bind(this);
    }

    alert(message) {
        return DialogService.alert(message);
    }

    confirm(message) {
        return DialogService.confirm(message);
    }

    render() {
        const dialog = {
            alert: this.alert,
            confirm: this.confirm
        };

        const { render } = this.props;

        return <React.Fragment>{render(dialog)}</React.Fragment>;
    }
}

export default DialogComponent;

DialogComponent.propTypes = {
    render: PropTypes.func.isRequired
};
