import React from 'react';

import DialogComponent from './Dialog';

const withDialog = Target =>
    function Component(props) {
        return <DialogComponent render={dialog => <Target {...props} dialog={dialog} />} />;
    };

export default withDialog;
