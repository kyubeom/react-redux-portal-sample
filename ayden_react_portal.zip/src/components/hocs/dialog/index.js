import withDialog from './withDialog';

export default withDialog;
