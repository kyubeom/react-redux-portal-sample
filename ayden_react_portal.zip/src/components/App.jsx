import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Route, Redirect, withRouter, Switch } from 'react-router-dom';
import { connect } from 'react-redux';
import { isEmpty, includes } from 'lodash';

import { session as sessionOperations } from 'actions';
import SessionConstant from 'constants/Session';
import { Spinner, Confirm, Alert, Exception } from 'molecules/index';
import ModalContainer from 'molecules/modal';

import Home from './pages/home/Home';
import Login from './pages/login/Login';

const activateWebAppIfHasAdminToken = operations => {
    operations.verifyingSession();
    const session = sessionStorage.getItem(SessionConstant.SESSION_KEY);
    if (session !== undefined && session !== null) {
        const parsed = JSON.parse(session);
        if (parsed.state === SessionConstant.SESSION_STATE.ACTIVE) {
            operations.activeSession(parsed);
        } else {
            operations.removeSession();
        }
    } else {
        operations.removeSession();
    }
};

const initApp = operations => {
    activateWebAppIfHasAdminToken(operations);
};

class App extends Component {
    componentDidMount() {
        const { redux } = this.props;
        initApp(redux);
    }

    render() {
        const { sessionState, loading, location } = this.props;
        if (isEmpty(sessionState) || sessionState === SessionConstant.SESSION_STATE.CHECKING) {
            return <React.Fragment />;
        }

        let to = '/employee-accounts';
        const { pathname } = location;
        if (sessionState === SessionConstant.SESSION_STATE.ACTIVE) {
            to = isEmpty(pathname) || pathname === '/login' ? to : pathname;
        } else if (includes([SessionConstant.SESSION_STATE.NONE], sessionState)) {
            to = '/login';
        }
        return (
            <React.Fragment>
                <Switch>
                    <Route path="/login" component={Login} {...this.props} />
                    <Route path="/" component={Home} {...this.props} />
                </Switch>
                <Spinner isLoading={loading.going} />
                {pathname !== to && <Redirect push={true} to={to} />}
                <Confirm />
                <Alert />
                <ModalContainer />
                <Exception />
            </React.Fragment>
        );
    }
}

const mapStateToProps = state => ({
    sessionState: state.session.state,
    loading: state.loading,
    popup: state.popup,
    authToken: state.session.authToken
});

const mapDispatchToProps = dispatch => ({
    redux: {
        activeSession(session) {
            dispatch(sessionOperations.activeSession(session));
        },
        verifyingSession() {
            dispatch(sessionOperations.verifyingSession());
        },
        removeSession() {
            dispatch(sessionOperations.removeSession());
        }
    }
});

const connected = connect(
    mapStateToProps,
    mapDispatchToProps
)(App);
export default withRouter(connected);

App.propTypes = {
    sessionState: PropTypes.string,
    loading: PropTypes.object,
    location: PropTypes.object
};

App.defaultProps = {
    sessionState: '',
    loading: {},
    location: {}
};
