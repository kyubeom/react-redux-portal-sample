import { isNil } from 'lodash';
import { $http } from '../modules/index';

const PREFIX = '/auth/v1/accesspolicy';

class AccessPolicyRest {
    static ACCESS_POLICY = PREFIX;

    /**
     * 시스템 접속 정책 다건 조회
     * @param params
     * @returns {AxiosPromise<any>}
     */
    static selectList(params) {
        const sanitized = params || {};
        if (isNil(sanitized.limit)) {
            sanitized.limit = 10;
        }
        if (isNil(sanitized.page)) {
            sanitized.page = 1;
        }
        return $http.get(PREFIX, { params: sanitized });
    }

    /**
     * 시스템 접속 정책 단건 추가
     * @param params
     * @returns {AxiosPromise<any>}
     */
    static create(params) {
        return $http.post(PREFIX, params);
    }

    /**
     * 시스템 접속 정책 다건 수정
     * @param params
     * @returns {AxiosPromise<any>}
     */
    static modify(params) {
        return $http.put(PREFIX, params);
    }

    /**
     * 시스템 접속 정책 다건 삭제
     * @param ids
     * @returns {AxiosPromise}
     */
    static remove(ids) {
        const body = { data: ids };
        return $http.delete(PREFIX, body);
    }

    static changeOrder(orders) {
        return $http.put(`${PREFIX}/rank`, orders);
    }
}

export default AccessPolicyRest;
