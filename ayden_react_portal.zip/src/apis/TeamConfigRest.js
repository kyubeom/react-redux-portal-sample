import _ from 'lodash';
import { $http } from '../modules/index';

class TeamConfigRest {
    retrieves(params) {
        if (_.isEmpty(params.cfgId)) {
            return Promise.reject();
        }
        return $http.get(`/auth/v1/depts/configs/${params.cfgId}/depts`, { params });
    }

    save(data) {
        return $http.put(`/auth/v1/depts/configs`, data);
    }

    remove({ deptIds, cfgId }) {
        return $http.delete(`/auth/v1/depts/configs`, { data: deptIds, params: { cfgId } });
    }
}

export default new TeamConfigRest();
