import store from 'src/redux/store';
import { $http } from '../modules/index';

function selectAllDepartments(condition) {
    const state = store.getState();
    const { tenantId } = state.session.adminUser;
    return $http.get('/auth/v1/depts/for-admin', { params: { tenantId, orgChartType: 'MANUAL', ...condition } });
}

function addDepartment(dept) {
    return $http.post('/auth/v1/depts', dept);
}

function modifyDepartment(dept) {
    const { deptId } = dept;
    return $http.put(`/auth/v1/depts/${deptId}`, dept);
}

function deleteDepartment(deptId) {
    const state = store.getState();
    const { tenantId } = state.session.adminUser;
    return $http.delete(`/auth/v1/depts/${deptId}`, { params: { tenantId } });
}

function selectSubDepartments(deptId) {
    const state = store.getState();
    const { tenantId } = state.session.adminUser;
    return $http.get(`/auth/v1/depts/${deptId}/sub`, { params: { tenantId } });
}

function selectSubDepartmentsWithoutParent(condition) {
    const { deptId } = condition;
    return $http.get(`/auth/v1/depts/${deptId}/sub`, { params: { ...condition } });
}

function modifySubDepartmentsOrder(deptId, subDeptIds) {
    return $http.put(`/auth/v1/depts/${deptId}/sub`, [...subDeptIds]);
}

function selectDepartmentPath(deptId) {
    const state = store.getState();
    const { langCode } = state.session.locale;
    return $http.get(`/auth/v1/depts/${deptId}/path`, { params: { deptId, langCode } });
}

export default {
    selectAllDepartments,
    addDepartment,
    modifyDepartment,
    deleteDepartment,
    selectSubDepartments,
    selectSubDepartmentsWithoutParent,
    modifySubDepartmentsOrder,
    selectDepartmentPath
};
