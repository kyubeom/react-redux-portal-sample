import QueryString from 'query-string';
import { isNil } from 'lodash';
import { Base64 } from 'js-base64';
import { $http } from '../modules/index';

const FAQ_PREFIX = '/common/v1/helpcenter';

class FAQRest {
    static GET_FAQ_LIST = `${FAQ_PREFIX}/faq`;

    /**
     * FAQ 다건 조회
     * @param params = {
     *  faqStatCd: 상태코드
     *  faqCatCd: 카테고리코드
     *  faqLangSectCd: 언어코드
     *  keyword: 검색어
     *  page, limit
     * }
     * @returns {AxiosPromise<any>}
     */
    static selectList(params) {
        const sanitized = params || {};
        if (isNil(params.limit)) {
            sanitized.limit = 10;
        }
        if (isNil(params.page)) {
            sanitized.page = 1;
        }
        return $http.get(`${FAQ_PREFIX}/faq`, { params: { ...sanitized, keyword: Base64.encode(sanitized.keyword) } });
    }

    /**
     * FAQ 추가시 순서 정보 조회
     * @param params
     * @returns {AxiosPromise<any>}
     */
    static selectOrderSequence(params = {}) {
        return $http.get(`${FAQ_PREFIX}/faq/orderSeq`, { params });
    }

    /**
     * FAQ 단건 추가
     * @param params
     * @returns {AxiosPromise<any>}
     */
    static create(params) {
        return $http.post(`${FAQ_PREFIX}/faq`, params);
    }

    /**
     * FAQ 단건 조회
     * @param id
     * @returns {AxiosPromise<any>}
     */
    static selectOne(id) {
        return $http.get(`${FAQ_PREFIX}/faq/${id}`);
    }

    /**
     * FAQ 단건 수정
     * @param params
     * @returns {AxiosPromise<any>}
     */
    static modify(params) {
        return $http.put(`${FAQ_PREFIX}/faq/${params.faqId}`, params);
    }

    /**
     * FAQ 상태 변경
     * @faqIds array
     * @statusCode "ACTIVE"||"DELETED"
     */
    static changeStatus(faqIds, statusCode) {
        return $http.put(`${FAQ_PREFIX}/faq`, { faqIds, faqStatCd: statusCode });
    }

    /**
     * FAQ 단건 삭제
     * @faqIds array
     * @returns {AxiosPromise}
     */
    static remove(faqIds) {
        return $http.delete(`${FAQ_PREFIX}/faq`, { params: { faqIds }, paramsSerializer: params => QueryString.stringify(params, { arrayFormat: 'repeat' }) });
    }
}

export default FAQRest;
