import _ from 'lodash';
import moment from 'moment';
import store from 'src/redux/store';
import { $http } from '../modules/index';
import FileService from '../utils/FileService';

let userStatus = [];
let userInactiveStatus = [];
const dateRegexp = /[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]/;

class UserRest {
    static GET_EMPLOYEE_LIST = '/auth/v1/users/for-admin';

    static getUserStatus = async () => {
        const response = await $http.get('/auth/v1/codes/2000004');
        const { data } = response;
        _.forEach(data, draft => {
            draft.key = draft.codeValidVal;
            draft.message = draft.thCdValidValNm;
        });
        userStatus = data;
        return response;
    };

    static getUserInactiveStatus = async () => {
        const response = await $http.get('/auth/v1/codes/2000005');
        const { data } = response;
        _.forEach(data, draft => {
            draft.key = draft.codeValidVal;
            draft.message = draft.thCdValidValNm;
        });
        userInactiveStatus = data;
        return response;
    };

    static getEmployeeAccounts = async params => {
        const response = await $http.get('/auth/v1/users/for-admin', { params });
        const { resultCode, data, total } = response;
        if (resultCode === 200) {
            data.forEach(draft => {
                const findUserStatus = _.find(userStatus, item => item.key === draft.userStatCd);
                draft.showUserStatCd = findUserStatus ? findUserStatus.message : '';
                draft.showStroageUseRate = (draft.stroageUseRate * 100).toFixed(0);
                draft.showFirstUserRegDt = moment(draft.firstUserRegDt).isValid() ? moment(draft.firstUserRegDt).format('YYYY-MM-DD A h:mm') : '';
                draft.showLastLoginDt = moment(draft.lastLoginDt).isValid() ? moment(draft.lastLoginDt).format('YYYY-MM-DD A h:mm') : '';
                draft.minStorageAllocSize = draft.storageAllocSize;
                draft.minLightDriveStorageAllocSize = draft.lightDriveStorageAllocSize;
                draft.minMailDriveStorageAllocSize = draft.mailDriveStorageAllocSize;
                const findDisableType = _.find(userInactiveStatus, item => item.key === draft.disableType);
                draft.showDisableType = findDisableType ? findDisableType.message : '';
                draft.selected = false;
            });
        }
        return { resultCode, data, total };
    };

    static getPartnerAccounts = async params => {
        const response = await $http.get('/auth/v1/users/for-admin', { params });
        const { resultCode, data, total } = response;
        const state = store.getState();
        const { timezoneDiff } = state.session.locale;
        if (resultCode === 200) {
            data.forEach(draft => {
                const findUserStatus = _.find(userStatus, item => item.key === draft.userStatCd);
                draft.showUserStatCd = findUserStatus ? findUserStatus.message : '';
                draft.showStroageUseRate = (draft.stroageUseRate * 100).toFixed(0);
                draft.showFirstUserRegDt = moment(draft.firstUserRegDt).isValid() ? moment(draft.firstUserRegDt).format('YYYY-MM-DD A h:mm') : '';
                draft.showLastLoginDt = moment(draft.lastLoginDt).isValid() ? moment(draft.lastLoginDt).format('YYYY-MM-DD A h:mm') : '';
                draft.minStorageAllocSize = draft.storageAllocSize;
                draft.minLightDriveStorageAllocSize = draft.lightDriveStorageAllocSize;
                draft.minMailDriveStorageAllocSize = draft.mailDriveStorageAllocSize;
                const findDisableType = _.find(userInactiveStatus, item => item.key === draft.disableType);
                draft.showDisableType = findDisableType ? findDisableType.message : '';
                draft.showAccessExpirationTime = moment(draft.accessExpirationTime).isValid()
                    ? moment(draft.accessExpirationTime)
                          .utcOffset(timezoneDiff)
                          .format('YYYY-MM-DD A h:mm:s')
                    : '';
                draft.accessExpirationTime = moment(draft.accessExpirationTime).isValid() ? draft.accessExpirationTime : moment('99991231', 'YYYYMMDD').valueOf();
                draft.selected = false;
            });
        }
        return { resultCode, data, total };
    };

    static getCheckDuplicatedUser(userLoginId, tenantId) {
        const params = {
            userLoginId,
            excludeUserId: '',
            tenantId
        };
        return $http.get('/auth/v1/user/valid', { params });
    }

    static changeUserStatus({ status, userIds, tenantId, disableType }) {
        if (_.isEmpty(userIds) || _.isEmpty(status) || _.isEmpty(tenantId)) {
            return Promise.reject();
        }
        const data = { userStatCd: status, userIds, tenantId, disableType };
        return $http.put('/auth/v1/users/userStatCd', data);
    }

    static initPassword({ userIds }) {
        if (_.isEmpty(userIds)) {
            return Promise.reject();
        }
        const data = { userIdsForReset: userIds };
        return $http.put('/auth/v1/users/passwords', data);
    }

    static releaseLongTermsUnusedStatus({ userIds, requesterId, tenantId }) {
        if (_.isEmpty(userIds) || _.isEmpty(requesterId) || _.isEmpty(tenantId)) {
            return Promise.reject();
        }
        const data = { userIds, requesterUserId: requesterId, tenantId };
        return $http.put('/auth/v1/users/lastactdt', data);
    }

    static changeExpirationDate({ userIds, accessExpiredTime }) {
        if (_.isEmpty(userIds) || _.isNil(accessExpiredTime)) {
            return Promise.reject();
        }

        const YYYYMMDDFORMAT = moment(accessExpiredTime).format('YYYY-MM-DD');
        const momentTil235959 = `${YYYYMMDDFORMAT}T23:59:59`;
        const timezoneAdded = moment(momentTil235959).valueOf();
        const data = { userIds, accessExpiredTime: timezoneAdded };
        return $http.put('/auth/v1/users/accessExpiredTime', data);
    }

    static findUsers(params) {
        return $http.get('/auth/v1/users', { params });
    }

    static createUser(user) {
        const targetKeys = [
            'userSectCd',
            'userIfYn',
            'userLoginId',
            'userNm',
            'userEngNm',
            'userCopNm',
            'userCopEngNm',
            'deptId',
            'userTelno',
            'userCelno',
            'storageAllocSize',
            'lightDriveStorageAllocSize',
            'mailDriveStorageAllocSize',
            'userStatCd',
            'notAllowedSyncPeriodYmd'
        ];

        const data = _.pick(user, targetKeys);
        const state = store.getState();
        data.tenantId = state.session.adminUser.tenantId;
        data.coId = state.session.adminUser.companyId;
        data.storageAllocSize = Number(data.storageAllocSize);
        data.lightDriveStorageAllocSize = Number(data.lightDriveStorageAllocSize);
        data.mailDriveStorageAllocSize = Number(data.mailDriveStorageAllocSize);
        if (moment(data.notAllowedSyncPeriodYmd).isValid()) {
            data.notAllowedSyncPeriodYmd = moment(data.notAllowedSyncPeriodYmd).format('YYYYMMDD');
        }
        if (dateRegexp.test(data.notAllowedSyncPeriodYmd)) {
            data.notAllowedSyncPeriodYmd = moment(data.notAllowedSyncPeriodYmd, 'YYYY-MM-DD').format('YYYYMMDD');
        }
        return $http.post('/auth/v1/users', data);
    }

    static updateUser(originUser, newUser) {
        const targetKeys = [
            'userId',
            'userIfYn',
            'userNm',
            'userEngNm',
            'userCopNm',
            'userCopEngNm',
            'deptId',
            'userTelno',
            'userCelno',
            'storageAllocSize',
            'lightDriveStorageAllocSize',
            'mailDriveStorageAllocSize',
            'userStatCd',
            'notAllowedSyncPeriodYmd',
            'userDescContent'
        ];

        const data = {
            userId: originUser.userId
        };

        _.forEach(targetKeys, targetKey => {
            if (originUser[targetKey] !== newUser[targetKey]) {
                data[targetKey] = newUser[targetKey];

                if (targetKey === 'notAllowedSyncPeriodYmd') {
                    if (moment(data[targetKey]).isValid()) {
                        data[targetKey] = moment(data[targetKey]).format('YYYYMMDD');
                    }
                    if (dateRegexp.test(data[targetKey])) {
                        data[targetKey] = moment(data[targetKey], 'YYYY-MM-DD').format('YYYYMMDD');
                    }
                } else if (targetKey === 'storageAllocSize' || targetKey === 'lightDriveStorageAllocSize' || targetKey === 'mailDriveStorageAllocSize') {
                    data[targetKey] = Number(data[targetKey]);
                }
            }
        });

        return $http.put(`/auth/v1/users/${originUser.userId}`, data);
    }

    static createPartner(user) {
        const targetKeys = [
            'userSectCd',
            'userIfYn',
            'userLoginId',
            'userNm',
            'userEngNm',
            'userCopNm',
            'userCopEngNm',
            'deptId',
            'userTelno',
            'userCelno',
            'chargingDeptId',
            'storageAllocSize',
            'lightDriveStorageAllocSize',
            'mailDriveStorageAllocSize',
            'userStatCd'
        ];

        if (user.userIfYn === 'Y') {
            targetKeys.push('notAllowedSyncPeriodYmd');
        } else {
            targetKeys.push('orgnOnpstCoNm');
            targetKeys.push('accessExpirationTime');
        }

        const data = _.pick(user, targetKeys);

        const state = store.getState();
        data.tenantId = state.session.adminUser.tenantId;
        data.coId = state.session.adminUser.companyId;
        data.storageAllocSize = Number(data.storageAllocSize);
        data.lightDriveStorageAllocSize = Number(data.lightDriveStorageAllocSize);
        data.mailDriveStorageAllocSize = Number(data.mailDriveStorageAllocSize);
        if (user.userIfYn === 'N') {
            const YYYYMMDDFORMAT = moment(data.accessExpirationTime).format('YYYY-MM-DD');
            const momentTil235959 = `${YYYYMMDDFORMAT}T23:59:59`;
            const timezoneAdded = moment(momentTil235959).valueOf();
            data.accessExpirationTime = timezoneAdded;
        }

        if (user.userIfYn === 'Y') {
            if (moment(data.notAllowedSyncPeriodYmd).isValid()) {
                data.notAllowedSyncPeriodYmd = moment(data.notAllowedSyncPeriodYmd).format('YYYYMMDD');
            }
            if (dateRegexp.test(data.notAllowedSyncPeriodYmd)) {
                data.notAllowedSyncPeriodYmd = moment(data.notAllowedSyncPeriodYmd, 'YYYY-MM-DD').format('YYYYMMDD');
            }
        }

        return $http.post('/auth/v1/users', data);
    }

    static updatePartner(originUser, newUser) {
        const targetKeys = [
            'userSectCd',
            'userIfYn',
            'userLoginId',
            'userNm',
            'userEngNm',
            'userCopNm',
            'userCopEngNm',
            'deptId',
            'userTelno',
            'userCelno',
            'chargingDeptId',
            'storageAllocSize',
            'lightDriveStorageAllocSize',
            'mailDriveStorageAllocSize',
            'userStatCd',
            'userDescContent'
        ];

        if (newUser.userIfYn === 'Y') {
            targetKeys.push('notAllowedSyncPeriodYmd');
        } else {
            targetKeys.push('orgnOnpstCoNm');
            targetKeys.push('accessExpirationTime');
        }

        const data = {
            userId: originUser.userId
        };
        _.forEach(targetKeys, targetKey => {
            if (originUser[targetKey] !== newUser[targetKey]) {
                data[targetKey] = newUser[targetKey];

                if (targetKey === 'notAllowedSyncPeriodYmd') {
                    if (moment(data[targetKey]).isValid()) {
                        data[targetKey] = moment(data[targetKey]).format('YYYYMMDD');
                    }
                    if (dateRegexp.test(data[targetKey])) {
                        data[targetKey] = moment(data[targetKey], 'YYYY-MM-DD').format('YYYYMMDD');
                    }
                } else if (targetKey === 'storageAllocSize' || targetKey === 'lightDriveStorageAllocSize' || targetKey === 'mailDriveStorageAllocSize') {
                    data[targetKey] = Number(data[targetKey]);
                }
            }
        });

        const state = store.getState();
        data.tenantId = state.session.adminUser.tenantId;
        data.coId = state.session.adminUser.companyId;
        if (newUser.userIfYn === 'N') {
            const YYYYMMDDFORMAT = moment(data.accessExpirationTime).format('YYYY-MM-DD');
            const momentTil235959 = `${YYYYMMDDFORMAT}T23:59:59`;
            const timezoneAdded = moment(momentTil235959).valueOf();
            data.accessExpirationTime = timezoneAdded;
        }

        if (newUser.userIfYn === 'N' && originUser.userIfYn === 'Y') {
            data.userStatCd = 'S';
        }
        return $http.put(`/auth/v1/users/${originUser.userId}`, data);
    }

    static getProductList = async () => {
        const response = await $http.get('/auth/v1/codes/2000006');
        const { data } = response;
        data.forEach(draft => {
            draft.value = draft.codeValidVal;
            draft.message = draft.thCdValidValNm;
        });
        return data;
    };

    static getStatusList = async () => {
        const response = await $http.get('/auth/v1/codes/2000004');
        const { data } = response;
        data.forEach(draft => {
            draft.value = draft.codeValidVal;
            draft.message = draft.thCdValidValNm;
        });
        return data;
    };

    static getDeptPath = async deptId => {
        const response = await $http.get(`/auth/v1/depts/${deptId}/path`);
        return response.data;
    };

    static downloadExcel = async (params, fileName, fileType) => {
        await $http.get('/auth/v1/users/for-admin/excel', { responseType: 'blob', params }).then(response => {
            FileService.saveOrOpenBlob(response, fileName, fileType);
        });
    };

    static downloadExcelForPartner = async (params, fileName, fileType) => {
        await $http.get('/auth/v1/users/for-admin/excel/subcontractor', { responseType: 'blob', params }).then(response => {
            FileService.saveOrOpenBlob(response, fileName, fileType);
        });
    };

    static getSystemCollabFolders = async params => {
        const response = await $http.get('/drive/v1/folders', { params });
        return response;
    };

    static getFiles = async params => {
        const response = await $http.get('/drive/v1/folders', { params });
        return response;
    };

    static getConfigs = async () => {
        const response = await $http.get('/auth/v1/configs/cfg');
        return response;
    };
}

export default UserRest;
