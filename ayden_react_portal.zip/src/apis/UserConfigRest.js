import _ from 'lodash';
import { $http } from '../modules/index';

class UserConfigRest {
    retrieves(params) {
        if (_.isEmpty(params.cfgId)) {
            return Promise.reject();
        }
        return $http.get(`/auth/v1/user/configs/${params.cfgId}/users`, { params });
    }

    save(data) {
        return $http.put(`/auth/v1/user/configs`, data);
    }

    remove({ userIds, cfgId }) {
        return $http.delete(`/auth/v1/user/configs`, { data: userIds, params: { cfgId } });
    }
}

export default new UserConfigRest();
