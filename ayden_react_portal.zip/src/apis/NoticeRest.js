import QueryString from 'query-string';
import { Base64 } from 'js-base64';
import { $http } from '../modules/index';

const prefix = '/common/v1/helpcenter/anuc';

class NoticeRest {
    static selectNotices(params) {
        const changedParams = params;
        const { keyword } = params;
        if (keyword) changedParams.keyword = Base64.encode(keyword);
        return $http.get(prefix, { params: changedParams });
    }

    static getNotice(anucId) {
        return $http.get(`${prefix}/${anucId}`);
    }

    static deleteNotices(anucIds) {
        return $http.delete(prefix, { params: { anucIds }, paramsSerializer: params => QueryString.stringify(params, { arrayFormat: 'repeat' }) });
    }

    static addNotice(anuc) {
        return $http.post(prefix, anuc);
    }

    static updateNotice(anuc, anucId) {
        return $http.put(`${prefix}/${anucId}`, anuc);
    }
}

export default NoticeRest;
