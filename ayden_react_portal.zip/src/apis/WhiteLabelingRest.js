import _ from 'lodash';
import $http from '../modules/Http';

class WhiteLabelingRest {
    retrieveSolutionName(lang) {
        const code = WhiteLabelingRest.CODES_BY_LANG[lang] || WhiteLabelingRest['001'];
        return $http.get(`/common/v1/configs/cfg/${code}`).then(res => _.get(res, 'data.cfgVal', 'Knox Drive'));
    }
}

WhiteLabelingRest.CODES_BY_LANG = {
    '001': 'EFL_COM_SOLUTION_NAME_KO',
    '002': 'EFL_COM_SOLUTION_NAME_EN',
    '003': 'EFL_COM_SOLUTION_NAME_CH'
};

export default new WhiteLabelingRest();
