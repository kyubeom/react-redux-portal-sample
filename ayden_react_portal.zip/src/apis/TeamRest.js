import { setupCache } from 'axios-cache-adapter';
import { $http } from '../modules/index';

const cache = setupCache({ maxAge: 60 * 1000 });
const deptCacheAxios = $http.create({ adapter: cache.adapter });

function selectAllDepartmentsWithCache(tenantId) {
    return deptCacheAxios.get('/auth/v1/depts', { params: { tenantId } }).then(res => res.data);
}

export default {
    selectAllDepartmentsWithCache
};
