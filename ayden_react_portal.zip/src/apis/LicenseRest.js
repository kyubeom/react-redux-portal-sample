import { $http } from '../modules/index';

class LicenseRest {
    get() {
        return $http.get('/common/v1/licensekey').then(res => res.data);
    }

    create(created) {
        return $http.post('/common/v1/licensekey', created);
    }

    update(updated) {
        return $http.put('/common/v1/licensekey', updated);
    }
}

export default new LicenseRest();
