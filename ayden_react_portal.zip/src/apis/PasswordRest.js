import { $http } from 'modules';

class PasswordRest {
    static changePassword(origin, change) {
        const data = {
            oldPassword: origin,
            newPassword: change
        };
        return $http.put('/adm/v1/user/password/initialize', data);
    }
}

export default PasswordRest;
