import { isNil } from 'lodash';
import { $http } from '../modules/index';

class CodeRest {
    static select(codeId) {
        if (isNil(codeId)) {
            return Promise.resolve();
        }
        return $http.get(`/auth/v1/codes/${codeId}`).then(res => res.data);
    }
}

export default CodeRest;
