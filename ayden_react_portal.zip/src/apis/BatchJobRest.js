import store from 'src/redux/store';
import { $http } from '../modules/index';

class BatchJobRest {
    static select(params = {}) {
        return $http.get('/adm/v1/bats', { params });
    }

    static updateStatus(userStatCd = 'A', param = {}) {
        return $http.put(`/adm/v1/bats/${userStatCd}`, param);
    }

    static selectCodeForBatchJob(cdIds) {
        return $http.get(`/adm/v1/codes?cdIds=${cdIds}`).then(res => res.data);
    }

    static updateBatchJob(batchJob) {
        const state = store.getState();
        const batchJobParam = Object.assign({}, batchJob);
        batchJobParam.tenantId = state.session.adminUser.tenantId;
        batchJobParam.coId = state.session.adminUser.companyId;
        return $http.put('/adm/v1/bats', batchJobParam);
    }
}

export default BatchJobRest;
