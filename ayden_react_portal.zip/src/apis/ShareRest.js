import { $http } from 'src/modules/index';

class ShareRest {
    static getShareTargets(objtId, objtShareTgtSectCd, objtShareTgtNm, objtShareTgtDeptNm, authCd, page = 1, limit = 20) {
        const params = {
            objtShareTgtSectCd,
            objtShareTgtNm,
            objtShareTgtDeptNm,
            authCd,
            page,
            limit
        };

        return $http.get(`/drive/v1/shares/admin/${objtId}`, { params }).then(
            response => {
                console.log('call getShareTargets : ', response.data);
                return response;
            },
            error => {
                return error;
            }
        );
    }

    static saveShareTargets(objtIds, shareTargets) {
        const config = { objtIds, shareTargets };
        const url = `/drive/v1/shares`;

        return $http.post(url, config).then(
            response => {
                console.log('called saveShareTargets : ', response.data);
                return response;
            },
            error => {
                return error;
            }
        );
    }
}

export default ShareRest;
