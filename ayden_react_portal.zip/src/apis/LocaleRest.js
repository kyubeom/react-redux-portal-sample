import { $http } from '../modules/index';

class LocaleRest {
    GET_LANGUAGES = '/auth/v1/codes/language';

    getLanguages() {
        return $http.get(this.GET_LANGUAGES).then(res => res.data);
    }
}

export default new LocaleRest();
