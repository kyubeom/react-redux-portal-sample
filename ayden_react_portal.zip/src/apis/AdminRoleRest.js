import { isNil } from 'lodash';
import { $http } from 'src/modules/index'; // eslint-disable-line

class AdminRoleRest {
    static selectAdminRoles(page, limit, roleNm, roleStatus) {
        const params = {
            page: isNil(page) ? 0 : page,
            limit: isNil(page) ? 10 : limit
        };
        if (roleNm) params.roleNm = roleNm;
        if (roleStatus) params.roleStatus = roleStatus;
        return $http.get('/adm/v1/roles', { params });
    }

    static retrievesRoleAndMenu(roleId, includeUpr = 'N') {
        return $http.get('/adm/v1/role/menu', { params: { roleId, includeUpr } });
    }

    static selectAdminRole(roleId) {
        return $http.get('/adm/v1/role', { params: { roleId } });
    }

    static deleteAdminRole(roleIds) {
        const body = { data: roleIds };
        return $http.delete('/adm/v1/roles', body);
    }

    static insertAdminRole(roleNm, roleStatCd, roleDescContent, roleMenu) {
        return $http.post('/adm/v1/role', { role: { roleNm, roleStatCd, roleDescContent }, roleMenus: roleMenu });
    }

    static updateAdminRole(roleId, roleNm, roleStatCd, roleDescContent, roleMenu) {
        return $http.put('/adm/v1/role', { role: { roleId, roleNm, roleStatCd, roleDescContent }, roleMenus: roleMenu });
    }
}

export default AdminRoleRest;
