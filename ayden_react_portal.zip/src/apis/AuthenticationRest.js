import { $http } from 'modules';
import _ from 'lodash';

class AuthenticationRest {
    static login({ id, password, langCode, timezoneDiff }) {
        const body = {
            id,
            password,
            langCd: langCode,
            timeDiff: timezoneDiff
        };
        return $http.post('/adm/v1/auth/login', body);
    }

    static confirmOtp(otp) {
        const body = {
            otpKey: otp
        };
        return $http.post('/adm/v1/auth/otp/confirm', body);
    }

    static logout() {
        return $http.post('/adm/v1/auth/logout');
    }

    static changeTenant(tenantId) {
        if (_.isNil(tenantId)) {
            return Promise.reject();
        }
        return $http.put(`/adm/v1/auth/tenant/${tenantId}`);
    }

    static changeTempPassword(newPassword) {
        return $http.put('/adm/v1/auth/password', { newPassword });
    }
}

export default AuthenticationRest;
