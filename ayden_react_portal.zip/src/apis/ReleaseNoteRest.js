import QueryString from 'query-string';
import { Base64 } from 'js-base64';
import { $http } from '../modules/index';

const prefix = '/common/v1/helpcenter/relnote';

class ReleaseNoteRest {
    static getReleaseNotes(params) {
        const changedParams = params;
        const { keyword } = params;
        if (keyword) changedParams.keyword = Base64.encode(keyword);
        return $http.get(prefix, { params: changedParams });
    }

    static getReleaseNote(relnoteId) {
        return $http.get(`${prefix}/${relnoteId}`);
    }

    static deleteReleaseNotes(relnoteIds) {
        return $http.delete(prefix, { params: { relnoteIds }, paramsSerializer: params => QueryString.stringify(params, { arrayFormat: 'repeat' }) });
    }

    static addReleaseNote(relnote) {
        return $http.post(prefix, relnote);
    }

    static updateReleaseNote(relnote, relnoteId) {
        return $http.put(`${prefix}/${relnoteId}`, relnote);
    }
}

export default ReleaseNoteRest;
