import _ from 'lodash';
import AuthenticationService from 'utils/AuthenticationService';
import SignatureUtil from 'utils/SignatureUtil';
import { $http } from '../modules/index';

class FileRest {
    getManualVersions(params) {
        return $http.get('/drive/v1/file-version/manual', { params });
    }

    uploadManual({ files, langCd, objtId }) {
        const url = '/drive/v1/upload/multipart/manual';
        const formData = new FormData();
        formData.append('tagInfoVal', langCd);
        formData.append('multipartFile', files[0], files[0].name);

        let data = url;
        if (objtId) {
            formData.append('objtId', objtId);
            data = data.concat(objtId);
        }
        data = data.concat(langCd);

        return $http.post('/drive/v1/upload/multipart/manual', formData, {
            headers: {
                'Content-Type': 'multipart/form-data',
                hmac: SignatureUtil.generate(data, AuthenticationService.getSignatureKey())
            }
        });
    }

    downloadManual({ objtId, fileVerSno }) {
        const url = `/drive/v1/file-download/manual-admin/${objtId}`; // admin manual이 아니라 admin 호출용 api임.
        const params = { fileVerSno };
        return $http.get(url, { params, responseType: 'blob' });
    }

    download({ objtId, onpstId, fileVerSno }) {
        const url = `/drive/v1/file-download/${objtId}`;
        const params = _.isNil(fileVerSno) ? { onpstId } : { onpstId, fileVerSno };
        return $http.get(url, { params, responseType: 'blob' });
    }
}

export default new FileRest();
