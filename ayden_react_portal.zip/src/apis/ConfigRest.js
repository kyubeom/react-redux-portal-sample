import { $http } from '../modules/index';

class ConfigRest {
    static retrieveConfigs(type, tenantId) {
        const sanitized = {
            settingDivCd: type,
            coCdVal: tenantId
        };
        return $http.get('/adm/cmm/svrSett/selectSvrSett', { params: sanitized });
    }

    static retreiveConfigList = async () => {
        const response = await $http.get('/auth/v1/configs/cfg');
        const { data } = response;
        return data;
    };
}

export default ConfigRest;
