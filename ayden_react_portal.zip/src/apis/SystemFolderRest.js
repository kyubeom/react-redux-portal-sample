import { $http } from 'src/modules/index';

class SystemFolderRest {
    static getSystemFolders() {
        return $http.get('/drive/v1/folder/system');
    }

    static createSystemFolder(objtNm, size) {
        return $http.post('/drive/v1/folder/system', { objtNm, allocUseSize: String(size) });
    }
}

export default SystemFolderRest;
