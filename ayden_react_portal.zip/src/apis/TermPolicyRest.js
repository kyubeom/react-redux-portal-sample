import _ from 'lodash';
import { $http } from '../modules/index';

class TermPolicyRest {
    static getTermTypeList = async () => {
        const response = await $http.get('/common/v1/codes/5000015');
        const { data } = response;
        _.forEach(data, draft => {
            draft.termsTypeSectCd = draft.codeValidVal;
            draft.text = draft.thCdValidValNm;
        });
        return response;
    };

    static getUserTypeList = async () => {
        const response = await $http.get('/common/v1/codes/2000003');
        const { data } = response;
        _.forEach(data, draft => {
            draft.termsTgtSectCd = draft.codeValidVal;
            draft.text = draft.thCdValidValNm;
        });
        return response;
    };

    static getTermDataList = async params => {
        const response = await $http.get('/common/v1/helpcenter/terms', { params });
        return response;
    };

    static getTermDataDetail = async termsId => {
        const response = await $http.get(`/common/v1/helpcenter/terms/${termsId}`);
        return response;
    };

    static postTermData = async data => {
        const response = await $http.post('/common/v1/helpcenter/terms', data);
        return response;
    };
}

export default TermPolicyRest;
