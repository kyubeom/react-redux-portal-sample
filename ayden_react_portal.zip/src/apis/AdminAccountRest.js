import { isNil, isArray, isEmpty } from 'lodash';
import { $http } from '../modules/index';

class AdminAccountRest {
    select(params) {
        const sanitized = params || {};
        if (isNil(sanitized.limit)) {
            sanitized.limit = 10;
        }
        if (isNil(sanitized.page)) {
            sanitized.page = 1;
        }
        return $http.get('/adm/v1/users', { params: sanitized });
    }

    selectOne({ adminUserId, adminLoginId }) {
        return $http.get('/adm/v1/user', { params: { adminUserId, adminLoginId } }).then(res => res.data);
    }

    initPassword(adminUserId) {
        if (isNil(adminUserId)) {
            return Promise.resolve();
        }
        return $http.put(`/adm/v1/user/${adminUserId}/password/temp`);
    }

    createAdministrator(admin) {
        return $http.post(`/adm/v1/user`, admin);
    }

    changeAdministrator(admin) {
        return $http.put(`/adm/v1/user`, admin);
    }

    changeStatusOfAdministrator(adminUserIds, status) {
        return $http.put(`/adm/v1/users/${status}`, adminUserIds);
    }

    changeAdministrators(administrators) {
        if (isEmpty(administrators)) {
            return Promise.reject();
        }
        return $http.put(`/adm/v1/users`, administrators);
    }

    removeAdministrator(adminUserIds) {
        if (!isArray(adminUserIds)) {
            return Promise.reject();
        }
        return $http.delete(`/adm/v1/users`, { data: adminUserIds });
    }
}

export default new AdminAccountRest();
