import _ from 'lodash';
import { STATUS as NETWORK_STATUS, STATUS } from 'constants/Network';
import $http from '../modules/Http';

class NetworkRest {
    constructor() {
        this.parsingMapForWhetherUseByStatus = {};
        this.parsingMapForWhetherUseByStatus[STATUS.ACTIVE] = 'Y';
        this.parsingMapForWhetherUseByStatus[STATUS.INACTIVE] = 'N';
    }

    refineForServer(network = {}) {
        return {
            ipId: network.id,
            ipNm: network.name,
            startIpAddr: network.startIp,
            endIpAddr: network.endIp,
            useYn: network.status === NETWORK_STATUS.ACTIVE ? 'Y' : 'N',
            tenantId: network.tenantId
        };
    }

    sanitize(network = {}) {
        return {
            id: network.ipId,
            name: network.ipNm,
            startIp: network.startIpAddr,
            endIp: network.endIpAddr,
            tenantId: network.tenantId,
            status: network.useYn === 'Y' ? STATUS.ACTIVE : STATUS.INACTIVE
        };
    }

    retrieve(params = {}) {
        const data = {
            comNm: params.name,
            useYn: _.get(this.parsingMapForWhetherUseByStatus, params.status),
            startIpAddr: params.startIp,
            endIpAddr: params.endIp,
            limit: params.limit || 20,
            page: params.page || 0
        };
        return $http.get('/auth/v1/network', { params: data }).then(res => {
            const { list, total } = res.data;
            const sanitized = list.map(this.sanitize);
            return { list: sanitized, total };
        });
    }

    retrieveAll() {
        return $http.get('/auth/v1/network/all').then(res => res.data);
    }

    create({ name, startIp, endIp, status }) {
        const data = { ipNm: name, startIpAddr: startIp, endIpAddr: endIp, useYn: _.get(this.parsingMapForWhetherUseByStatus, status) };
        return $http.post('/auth/v1/network', data);
    }

    update(networks) {
        if (_.isEmpty(networks)) {
            return Promise.reject();
        }
        return $http.put('/auth/v1/network', networks.map(this.refineForServer));
    }

    remove(networkIds = []) {
        return $http.delete('/auth/v1/network', { data: networkIds });
    }

    changeStatus({ networkIds, status }) {
        if (_.isNil(status)) {
            return Promise.reject();
        }
        const use = _.get(this.parsingMapForWhetherUseByStatus, status);
        return $http.put(`/auth/v1/network/use/${use}`, networkIds);
    }

    checkDuplicateName(name) {
        return $http.get('/auth/v1/network/duplicate/name', { params: { ipName: name } }).then(res => res.data);
    }

    checkDuplicateIp(start, end, networkId) {
        return $http.get('/auth/v1/network/duplicate/ip', { params: { startIp: start, endIp: end, ipId: networkId } }).then(res => res.data);
    }
}

export default new NetworkRest();
