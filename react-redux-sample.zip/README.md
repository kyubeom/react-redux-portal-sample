# Admin webapp

Admin Portal React Project

- [Install](#install)
- [Start](#start)
- [Build](#build)
- [Es-lint](#es-lint)
- [Naming Convention](#naming)
- [Folder Structure](#structure)
- [HOC](#hoc)
- [Redux](#redux)

## <a name='installation'>Installation</a>

    Using [npm](https://www.npmjs.com/):
    $ npm install
    
## <a name='start'>Start server</a>
    $ npm start
    
## <a name='build'>Build</a>
mode : development + (es-lint)

    $ npm run dev

mode : production
 
    $ npm run build

## <a name='es-lint'>Es-Lint</a>
    $ npm run lint
    config file : root 경로의 .eslintrc.json
    report path : build 후 dist folder
    file format : eslint-report-xxx.html

## <a name='naming'>Naming Convention</a>

    Folder Naming: Lower case
    File Naming: Pascal Case

## <a name='structure'>Folder Structure</a>

최상단 업무영역

    state : 전역상태관리 > redux
    common : 공통영역, to share hoc,api,utils,constants,rest,service.
    components : 컴포넌트 목록


업무 폴더 내부 구조

    state
    ㄴ auth
        index.js
    ㄴ locale
        index.js
    common
    ㄴ views
        DatePickers.js
    ㄴ hoc
    ㄴ service
    ㄴ rest
    components
    ㄴ layout
        ㄴgnb
            Gnb.jsx
    ㄴ login
    ㄴ userAccount
    ㄴ dialog
        ㄴviews : 다섯개 이상 js파일이 생기면 폴더를 따로 추가


폴더내부파일 네이밍

    * : 폴더이름과 동일
    *.jsx : 상태가 관리되는 컨테이너 컴포넌트 (css, i18n 포함)
    *.scss|css : style정의
    i18n.json : 다국어 리소스
    *Rest : rest api 호출을 위한 함수
    *Service : 업무 내 유틸성,공통성 메서드 모음
    views : 순수 표현 컴포넌트 폴더


## <a name='hoc'>HOC</a>

withI18n : 다국어 고차컴포넌트 
 
    withI18n( component, resourceJson );
    - this.props.i18n.t('message key');
 
withDialog : 다이얼로그 지원 고차컴포넌트

    withDIalog( component );
    - this.props.dialog.alert( 'message key'  , option = {} )
      : options 
        {
          okAction : (function)
        }
    - this.props.dialog.comfirm( 'message key'  , option = {} )
      : options 
        {
          okAction : (function),
          cancelAction : (function)
        }

withAdminCommonHOC

 : 공통적으로 화면에 쓰이는 고차컴포넌트를 한꺼번에 수행
   현재는 i18n, dialog 포함
   
    withAdminCommonHOC( component, resourceJson );
   
## <a name='redux'>[Redux - mapDispatchToPros method classfication naming]</a>

redux 라는 네이밍의 object로 한번 감싸서 정의하여 사용

example :

    const mapDispatchToProps = dispatch => ({
        redux : {
            activeSession(session){
                dispatch(activeSession(session));
            },
            changeLanguage(language){
                dispatch(changeLanguage(language));
            },
            changeTimezone(timezone){
                dispatch(changeTimezone(timezone));
            }
        }
    });
    
    export default connect(mapStateToProps, mapDispatchToProps)(Login);
    
     
    
    constructor(props){
      super(props);
      
    }
    
    changeTimezone(){
      this.props.redux.changeTimezone({~});
    }

