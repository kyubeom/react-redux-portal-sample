const webpack = require('webpack');
const merge = require('webpack-merge');
const common = require('./webpack.config.js');
const UglifyJSPlugin = require('uglifyjs-webpack-plugin');

const publicPath = '/adminweb/';
const mode = 'production';


//const path = require('path');

module.exports = merge(common, {
    output: {
        publicPath: publicPath
    },
    mode: mode,
    devtool: 'source-map',
    plugins: [
       new UglifyJSPlugin({sourceMap: true}),
       new webpack.DefinePlugin({
           "process.env": {
               NODE_ENV: JSON.stringify(mode),
               ROUTER_BASENAME: JSON.stringify(publicPath)
           }
       })
    ],
    //devServer: {
    //    contentBase: path.join(__dirname, "./dist"),
    //    compress: true,
    //    port: 9000,
    //    hot: true,
    //    historyApiFallback: true,
    //    proxy: {
    //        "/adm": "http://182.193.17.35"
    //    }
    //}
});