const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');
const path = require('path');
const LodashModuleReplacementPlugin = require('lodash-webpack-plugin');

const DIST_PATH = './dist';
const SRC_PATH = './src';
const ROOT_PATH = SRC_PATH + '/app';

const entry = {
    "babel-polyfill": "babel-polyfill",
    'vendors': ['react', 'react-dom', 'react-router-dom', 'prop-types', 'js-cookie', 'redux', 'react-redux'],
    'app': path.resolve(__dirname, SRC_PATH + '/app/index.jsx')
};


const output = {
    path: path.resolve(__dirname, DIST_PATH),
    chunkFilename: '[name]-[chunkhash:8].js',
    publicPath: '/'
};


const modules = {
    noParse: /moment|jquery/,
    rules: [
        {
            test: /\.(jsx|js)$/,
            loader: 'babel-loader',
            options: {
                presets: [
                    'react', 'stage-3'
                ],
                plugins: [
                    'syntax-dynamic-import',
                    'lodash',
                    ['module-resolver',
                        {
                            'root': [ROOT_PATH],
                            'alias': {'~': ROOT_PATH}
                        }
                    ]
                ]
            },
            exclude: ['/node_modules']
        },
        {
            test: /\.(scss|css)$/,
            use: [
                "style-loader",
                {
                    loader: "css-loader",
                    options: {
                        importLoaders: 1,
                        modules: true,
                        localIdentName: '[path][name]__[local]--[hash:base64:5]'
                    }
                },
                "sass-loader"
            ],
            include: [
                path.resolve(__dirname, "src/app/components/login"),
                path.resolve(__dirname, "src/app/components/wrapper"),
            ],
        },
        {
            test: /\.(scss|css)$/,
            use: [
                "style-loader",
                "css-loader",
                "sass-loader"
            ],
            exclude: [
                path.resolve(__dirname, "src/app/components/login"),
                path.resolve(__dirname, "src/app/components/wrapper"),
            ],
        },
        {
            test: /\.(png|jpg|gif)$/,
            use: {
                loader: 'url-loader?publicPath=assets/images',
                options: {
                    limit: 10000,
                    outputPath: 'assets/images',
                    name: '[name]_[hash].[ext]'
                }
            },
            exclude: /node_modules/
        },
        {
            test: /\.(ttf|eot|svg|woff(2)?)(\?[a-z0-9]+)?$/,
            loader: 'file-loader',
        }
    ]
};

const plugins = [
    new CleanWebpackPlugin([DIST_PATH]),
    new LodashModuleReplacementPlugin({
        paths: true,
        caching: true,
        cloning: true,
        memoizing: true
    }),
    new webpack.IgnorePlugin(/^\.\/locale$/, /moment$/),
    new HtmlWebpackPlugin({
        template: path.join(__dirname, SRC_PATH+'/app/index.html'),
        favicon: path.join(__dirname, SRC_PATH+'/assets/images/favicon.ico'),
        inject: true,
        filename: path.join(__dirname, DIST_PATH+'/index.html')
    })
];


const optimization = {
    splitChunks: {
        cacheGroups: {
            commons: {
                name: 'vendors',
                chunks: "initial",
                minChunks: 2
            }
        }
    },
    sideEffects: false
};

const resolve = {
    extensions: ['.js', '.jsx']
};

const config = {
    entry: entry,
    output: output,
    module: modules,
    plugins: plugins,
    resolve: resolve,
    optimization: optimization
};

module.exports = config;
