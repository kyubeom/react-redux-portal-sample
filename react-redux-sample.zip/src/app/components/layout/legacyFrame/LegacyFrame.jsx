import React from 'react';
import PropTypes from 'prop-types';
import { split, get } from 'lodash';

const LegacyFrame = props => {
    const { location, langCd } = props;
    const uri = get(split(location.search, '=/'), 1);
    let iframeUrl = `/adm/apmain/index.jsp#${uri}/?t=${Date.now()}&langCd=${langCd}&iframeCallFromRenew`;
    if (window.location.hostname === 'localhost') {
        iframeUrl = `http://182.193.17.35${iframeUrl}`;
        // iframeUrl = `http://localhost:8081${iframeUrl}`;
    }
    return (
        <iframe src={iframeUrl} title="legacyAdminPage" width="100%" height="100%" />
    );
};

export default LegacyFrame;

LegacyFrame.propTypes = {
    location: PropTypes.object.isRequired,
    langCd: PropTypes.string
};

LegacyFrame.defaultProps = {
    langCd: 'ko'
};
