import React, { Component } from 'react';
import { HashRouter, Route, Switch, Redirect } from 'react-router-dom';
import { connect } from 'react-redux';
import Cookies from 'js-cookie';
import { isNil, split, get as _get, isEmpty } from 'lodash';
import PropTypes from 'prop-types';

import Home from './Home';
import Login from '../login/Login';

/* eslint-disable import/no-unresolved */
import { BrandRest, BrandService } from '~/common/service/brand';
import { sessionOperations } from '~/state/session';
import { localeOperations } from '~/state/locale';
import LegacyService from '~/common/service/LegacyService';
import SessionConstant from '~/common/utils/SessionConstant';
/* eslint-disable import/no-unresolved */

import '../../../styles';


const setBrand = () => {
    BrandRest.retrieveName().then(name => {
        const brandName = `${name} Admin`;
        LegacyService.setBrandNameAtCookie(brandName);
        BrandService.setBrandNameAyDocumentTitle(brandName);
    });
};

const activateWebAppSessionIfHasAdminSessionCookie = operations => {
    operations.verifyingSession();
    const session = Cookies.get(SessionConstant.SESSION_COOKIE_NAME);
    if (session !== undefined && session !== null) {
        const parsed = JSON.parse(session);
        operations.changeLanguage(parsed.locale.language);
        operations.changeTimezone(parsed.locale.timezone);
        operations.activeSession(parsed);
    } else {
        operations.removeSession();
    }
};


const initApp = operations => {
    activateWebAppSessionIfHasAdminSessionCookie(operations);
    setBrand();
};


class App extends Component {

    componentDidMount() {
        const { redux } = this.props;
        initApp(redux);
    }

    render() {
        const { sessionState } = this.props;
        if (isNil(sessionState) || sessionState === SessionConstant.SESSION_STATE.CHECKING) {
            return (<React.Fragment />);
        }

        let to = '/user-account';
        if (sessionState === SessionConstant.SESSION_STATE.ACTIVE) {
            const currentHash = _get(split(window.location.hash, '#/'), 1);
            to = isEmpty(currentHash) || currentHash === 'login' ? to : currentHash;
        }

        return (
            <HashRouter>
                <React.Fragment>
                    <Switch>
                        <Route path="/login" component={Login} {...this.props} />
                        <Route path="/" component={Home} {...this.props} />
                    </Switch>
                    { sessionState === SessionConstant.SESSION_STATE.ACTIVE && (<Redirect push={true} to={to} />) }
                    { sessionState === SessionConstant.SESSION_STATE.NONE && (<Redirect push={true} to="/login" />) }
                </React.Fragment>
            </HashRouter>
        );
    }

}


const mapStateToProps = state => ({
    sessionState: state.session.state
});

const mapDispatchToProps = dispatch => ({
    redux: {
        activeSession(session) {
            dispatch(sessionOperations.activeSession(session));
        },
        changeLanguage(lang) {
            dispatch(localeOperations.changeLanguage(lang));
        },
        changeTimezone(zone) {
            dispatch(localeOperations.changeTimezone(zone));
        },
        verifyingSession() {
            dispatch(sessionOperations.verifyingSession());
        },
        removeSession() {
            dispatch(sessionOperations.removeSession());
        }
    }
});

export default connect(mapStateToProps, mapDispatchToProps)(App);

App.propTypes = {
    sessionState: PropTypes.string
};

App.defaultProps = {
    sessionState: ''
};
