import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { Route, withRouter } from 'react-router-dom';

import Gnb from './header/Gnb';
import Lnb from './navigation/Lnb';
import LegacyFrame from './legacyFrame/LegacyFrame';
import { UserAccount } from '..';

/* eslint-disable import/no-unresolved */
import Loading from '~/common/views/Loading';
/* eslint-disable import/no-unresolved */

import './Home.scss';
import './Content_common.scss';

const Home = props => {
    const { language, location, history, loading } = props;
    const bsClass = location.pathname === '/legacy_frame' ? 'legacy' : 'content_wrap';
    return (
        <div className="home">
            <Lnb history={history} />
            <header>
                <Gnb />
            </header>
            <section>
                <main className={bsClass}>
                    <Route exact={true} path="/user-account" component={UserAccount} />
                    <Route path="/legacy_frame" render={() => <LegacyFrame location={location} langCd={language.key} />} />
                </main>
                <Loading isLoading={loading.going} />
            </section>
        </div>
    );
};

const mapStateToProps = state => ({
    language: state.locale.language,
    loading: state.loading
});

const connected = connect(mapStateToProps, null)(Home);
const HomeHoc = withRouter(connected);

export default HomeHoc;

Home.propTypes = {
    history: PropTypes.object.isRequired,
    location: PropTypes.object.isRequired,
    language: PropTypes.object,
    loading: PropTypes.object,
};

Home.defaultProps = {
    language: {},
    loading: {}
};
