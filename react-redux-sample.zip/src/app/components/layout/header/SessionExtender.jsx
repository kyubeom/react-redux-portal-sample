import React from 'react';
import PropTypes from 'prop-types';
import { NavItem, Button } from 'react-bootstrap';
import Timer from '../../../common/views/Timer';


const SessionExtender = props => {
    const { i18n, operatingTime, extendSession, removeSession, initTimer } = props;

    return (
        <NavItem className="default_cursor" href="#">
            { i18n.t('gnb.session.remainingTime') }
            {' '}
            <Timer
                operatingTime={operatingTime}
                whenTimeZeroFunction={removeSession}
                className="gnbTimer"
                initTimer={initTimer} />
            {' '}
            <Button className="extendBtn" bsSize="xsmall" onClick={extendSession}>
                { i18n.t('gnb.session.extend') }
            </Button>
        </NavItem>
    );
};


export default SessionExtender;

SessionExtender.propTypes = {
    operatingTime: PropTypes.oneOfType([
        PropTypes.number,
        PropTypes.object
    ]),
    extendSession: PropTypes.func.isRequired,
    removeSession: PropTypes.func.isRequired,
    initTimer: PropTypes.bool
};

SessionExtender.defaultProps = {
    operatingTime: 3600,
    initTimer: false
};
