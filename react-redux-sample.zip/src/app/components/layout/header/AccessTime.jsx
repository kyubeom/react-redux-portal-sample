import React from 'react';
import { get as _get } from 'lodash';
import { NavItem } from 'react-bootstrap';
import PropTypes from 'prop-types';

const AccessTime = props => {
    const { i18n, session, timezone, } = props;
    return (
        <NavItem className="default_cursor" href="#">
            { i18n.t('gnb.last.accessTime') }
            {' '}
            { _get(session, 'access.dateTime') }
            {' '}
            { _get(timezone, 'timezone.name') }
        </NavItem>
    );
};

export default AccessTime;

AccessTime.propTypes = {
    session: PropTypes.object.isRequired,
    timezone: PropTypes.object.isRequired,
};
