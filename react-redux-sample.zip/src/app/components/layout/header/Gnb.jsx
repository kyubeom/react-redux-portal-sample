import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Navbar, Nav, NavDropdown, MenuItem } from 'react-bootstrap';
import { get as _get, isEmpty as _isEmpty, isArray as _isArray } from 'lodash';
import PropTypes from 'prop-types';

import './Gnb.scss';

/* eslint-disable import/no-unresolved */
import { sessionOperations } from '~/state/session';
import withAdminCommonHOC from '~/common/hoc/AdminCommonHOC';
import { AuthenticationRest, AuthenticationService } from '~/common/service/auth';
import LegacyService from '~/common/service/LegacyService';
/* eslint-disable import/no-unresolved */

import GnbRest from './GnbRest';
import AccessTime from './AccessTime';
import SessionExtender from './SessionExtender';
import SelectCompany from './SelectCompany';
import ChangePassword from '../../popup/password/ChangePassword';
import i18nResource from './i18n.json';

class Gnb extends Component {

    constructor(props) {
        super(props);
        this.handleSelect = this.handleSelect.bind(this);
        this.changeCompany = this.changeCompany.bind(this);
        this.extendSession = this.extendSession.bind(this);
        this.closeChangePassword = this.closeChangePassword.bind(this);

        this.state = {
            companyList: [],
            coCdVal: '',
            session: {},
            timezone: {},
            openDialogForChangePassword: false,
            initTimer: false
        };
        this.i18n = props.i18n;
        this.redux = props.redux;
        this.dialog = props.dialog;
        this.operatingTime = 3600;

        LegacyService.addApiCallEventListener(e => {
            if (e.data === 'admin-api-call-in-legacy') {
                this.setState({ initTimer: true });
            }
        });
    }


    componentDidMount() {
        this.doneMounted = true;
        Promise.all([GnbRest.getCompanyList(), GnbRest.getManualUrl(), GnbRest.getAdminTimeoutValue()])
            .then(values => {
                const companyList = values[0];
                const manualUrl = values[1];
                const adminTimeoutValue = values[2] * 60; // 분 기준으로 초로 바꿔줌
                if (this.doneMounted) {
                    this.setState({ companyList });
                    this.operatingTime = Number(adminTimeoutValue);
                    this.manualUrl = manualUrl;
                }
            });
    }

    componentWillUnmount() {
        this.doneMounted = false;
    }

    static getDerivedStateFromProps(nextProps, prevStatus) {
        const state = {};

        if (!_isEmpty(nextProps.session) && nextProps.session.authToken !== prevStatus.session.authToken) {
            state.session = nextProps.session;
        }

        if (!_isEmpty(nextProps.timezone) && nextProps.timezone.code !== prevStatus.timezone.code) {
            state.timezone = nextProps.timezone;
        }

        if (!_isEmpty(nextProps.session) && _get(nextProps.session, 'adminUser.tenantId') !== prevStatus.coCdVal) {
            state.coCdVal = _get(nextProps.session, 'adminUser.tenantId');
        }

        if (!_isEmpty(state)) {
            return state;
        }

        return null;
    }

    handleSelect(eventKey) {
        switch (eventKey) {
        case 'changePassword': this.openChangePassword(); break;
        case 'goToManualSite': this.openManual(); break;
        case 'logout': this.logout(); break;
        default: break;
        }
    }

    openChangePassword() {
        this.setState({ openDialogForChangePassword: true });
    }

    closeChangePassword() {
        this.setState({ openDialogForChangePassword: false });
    }

    openManual() {
        window.open(this.manualUrl, '_blank');
    }

    logout() {
        const okAction = () => {
            AuthenticationRest.logout();
            AuthenticationService.removeWebappSession().then(() => {
                this.redux.removeSession();
            });
        };

        this.dialog.confirm(this.i18n.t('gnb.admin.menu.logout.message'), { okAction });
    }

    changeCompany(tenantId) {
        this.redux.changeSessionTenent(tenantId);
        AuthenticationService.changeTenantInCookie(tenantId).then(() => {
            window.location.reload();
        });
    }

    extendSession() {
        // 세션 연장용으로 api 호출
        GnbRest.getAdminTimeoutValue();
        this.setState({ initTimer: true });
    }

    render() {
        const { i18n, extendSession, handleSelect, closeChangePassword, operatingTime } = this;
        const { companyList, session, timezone, openDialogForChangePassword, initTimer } = this.state;
        const { removeSession } = this.redux;
        const loginId = _get(session, 'adminUser.loginId', '');

        return (
            <Navbar className="gnb">
                <Nav pullRight={true} onSelect={handleSelect}>
                    { _isArray(companyList) && <SelectCompany {...this.state} changeCompany={this.changeCompany} /> }
                    <AccessTime i18n={i18n} session={session} timezone={timezone} />
                    <SessionExtender i18n={i18n} operatingTime={operatingTime} extendSession={extendSession} removeSession={removeSession} initTimer={initTimer} />
                    <NavDropdown title={loginId} id="basic-nav-dropdown1">
                        <MenuItem eventKey="changePassword">
                            {i18n.t('gnb.admin.menu.changePassword')}
                        </MenuItem>
                        <MenuItem eventKey="goToManualSite">
                            {i18n.t('gnb.admin.menu.manual')}
                        </MenuItem>
                        <MenuItem eventKey="logout">
                            {i18n.t('gnb.admin.menu.logout')}
                        </MenuItem>
                    </NavDropdown>
                </Nav>
                <ChangePassword
                    openDialogForChangePassword={openDialogForChangePassword}
                    cancelAction={closeChangePassword} />
            </Navbar>
        );
    }

}

const mapDispatchToProps = dispatch => ({
    redux: {
        removeSession(session) {
            dispatch(sessionOperations.removeSession(session));
        },
        changeSessionTenent(session, id) {
            dispatch(sessionOperations.changeSessionTenent(session, id));
        }
    }
});

const mapStateToProps = state => ({
    session: state.session,
    timezone: state.locale.timezone
});

const connected = connect(mapStateToProps, mapDispatchToProps)(Gnb);
const GnbWithHOC = withRouter(withAdminCommonHOC(connected, i18nResource));

export default GnbWithHOC;

Gnb.propTypes = {
    history: PropTypes.object.isRequired,
};
