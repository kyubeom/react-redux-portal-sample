import React, { Component } from 'react';

import { MenuItem, NavDropdown } from 'react-bootstrap';
import PropTypes from 'prop-types';


class SelectCompany extends Component {

    constructor(props) {
        super(props);
        const { changeCompany } = props;
        this.changeCompany = changeCompany;
        this.changeCompanyEvent = this.changeCompanyEvent.bind(this);
    }

    shouldComponentUpdate(nextProps) {
        const { companyList, coCdVal } = nextProps;
        if (companyList !== this.companyList) {
            return true;
        }

        if (coCdVal !== this.coCdVal) {
            return true;
        }

        return false;
    }

    changeCompanyEvent(coCdVal) {
        this.changeCompany(coCdVal);
    }

    render() {
        let selectedCompanyName = '';
        const { companyList, coCdVal } = this.props;

        const companyListItem = companyList.map(company => {
            if (company.coCdVal === coCdVal) {
                selectedCompanyName = company.coNm;
                return (
                    <MenuItem key={company.coCdVal} eventKey={company.coCdVal} active={true}>
                        {company.coNm}
                    </MenuItem>
                );
            }

            return (
                <MenuItem key={company.coCdVal} eventKey={company.coCdVal}>
                    {company.coNm}
                </MenuItem>
            );
        });

        return (
            <NavDropdown title={selectedCompanyName} id="nav-dropdown" bsClass="dropdown" onSelect={k => this.changeCompanyEvent(k)}>
                {companyListItem}
            </NavDropdown>
        );
    }

}

SelectCompany.propTypes = {
    changeCompany: PropTypes.func.isRequired,
    companyList: PropTypes.array.isRequired,
    coCdVal: PropTypes.string.isRequired,
};

export default SelectCompany;
