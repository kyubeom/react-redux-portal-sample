import { $http } from '../../../common/index';

class GnbRest {

    static getCompanyList() {
        return $http.get('/adm/cmm/apmain/selectCompanyList');
    }

    static getManualUrl() {
        return $http.get('/adm/cmm/svrSett/selectAdminManualURL');
    }

    static getAdminTimeoutValue() {
        return $http.get('/adm/cmm/svrSett/selectAdminTimeoutVal');
    }

}

export default GnbRest;
