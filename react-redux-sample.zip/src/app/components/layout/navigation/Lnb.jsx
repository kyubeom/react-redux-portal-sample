import React, { Component } from 'react';
import CustomScroll from 'react-custom-scroll';
import $ from 'jquery';
import PropTypes from 'prop-types';

import './Lnb.scss';
import '../../../../assets/js/scroll';
import '../../../../styles/scroll.css';

import LnbBrandImage from './views/LnbBrandImage';
import Category from './views/Category/Category';
import LnbService from './LnbService';

class Lnb extends Component {

    constructor(props) {
        super(props);
        this.state = { categoryList: [] };
        this.selectSubCategory = this.selectSubCategory.bind(this);
        this.clickCategory = this.clickCategory.bind(this);
        this.currentCategoryId = '';
    }

    componentDidMount() {
        this.isComponentMounted = true;

        LnbService.retrieveCategoryList().then(categoryList => {
            if (this.isComponentMounted) {
                this.setState({ categoryList });
            }
        });
    }

    componentWillUnmount() {
        this.isComponentMounted = false;
    }

    selectSubCategory(route) {
        this.setState({ selectedId: route.id });
        const { history } = this.props;
        const url = route.type === 'iframe' ? `/legacy_frame?url=${route.url}` : route.url;
        history.push(url);
    }

    clickCategory(event, id) {
        // 열려있는 submenu들을 닫음
        $('.sub-category-group').css({ height: '0px' });
        const $target = $(event.currentTarget);
        const $parent = $target.parent();
        const $submenuWrap = $target.next();

        if ($submenuWrap.outerHeight() === 0) {
            const $submenuListWrap = $submenuWrap.children();
            const submenuItemHeight = $submenuListWrap.eq(0).outerHeight();
            $submenuWrap.css({ height: submenuItemHeight * $submenuListWrap.length });
        }

        if (this.currentCategoryId !== id) {
            $parent.siblings().removeClass('active');
            $parent.toggleClass('active');
            this.currentCategoryId = id;
        }
    }

    render() {
        const { categoryList, selectedId } = this.state;
        const { selectSubCategory, clickCategory } = this;
        const props = {
            selectSubCategory,
            clickCategory,
            selectedId
        };

        return (
            <div className="lnb">
                <CustomScroll flex="1" heightRelativeToParent="100vh">
                    <LnbBrandImage />
                    <div className="categoryWrap">
                        {
                            categoryList.map(category => <Category key={category.id} category={category} {...props} />)
                        }
                    </div>
                </CustomScroll>
            </div>
        );
    }

}

export default Lnb;

Lnb.propTypes = {
    history: PropTypes.object.isRequired
};
