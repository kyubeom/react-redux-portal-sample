import { $http } from '../../../common/index';

class LnbRest {

    static getSubCategoryList() {
        return $http.post('/adm/cmm/apmain/selectAdminMenu');
    }

    static getCategoryList() {
        return $http.get('/adm/cmm/apmain/selectListMnu');
    }

}

export default LnbRest;
