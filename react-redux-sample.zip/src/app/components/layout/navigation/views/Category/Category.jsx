import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { ListGroup } from 'react-bootstrap';

import i18nResource from './i18n.json';

/* eslint-disable import/no-unresolved */
import { withI18n } from '~/common/hoc/index';
/* eslint-disable import/no-unresolved */

import './Category.scss';
import SubCategory from '../SubCategory/SubCategory';

class Category extends Component {

    constructor(props) {
        super(props);
        this.i18n = props.i18n;
    }

    render() {
        const { category, selectedId, clickCategory, selectSubCategory } = this.props;
        const lnbCategoryIcon = `${category.imageClass} whiteImage`;
        const menuClass = selectedId === category.id ? 'selected' : '';

        return (
            <div className="category">
                <div className={menuClass} onClick={e => clickCategory(e, category.id)} role="menuitem" tabIndex={category.index}>
                    <div className={lnbCategoryIcon} aria-hidden="true" />
                    <div className="glyphicon glyphicon-menu-down whiteImage rightAsign" aria-hidden="true" />
                    <div className="text">
                        { this.i18n.t(category.title) }
                    </div>
                </div>

                <ListGroup bsClass="sub-category-group list-group">
                    {
                        category.sub.map(sub => <SubCategory key={sub.id} item={sub} i18n={this.i18n} selectSubCategory={selectSubCategory} selectedId={selectedId} />)
                    }
                </ListGroup>

            </div>
        );
    }

}

Category.propTypes = {
    selectedId: PropTypes.string,
    clickCategory: PropTypes.func.isRequired,
    selectSubCategory: PropTypes.func.isRequired,
    category: PropTypes.object.isRequired,
};

Category.defaultProps = {
    selectedId: '',
};

export default withI18n(Category, i18nResource);
