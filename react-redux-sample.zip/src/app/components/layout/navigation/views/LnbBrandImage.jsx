import React from 'react';

import '../Lnb.scss';

const LnbBrandImage = () => {
    const labelName = 'EDM 2.0';

    return (
        <div className="brand">
            {labelName}
        </div>
    );
};

export default LnbBrandImage;
