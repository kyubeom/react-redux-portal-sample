import React from 'react';
import PropTypes from 'prop-types';
import { ListGroupItem } from 'react-bootstrap';
import './SubCategory.scss';

const SubCategory = props => {
    const { item, selectedId, i18n, selectSubCategory } = props;
    const subCategoryDefaultCss = 'sub-category';
    const listGroupItemClass = `${subCategoryDefaultCss} ${(item.id === selectedId ? 'selected list-group-item' : 'list-group-item')}`;
    return (
        <ListGroupItem
            bsClass={listGroupItemClass}
            key={item.id}
            onClick={() => selectSubCategory(item.route)}>
            <p className="text">
                {i18n.t(item.title)}
            </p>
        </ListGroupItem>
    );
};

SubCategory.propTypes = {
    item: PropTypes.object.isRequired,
    selectedId: PropTypes.string,
    selectSubCategory: PropTypes.func.isRequired
};

SubCategory.defaultProps = {
    selectedId: ''
};

export default SubCategory;
