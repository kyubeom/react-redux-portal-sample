const UPPER_MENU_OPTIONS = {
    'Account': { css: 'glyphicon glyphicon-user', title: 'lnb.category.account' },
    'Workspace': { css: 'fa fa-home', title: 'lnb.category.worksapce' },
    'Monitoring': { css: 'fa fa-edit', title: 'lnb.category.monitoring' },
    'Business Operations': { css: 'fa fa-desktop', title: 'lnb.category.business-perations' },
    'Tenant Settings': { css: 'fa fa-table', title: 'lnb.category.tenent-settings' },
    'Restriction Maintenance': { css: 'fa fa-check-square', title: 'lnb.category.restriction-maintenance' },
    'Admin Console': { css: 'fa fa-clone', title: 'lnb.category.admin-console' },
    'System Administration': { css: 'fa fa-cog', title: 'lnb.category.system-manage' }
};


const SUB_MENU_OPTIONS = {
    // account
    '/act_user': { title: 'sub.lnb.category.user', type: '', url: '/user-account' },
    '/act_auditory': { title: 'sub.lnb.category.auditory', type: 'iframe' },
    '/act_subcontractor': { title: 'sub.lnb.category.partner', type: 'iframe' },

    // worksapce
    '/wks_user': { title: 'sub.lnb.category.member', type: 'iframe' },
    '/wks_file': { title: 'sub.lnb.category.file-folder', type: 'iframe' },
    '/wks_post': { title: 'sub.lnb.category.post', type: 'iframe' },

    // monitoring
    '/mon_user': { title: 'sub.lnb.category.monitoring-user', type: 'iframe' },
    '/mon_post': { title: 'sub.lnb.category.monitoring-post', type: 'iframe' },
    '/mon_str_rpt': { title: 'sub.lnb.category.actual-storage-usage', type: 'iframe' },
    '/mon_str_usage': { title: 'sub.lnb.category.personal-storage-usage-rage', type: 'iframe' },
    '/mon_batch': { title: 'sub.lnb.category.batch-job', type: 'iframe' },
    '/mon_takeover': { title: 'sub.lnb.category.managed-file', type: 'iframe' },
    '/mon_batch_log': { title: 'sub.lnb.category.batch-job-histroy', type: 'iframe' },
    '/mon_billing': { title: 'sub.lnb.category.billing', type: 'iframe' },
    '/mon_wks_activity': { title: 'sub.lnb.category.workspace-activity', type: 'iframe' },
    '/mon_app_log': { title: 'sub.lnb.category.mobile-app-log', type: 'iframe' },
    '/mon_file': { title: 'sub.lnb.category.compliance-violated', type: 'iframe' },
    '/mon_policy_exception': { title: 'sub.lnb.category.policy-exception-management', type: 'iframe' },
    '/mon_stat_removedphyfile': { title: 'sub.lnb.category.pysical-file-deletion-history', type: 'iframe' },
    '/public_link': { title: 'sub.lnb.category.public-link-history', type: 'iframe' },

    // business-perations
    '/mon_announcement': { title: 'sub.lnb.category.announcement', type: 'iframe' },
    '/mon_qna': { title: 'sub.lnb.category.qna', type: 'iframe' },
    '/mon_releasenotes': { title: 'sub.lnb.category.release-notes', type: 'iframe' },
    '/mon_banned_word': { title: 'sub.lnb.category.banned_word', type: 'iframe' },
    '/cfg_faq': { title: 'sub.lnb.category.faq', type: 'iframe' },
    '/cfg_helpcenter': { title: 'sub.lnb.category.helpcenter-file', type: 'iframe' },
    '/cfg_terms': { title: 'sub.lnb.category.terms-policy', type: 'iframe' },

    // tenent-settings
    '/cfg_set': { title: 'sub.lnb.category.configuration', type: 'iframe' },
    '/cfg_extension': { title: 'sub.lnb.category.file-extension-maintenance', type: 'iframe' },
    '/cfg_access_policy': { title: 'sub.lnb.category.system-access-policy', type: 'iframe' },
    '/cfg_network': { title: 'sub.lnb.category.network-definition', type: 'iframe' },
    '/cfg_policy': { title: 'sub.lnb.category.file-extension-maintenance', type: 'iframe' },
    '/cfg_logevent': { title: 'sub.lnb.category.log-event-maintenance', type: 'iframe' },
    '/cfg_code': { title: 'sub.lnb.category.code-maintenance', type: 'iframe' },
    '/cfg_interface': { title: 'sub.lnb.category.interface-maintenance', type: 'iframe' },
    '/cfg_batch_management': { title: 'sub.lnb.category.batch-job-maintenance', type: 'iframe' },
    '/cfg_version': { title: 'sub.lnb.category.version-maintenance', type: 'iframe' },

    // restriction-maintenance
    '/rst_myspace': { title: 'sub.lnb.category.myspace', type: 'iframe' },
    '/rst_sharepoint': { title: 'sub.lnb.category.sharepoint', type: 'iframe' },
    '/rst_mobile': { title: 'sub.lnb.category.mobile-app-external-access', type: 'iframe' },
    '/rst_post_approval': { title: 'sub.lnb.category.post-approvement-file', type: 'iframe' },
    '/rst_exclude_file': { title: 'sub.lnb.category.exclude-search-file', type: 'iframe' },
    '/rst_fileviewer': { title: 'sub.lnb.category.file-viewer', type: 'iframe' },
    '/rst_user_tempauth': { title: 'sub.lnb.category.file-temporary-auth', type: 'iframe' },

    // admin-console
    '/adm_acct': { title: 'sub.lnb.category.adm-account', type: 'iframe' },
    '/adm_role': { title: 'sub.lnb.category.adm-role', type: 'iframe' },
    '/adm_activity': { title: 'sub.lnb.category.adm-history', type: 'iframe' },

    // system-manage
    '/sys_set': { title: 'sub.lnb.category.sys-setting', type: 'iframe' },

    '': { title: null, type: 'iframe' },
};


export { UPPER_MENU_OPTIONS, SUB_MENU_OPTIONS };
