import { get as _get, isArray as _isArray } from 'lodash';
import { UPPER_MENU_OPTIONS, SUB_MENU_OPTIONS } from './utils/CategoryOptions';
import LnbRest from './LnbRest';

let categoryList = [];

function hasAuthority(submenu) {
    return submenu.accssAuthCd === 'E' || submenu.accssAuthCd === 'S';
}

function sanitizeSub(sub) {
    return {
        id: sub.menuId,
        title: _get(SUB_MENU_OPTIONS[sub.menuUrl], 'title', sub.menuNm),
        authority: sub.accssAuthCd === 'E' ? 'MANAGE' : 'VIEW',
        route: {
            type: _get(SUB_MENU_OPTIONS[sub.menuUrl], 'type', ''),
            // 'type': MENU_ACTION_CLASSFICATION[sub.menuNm] ? "component" : "iframe",
            url: _get(SUB_MENU_OPTIONS[sub.menuUrl], 'url', sub.menuUrl),
            id: sub.menuId
        }
    };
}

function isUpperCategory(menu) {
    return menu.hasSubMnuYn === 'Y' && menu.subMnuNo === '0';
}

function sanitizeCategory(menu, subsByMenuID, index) {
    return {
        no: menu.mnuId,
        title: _get(UPPER_MENU_OPTIONS[menu.mnuNm], 'title', menu.mnuNm),
        id: menu.mnuNo,
        sub: subsByMenuID.get(menu.mnuNo),
        imageClass: _get(UPPER_MENU_OPTIONS[menu.mnuNm], 'css'),
        index
    };
}


class LnbService {

    static retrieveCategoryList() {
        if (categoryList.length > 0) {
            return Promise.resolve(categoryList);
        }

        return Promise.all([LnbRest.getCategoryList(), LnbRest.getSubCategoryList()]).then(values => {
            const menus = _isArray(values[0]) ? values[0] : [];
            const subDetails = _isArray(values[1]) ? values[1] : [];
            const subsByMenuID = new Map();

            subDetails
                .filter(hasAuthority)
                .forEach(sub => {
                    const subArray = subsByMenuID.get(sub.uprMenuId) || [];
                    subArray.push(sanitizeSub(sub));
                    subsByMenuID.set(sub.uprMenuId, subArray);
                });

            const sanitized = menus
                .filter(isUpperCategory)
                .map((menu, index) => sanitizeCategory(menu, subsByMenuID, index));
            categoryList = sanitized;
            return sanitized;
        });
    }

}

export default LnbService;
