import { $http } from '../../common/index';

class UserAccountRest {

    static getUserStateList() {
        return $http.get('/adm/cmm/commCd/selectListCommCd?cdId=1000012&page=1&start=0&limit=25');
    }

    static getUserSectList() {
        return $http.get('/adm/cmm/commCd/selectListCommCd?cdId=1000010&page=1&start=0&limit=25');
    }

    static getBliingSectList() {
        return $http.get('/adm/cmm/commCd/selectListCommCd?cdId=1000074&page=1&start=0&limit=25');
    }

    static getUserList(params) {
        return $http.get('/adm/act_user/selectListPageUserDtl?', { params });
    }

}

export default UserAccountRest;
