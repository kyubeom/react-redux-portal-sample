import React, { Component } from 'react';

import { isEmpty } from 'lodash';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { userAccountOperations } from '../../state/userAccount';
import './UserAccount.scss';
import { UserState, UserSect, LongTermUnuse, UserSearchBox, UserListTable } from './views';
import UserAccountService from './UserAccountService';
import { PageNation } from '../../common/views/index';
import i18nResource from './i18n.json';
import { withAdminCommonHOC } from '../../common/hoc';
import { TitleWrapper, SearchWrapper } from '../wrapper/index';

class UserAccount extends Component {

    constructor(props) {
        super(props);

        this.state = { userSearchSelectBoxObject: {} };

        this.searchParams = {
            userStatCd: '',
            userTypeCd: '',
            longtermUnusedYn: '',
            condCode: 'userNm',
            condTxt: '',
            page: 1,
            start: 0,
            limit: 15,
        };

        this.redux = props.redux;
        this.i18n = props.i18n;
        this.selectedUserIdList = [];

        this.searchActionFunc = this.searchActionFunc.bind(this);
        this.searchUserStatChangeEvent = this.searchUserStatChangeEvent.bind(this);
        this.searchUserSectChangeEvent = this.searchUserSectChangeEvent.bind(this);
        this.searchLongTermUseChangeEvent = this.searchLongTermUseChangeEvent.bind(this);
        this.searchKeywordCodeChangeEvent = this.searchKeywordCodeChangeEvent.bind(this);
        this.requestUserListSearchByPageChange = this.requestUserListSearchByPageChange.bind(this);
        this.getUserCountMsg = this.getUserCountMsg.bind(this);
        this.searchKeywordChangeEvent = this.searchKeywordChangeEvent.bind(this);
        this.getSelectedItemList = this.getSelectedItemList.bind(this);

        props.redux.requestUserSearchParam();
        props.redux.requestUserList(this.searchParams);
    }

    static getDerivedStateFromProps(nextProps, prevStatus) {
        const { userSearchSelectBoxObject } = prevStatus;
        const { userAccount } = nextProps;
        let { userSearchParam } = userAccount;

        if (isEmpty(userSearchSelectBoxObject) && !isEmpty(userSearchParam)) {
            userSearchParam = Object.assign({}, userSearchParam);
            UserAccountService.reBuildUserStateList(userSearchParam);
            UserAccountService.reBuildUserSectList(userSearchParam);
            userSearchParam.longTermUnuseList = UserAccountService.reBuildLongTermUnuseList(userSearchParam);
            userSearchParam.searchSelectBoxList = UserAccountService.reBuildSearchSelectBoxList(userSearchParam);

            return { userSearchSelectBoxObject: userSearchParam };
        }

        return null;
    }

    getUserCountMsg() {
        const { userAccount } = this.props;
        const { userListResultMap } = userAccount;
        let msg = this.i18n.t('userAccount.msg.default');
        if (userListResultMap.data) {
            const { data } = userListResultMap;
            const { total } = data;
            const fromCount = (this.searchParams.page - 1) * this.searchParams.limit + 1;
            const toCount = this.searchParams.page * this.searchParams.limit;
            msg = this.i18n.t('userAccount.msg.userCount', { total, fromCount, toCount });
        }

        return msg;
    }

    getSelectedItemList(itemList) {
        this.selectedUserIdList = itemList.map(item => item.userId);
        console.log(this.selectedUserIdList);
    }

    searchUserStatChangeEvent(userStatCd) {
        this.searchParams.userStatCd = userStatCd;
    }

    searchUserSectChangeEvent(userTypeCd) {
        this.searchParams.userTypeCd = userTypeCd;
    }

    searchLongTermUseChangeEvent(longtermUnusedYn) {
        this.searchParams.longtermUnusedYn = longtermUnusedYn;
    }

    searchKeywordCodeChangeEvent(condCode) {
        this.searchParams.condCode = condCode;
    }

    searchKeywordChangeEvent(keyword) {
        this.searchParams.condTxt = keyword;
    }

    searchActionFunc() {
        this.redux.requestUserList(this.searchParams);
    }

    requestUserListSearchByPageChange(newPageNum) {
        this.searchParams.page = newPageNum;
        this.searchParams.start = (newPageNum - 1) * this.searchParams.limit;

        this.redux.requestUserList(this.searchParams);
    }

    render() {
        const searchStyle = { margin: 0 };
        const userCountInfo = this.getUserCountMsg();

        const { userAccount } = this.props;
        const { userListResultMap } = userAccount;
        const { userSearchSelectBoxObject } = this.state;

        return (
            <div className="search_wrap">
                <TitleWrapper>
                    { this.i18n.t('userAccount.title') }
                </TitleWrapper>
                <SearchWrapper>
                    <UserState
                        {...userSearchSelectBoxObject}
                        searchUserStatChangeEvent={this.searchUserStatChangeEvent} />

                    <UserSect
                        {...userSearchSelectBoxObject}
                        searchUserSectChangeEvent={this.searchUserSectChangeEvent} />

                    <LongTermUnuse
                        {...userSearchSelectBoxObject}
                        searchLongTermUseChangeEvent={this.searchLongTermUseChangeEvent} />

                    <UserSearchBox
                        {...userSearchSelectBoxObject}
                        searchKeywordCodeChangeEvent={this.searchKeywordCodeChangeEvent}
                        searchActionFunc={this.searchActionFunc}
                        watchInputKeyword={this.searchKeywordChangeEvent}
                        searchStyle={searchStyle} />
                </SearchWrapper>

                <UserListTable {...userListResultMap.data} getSelectedItemList={this.getSelectedItemList} />

                <div>
                    <div className="userAccount_footer">
                        <PageNation
                            totalNum={userListResultMap.data ? userListResultMap.data.total : 0}
                            pageLimitNum={this.searchParams.limit}
                            selectedNum={this.searchParams.page}
                            pageActionFunc={this.requestUserListSearchByPageChange} />
                    </div>

                    <div className="user_total_text right_align">
                        {userCountInfo}
                    </div>
                </div>
            </div>
        );
    }

}

UserAccount.propTypes = {
    userAccount: PropTypes.object,
    // userListResultMap: PropTypes.object,
};

UserAccount.defaultProps = {
    userAccount: {
        userSearchParam: {
            userSectList: [],
            userStateList: [],
        },
    },
    // userListResultMap: {},
};

const mapDispatchToProps = dispatch => ({
    redux: {
        requestUserSearchParam() {
            dispatch(userAccountOperations.requestUserSearchParam());
        },
        requestUserList(params) {
            dispatch(userAccountOperations.requestUserList(params));
        },
    },
});

const mapStateToProps = state => {
    const { userAccount } = state;
    return {
        userAccount,
    };
};

const connected = connect(mapStateToProps, mapDispatchToProps)(UserAccount);
const withHOC = withAdminCommonHOC(connected, i18nResource);
export default withHOC;
