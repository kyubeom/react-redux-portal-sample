import Cookies from 'js-cookie';
import i18nResource from './i18n.json';

import { LOCALE_KEY } from '../../common/utils/Language';

function getLangCd(key) {
    const langCd = Cookies.get('langCd');
    const locale = LOCALE_KEY[langCd] ? LOCALE_KEY[langCd] : LOCALE_KEY['001'];
    const i18Map = i18nResource[locale];

    return i18Map[key];
}

class UserAccountService {

    static reBuildUserStateList({ userStateList = [] }) {
        if (!userStateList.find(target => target.cdValidVal === '')) {
            const allTarget = {
                cdValidVal: '',
                th1CdValidValNm: getLangCd('userAccount.selectBox.selectAll'),
            };

            userStateList.unshift(allTarget);
        }
    }

    static reBuildUserSectList({ userSectList = [] }) {
        if (!userSectList.find(target => target.cdValidVal === '')) {
            const allTarget = {
                cdValidVal: '',
                th1CdValidValNm: getLangCd('userAccount.selectBox.selectAll'),
            };

            userSectList.unshift(allTarget);
        }
    }

    static reBuildLongTermUnuseList() {
        const longTermUnuseList = [];
        longTermUnuseList.push({ cdValidVal: '', th1CdValidValNm: getLangCd('userAccount.selectBox.selectAll') });
        longTermUnuseList.push({ cdValidVal: 'Y', th1CdValidValNm: getLangCd('userAccount.selectBox.Y') });
        longTermUnuseList.push({ cdValidVal: 'N', th1CdValidValNm: getLangCd('userAccount.selectBox.N') });
        return longTermUnuseList;
    }

    static reBuildSearchSelectBoxList() {
        const searchSelectBoxList = [];
        searchSelectBoxList.push({ cdValidVal: 'userNm', th1CdValidValNm: getLangCd('userAccount.selectBox.name') });
        searchSelectBoxList.push({ cdValidVal: 'eplyNo', th1CdValidValNm: getLangCd('userAccount.selectBox.employNo') });
        searchSelectBoxList.push({ cdValidVal: 'loginIdLike', th1CdValidValNm: getLangCd('userAccount.selectBox.loginId') });
        return searchSelectBoxList;
    }

}

export default UserAccountService;
