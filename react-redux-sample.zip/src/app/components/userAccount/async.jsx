import React from 'react';
import Loadable from 'react-loadable';

const LoadableOtherComponent = Loadable({
    loader: () => import(/* webpackChunkName: "user_account" */'./UserAccount.jsx'), // eslint-disable-line
    loading: () => <React.Fragment />
});

export default () => <LoadableOtherComponent />;
