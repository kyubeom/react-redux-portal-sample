import React, { Component } from 'react';

import { isEmpty, pull, indexOf } from 'lodash';
import PropTypes from 'prop-types';
import uuidv4 from 'uuid/v4';
import { withI18n } from '../../../common/hoc';
import i18nResource from './i18n.json';
import UserAccountPopup from '../../popup/userAccount/UserAccountPopup';

class UserListTable extends Component {

    constructor(props) {
        super(props);

        this.state = {
            selectedItemList: [],
            isOpenUserAccountPopup: false,
            popupMode: 'ADD',
        };

        this.selectedAll = false;

        const { i18n, getSelectedItemList } = props;
        this.i18n = i18n;
        this.getSelectedItemList = getSelectedItemList;
        this.staticIds = [uuidv4(), uuidv4(), uuidv4(), uuidv4(), uuidv4(), uuidv4(), uuidv4()];

        this.itemSelectToggleEvent = this.itemSelectToggleEvent.bind(this);
        this.allitemSelectToggleEvent = this.allitemSelectToggleEvent.bind(this);
        this.userAddPopupOpenEvent = this.userAddPopupOpenEvent.bind(this);
        this.userAddPopupCloseEvent = this.userAddPopupCloseEvent.bind(this);
    }

    getUserListItem() {
        const { list } = this.props;
        const { selectedItemList } = this.state;

        let userListItem = [];

        if (!isEmpty(list)) {
            userListItem = list.map(userItem => {
                let itemChecked = false;
                if (indexOf(selectedItemList, userItem) > -1) {
                    itemChecked = true;
                }

                return (
                    <tr key={userItem.userId} className={itemChecked ? 'odd selected' : 'odd'}>
                        <td className="t-check">
                            <div className="checkbox">
                                <label>
                                    <input key={userItem.userId} type="checkbox" onChange={() => this.itemSelectToggleEvent(userItem)} checked={itemChecked} />
                                    <span className="label-text" />
                                </label>
                            </div>
                        </td>
                        <td>
                            {userItem.userStatName}
                        </td>
                        <td>
                            {userItem.userNm}
                        </td>
                        <td>
                            {userItem.userLoginId}
                        </td>
                        <td>
                            {userItem.eplyNo}
                        </td>
                        <td>
                            {userItem.userCopNm}
                        </td>
                        <td>
                            {userItem.uprDeptNm}
                        </td>
                        <td>
                            {userItem.userSectName}
                        </td>
                        <td>
                            {userItem.lastLoginDtm}
                        </td>
                        <td>
                            {userItem.rtmYmd}
                        </td>
                        <td>
                            {userItem.longTermUnusedYn}
                        </td>
                    </tr>
                );
            });
        }

        return userListItem;
    }


    isSelectedAll(selectedItemList) {
        const { list } = this.props;
        if (list.length === selectedItemList.length) {
            return true;
        }
        return false;
    }

    itemSelectToggleEvent(item) {
        const { selectedItemList } = this.state;

        if (indexOf(selectedItemList, item) > -1) {
            pull(selectedItemList, item);
        } else {
            selectedItemList.push(item);
        }

        this.getSelectedItemList(selectedItemList);

        this.selectedAll = this.isSelectedAll(selectedItemList);

        this.setState({
            selectedItemList
        });
    }

    allitemSelectToggleEvent() {
        this.selectedAll = !this.selectedAll;
        let selectedItemList = [];

        if (this.selectedAll) {
            const { list } = this.props;

            if (!isEmpty(list)) {
                selectedItemList = list.map(item => item);
            }
        }

        this.getSelectedItemList(selectedItemList);

        this.setState({
            selectedItemList
        });
    }

    userAddPopupOpenEvent() {
        this.setState({
            isOpenUserAccountPopup: true
        });
    }

    userAddPopupCloseEvent() {
        this.setState({
            isOpenUserAccountPopup: false
        });
    }

    render() {
        const userListItem = this.getUserListItem();
        const { isOpenUserAccountPopup, popupMode } = this.state;

        return (
            <div className="dataTables_wrapper">
                <div className="x_panel">
                    <div className="x_content">
                        <div className="selected_option and_datepicker">
                            <button key={this.staticIds[0]} type="button" className="btn btn-default" onClick={this.userAddPopupOpenEvent}>
                                { this.i18n.t('userAccount.views.button.add') }
                            </button>
                            <button key={this.staticIds[1]} type="button" className="btn btn-default">
                                { this.i18n.t('userAccount.views.button.chageState') }
                            </button>
                            <button key={this.staticIds[2]} type="button" className="btn btn-default">
                                { this.i18n.t('userAccount.views.button.passwordRest') }
                            </button>
                            <button key={this.staticIds[3]} type="button" className="btn btn-default">
                                { this.i18n.t('userAccount.views.button.longtermReset') }
                            </button>
                            <button key={this.staticIds[4]} type="button" className="btn btn-default">
                                { this.i18n.t('userAccount.views.button.changeFileAuth') }
                            </button>
                            <span key={this.staticIds[5]} className="divider" />
                            <button key={this.staticIds[6]} type="button" className="btn btn-primary right_align">
                                { this.i18n.t('userAccount.views.button.download') }
                            </button>
                        </div>
                        <table className="table table-striped table-bordered dataTable">
                            <thead>
                                <tr>
                                    <th className="no-sort t-check">
                                        <div className="checkbox">
                                            <label>
                                                <input type="checkbox" id="check-all" onClick={this.allitemSelectToggleEvent} checked={this.selectedAll} />
                                                <span className="label-text" />
                                            </label>
                                        </div>
                                    </th>
                                    <th className="filter-select">
                                        { this.i18n.t('userAccount.views.table.col.state') }
                                    </th>
                                    <th className="filter-input">
                                        { this.i18n.t('userAccount.views.table.col.name') }
                                    </th>
                                    <th className="filter-input no-sort">
                                        { this.i18n.t('userAccount.views.table.col.id') }
                                    </th>
                                    <th>
                                        { this.i18n.t('userAccount.views.table.col.eplyNo') }
                                    </th>
                                    <th className="filter-select">
                                        { this.i18n.t('userAccount.views.table.col.corp') }
                                    </th>
                                    <th>
                                        { this.i18n.t('userAccount.views.table.col.dept') }
                                    </th>
                                    <th className="filter-select">
                                        { this.i18n.t('userAccount.views.table.col.sectCd') }
                                    </th>
                                    <th>
                                        { this.i18n.t('userAccount.views.table.col.lastLoginDtm') }
                                    </th>
                                    <th>
                                        { this.i18n.t('userAccount.views.table.col.retiredDtm') }
                                    </th>
                                    <th className="filter-select">
                                        { this.i18n.t('userAccount.views.table.col.longtermUnuse') }
                                    </th>
                                </tr>
                            </thead>

                            <tbody>
                                {userListItem}
                            </tbody>
                        </table>
                    </div>
                </div>
                <UserAccountPopup isOpenUserAccountPopup={isOpenUserAccountPopup} cancelAction={this.userAddPopupCloseEvent} popupMode={popupMode} />
            </div>
        );
    }

}

UserListTable.propTypes = {
    list: PropTypes.array,
    getSelectedItemList: PropTypes.func,
};

UserListTable.defaultProps = {
    list: [],
    getSelectedItemList: undefined,
};

export default withI18n(UserListTable, i18nResource);
