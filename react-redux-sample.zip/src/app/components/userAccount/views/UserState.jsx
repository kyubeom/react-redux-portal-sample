import React, { Component } from 'react';

import PropTypes from 'prop-types';
import uuidv4 from 'uuid/v4';
import { ButtonToolbar, DropdownButton, MenuItem } from 'react-bootstrap';
import { withI18n } from '../../../common/hoc';
import i18nResource from './i18n.json';

class UserState extends Component {

    constructor(props) {
        super(props);
        this.state = { userStatCd: '' };
        this.searchUserStatChangeEvent = this.searchUserStatChangeEvent.bind(this);
        const { searchUserStatChangeEvent } = props;
        this.searchUserStatChange = searchUserStatChangeEvent;
        this.i18n = props.i18n;
    }

    searchUserStatChangeEvent(val) {
        this.setState({ userStatCd: val });
        this.searchUserStatChange(val);
    }

    render() {
        let userState = this.i18n.t('userAccount.views.selectAll');
        const userStateMenuItems = [];
        const { userStateList } = this.props;
        const { userStatCd } = this.state;

        userStateList.forEach(userStateInfo => {
            if (userStateInfo.cdValidVal === userStatCd) {
                userState = userStateInfo.th1CdValidValNm;
                userStateMenuItems.push(
                    <MenuItem key={uuidv4()} eventKey={userStateInfo.cdValidVal} active={true}>
                        {userStateInfo.th1CdValidValNm}
                    </MenuItem>
                );
            } else {
                userStateMenuItems.push(
                    <MenuItem key={uuidv4()} eventKey={userStateInfo.cdValidVal}>
                        {userStateInfo.th1CdValidValNm}
                    </MenuItem>
                );
            }
        });

        return (
            <div className="search_align col_20">
                <span>
                    { this.i18n.t('userAccount.views.state') }
                </span>
                <ButtonToolbar>
                    <DropdownButton title={userState} id="dropdown-size-medium" onSelect={this.searchUserStatChangeEvent}>
                        {userStateMenuItems}
                    </DropdownButton>
                </ButtonToolbar>
            </div>
        );
    }

}

UserState.propTypes = {
    userStateList: PropTypes.array,
    // userStatCd : PropTypes.string,
    searchUserStatChangeEvent: PropTypes.func.isRequired,
};

UserState.defaultProps = {
    userStateList: [],
};

const userStateHoc = withI18n(UserState, i18nResource);
export default userStateHoc;
