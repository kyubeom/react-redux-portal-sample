import React, { Component } from 'react';

import PropTypes from 'prop-types';
import { ButtonToolbar, DropdownButton, MenuItem } from 'react-bootstrap';
import uuidv4 from 'uuid/v4';
import { withI18n } from '../../../common/hoc';
import i18nResource from './i18n.json';

class LongTermUnuse extends Component {

    constructor(props) {
        super(props);
        this.state = { longtermUnusedVal: '' };
        this.longTermUnuseSelectEvent = this.longTermUnuseSelectEvent.bind(this);
        const { searchLongTermUseChangeEvent } = this.props;
        this.searchLongTermUseChangeEvent = searchLongTermUseChangeEvent;
        this.i18n = props.i18n;
    }

    longTermUnuseSelectEvent(val) {
        this.setState({ longtermUnusedVal: val });
        this.searchLongTermUseChangeEvent(val);
    }

    render() {
        let longTermUnUseTitle = '';
        const longTermUnUseMenuItems = [];
        const { longTermUnuseList } = this.props;
        const { longtermUnusedVal } = this.state;

        longTermUnuseList.forEach(longTermUnuseInfo => {
            if (longTermUnuseInfo.cdValidVal === longtermUnusedVal) {
                longTermUnUseTitle = longTermUnuseInfo.th1CdValidValNm;
                longTermUnUseMenuItems.push(
                    <MenuItem key={uuidv4()} eventKey={longTermUnuseInfo.cdValidVal} active={true}>
                        {longTermUnuseInfo.th1CdValidValNm}
                    </MenuItem>
                );
            } else {
                longTermUnUseMenuItems.push(
                    <MenuItem key={uuidv4()} eventKey={longTermUnuseInfo.cdValidVal}>
                        {longTermUnuseInfo.th1CdValidValNm}
                    </MenuItem>
                );
            }
        });

        return (
            <div className="search_align col_25">
                <span>
                    {this.i18n.t('userAccount.views.longtermUnuse')}
                </span>
                <ButtonToolbar>
                    <DropdownButton title={longTermUnUseTitle} id="dropdown-size-medium" onSelect={this.longTermUnuseSelectEvent}>
                        {longTermUnUseMenuItems}
                    </DropdownButton>
                </ButtonToolbar>
            </div>
        );
    }

}


LongTermUnuse.propTypes = {
    longTermUnuseList: PropTypes.array,
    searchLongTermUseChangeEvent: PropTypes.func.isRequired,
};

LongTermUnuse.defaultProps = {
    longTermUnuseList: [],
};

export default withI18n(LongTermUnuse, i18nResource);
