import React, { Component } from 'react';

import PropTypes from 'prop-types';
import { ButtonToolbar, DropdownButton, MenuItem } from 'react-bootstrap';
import uuidv4 from 'uuid/v4';
import { withI18n } from '../../../common/hoc';
import i18nResource from './i18n.json';

class UserSect extends Component {

    constructor(props) {
        super(props);
        this.state = ({ userSectCd: '' });
        this.searchUserSectChangeEvent = this.searchUserSectChangeEvent.bind(this);
        const { searchUserSectChangeEvent } = props;
        this.searchUserSectChange = searchUserSectChangeEvent;
        this.i18n = props.i18n;
    }

    searchUserSectChangeEvent(val) {
        this.setState({ userSectCd: val });
        this.searchUserSectChange(val);
    }

    render() {
        let userSect = this.i18n.t('userAccount.views.selectAll');
        const userSectMenuItems = [];
        const { userSectCd } = this.state;
        const { userSectList } = this.props;

        userSectList.forEach(userSectInfo => {
            if (userSectInfo.cdValidVal === userSectCd) {
                userSect = userSectInfo.th1CdValidValNm;
                userSectMenuItems.push(
                    <MenuItem key={uuidv4()} eventKey={userSectInfo.cdValidVal} active={true}>
                        {userSectInfo.th1CdValidValNm}
                    </MenuItem>
                );
            } else {
                userSectMenuItems.push(
                    <MenuItem key={uuidv4()} eventKey={userSectInfo.cdValidVal}>
                        {userSectInfo.th1CdValidValNm}
                    </MenuItem>
                );
            }
        });

        return (
            <div className="search_align col_25">
                <span>
                    {this.i18n.t('userAccount.views.sectCd')}
                </span>
                <ButtonToolbar>
                    <DropdownButton title={userSect} id="dropdown-size-medium" onSelect={this.searchUserSectChangeEvent}>
                        {userSectMenuItems}
                    </DropdownButton>
                </ButtonToolbar>
            </div>
        );
    }

}

UserSect.propTypes = {
    userSectList: PropTypes.array,
    // userSectCd : PropTypes.string,
    searchUserSectChangeEvent: PropTypes.func.isRequired,
};

UserSect.defaultProps = {
    userSectList: [],
};

export default withI18n(UserSect, i18nResource);
