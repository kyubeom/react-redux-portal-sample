import React, { Component } from 'react';

import PropTypes from 'prop-types';
import { ButtonToolbar, DropdownButton, MenuItem } from 'react-bootstrap';
import uuidv4 from 'uuid/v4';
import { SearchInputBox } from '../../../common/views';

class UserSearchBox extends Component {

    constructor(props) {
        super(props);
        this.state = { condCode: 'userNm' };
        this.searchKeywordCodeChangeEvent = this.searchKeywordCodeChangeEvent.bind(this);
        const { searchKeywordCodeChangeEvent } = props;
        this.searchKeywordCodeChange = searchKeywordCodeChangeEvent;
    }

    searchKeywordCodeChangeEvent(val) {
        this.setState({ condCode: val });
        this.searchKeywordCodeChange(val);
    }

    render() {
        let searchSelectBoxTitle = '';
        const searchMenuItems = [];
        const { condCode } = this.state;
        const { searchActionFunc, searchStyle, watchInputKeyword, searchSelectBoxList } = this.props;

        searchSelectBoxList.forEach(searchSelectBox => {
            if (searchSelectBox.cdValidVal === condCode) {
                searchSelectBoxTitle = searchSelectBox.th1CdValidValNm;
                searchMenuItems.push(
                    <MenuItem key={uuidv4()} eventKey={searchSelectBox.cdValidVal} active={true}>
                        {searchSelectBox.th1CdValidValNm}
                    </MenuItem>
                );
            } else {
                searchMenuItems.push(
                    <MenuItem key={uuidv4()} eventKey={searchSelectBox.cdValidVal}>
                        {searchSelectBox.th1CdValidValNm}
                    </MenuItem>
                );
            }
        });

        return (
            <div className="search_align_right">
                <ButtonToolbar>
                    <DropdownButton title={searchSelectBoxTitle} id="dropdown-size-medium" onSelect={this.searchKeywordCodeChangeEvent}>
                        {searchMenuItems}
                    </DropdownButton>
                </ButtonToolbar>
                <SearchInputBox
                    searchActionFunc={searchActionFunc}
                    style={searchStyle}
                    minKeyWordLength={0}
                    watchInputKeyword={watchInputKeyword} />
            </div>
        );
    }

}

UserSearchBox.propTypes = {
    searchSelectBoxList: PropTypes.array,
    // condCode : PropTypes.string,
    searchKeywordCodeChangeEvent: PropTypes.func.isRequired,
    searchStyle: PropTypes.object,
    searchActionFunc: PropTypes.func.isRequired,
    watchInputKeyword: PropTypes.func.isRequired,
};

UserSearchBox.defaultProps = {
    searchSelectBoxList: [],
    searchStyle: {},
};

export default UserSearchBox;
