import TitleWrapper from './TitleWrapper';
import SearchWrapper from './SearchWrapper';

export {
    TitleWrapper,
    SearchWrapper
};
