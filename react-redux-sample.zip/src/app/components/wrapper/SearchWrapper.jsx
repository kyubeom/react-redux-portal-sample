import React from 'react';
import PropTypes from 'prop-types';

import styles from './wrapper.scss';

const SearchWrapper = props => {
    const { children } = props;
    return (
        <div className={styles['search-wrap']}>
            { children }
        </div>
    );
};

export default SearchWrapper;

SearchWrapper.propTypes = {
    children: PropTypes.any.isRequired
};
