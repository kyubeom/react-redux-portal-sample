import React from 'react';
import PropTypes from 'prop-types';

const TitleWrapper = props => {
    const { children } = props;
    return (
        <h2 width="100%">
            { children }
        </h2>
    );
};

export default TitleWrapper;

TitleWrapper.propTypes = {
    children: PropTypes.any.isRequired
};
