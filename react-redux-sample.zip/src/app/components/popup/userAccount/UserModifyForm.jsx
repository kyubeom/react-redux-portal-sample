import React, { Component } from 'react';

/* eslint-disable import/no-unresolved */
import { withI18n } from '~/common/hoc';
/* eslint-disable import/no-unresolved */

import i18nResource from './i18n.json';

class UserModifyForm extends Component {

    constructor(props) {
        super(props);

        const { i18n } = props;
        this.i18n = i18n;
    }

    render() {
        return (
            <React.fragment />
        );
    }

}

export default withI18n(UserModifyForm, i18nResource);
