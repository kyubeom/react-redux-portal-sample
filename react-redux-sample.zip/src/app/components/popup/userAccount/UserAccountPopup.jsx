import React, { Component } from 'react';
import { Modal, Button } from 'react-bootstrap';
import PropTypes from 'prop-types';

/* eslint-disable import/no-unresolved */
import { withAdminCommonHOC } from '~/common/hoc';
/* eslint-disable import/no-unresolved */

import i18nResource from './i18n.json';
import './userAccountPopup.scss';
import UserAddFrom from './UserAddForm';
import UserModifyForm from './UserModifyForm';

class UserAccountPopup extends Component {

    constructor(props) {
        super(props);

        const { dialog, i18n, popupMode, cancelAction } = props;
        this.dialog = dialog;
        this.i18n = i18n;
        this.popupMode = popupMode;
        this.cancelAction = cancelAction;

        this.handleClose = this.handleClose.bind(this);
        this.handleSave = this.handleSave.bind(this);
    }

    handleSave() {
        console.log('do user save!!');
        this.cancelAction();
    }

    handleClose() {
        console.log('do user cancel!!');
        this.cancelAction();
    }

    render() {
        const { isOpenUserAccountPopup } = this.props;
        const bodyFrom = this.popupMode === 'ADD' ? <UserAddFrom /> : <UserModifyForm />;

        return (
            <Modal show={isOpenUserAccountPopup} onHide={this.handleClose} dialogClassName="user_add_dialog">
                <Modal.Header>
                    <Modal.Title bsClass="modal-title">
                        {this.popupMode === 'ADD' ? this.i18n.t('user.account.add.title') : this.i18n.t('user.account.modify.title')}
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {bodyFrom}
                </Modal.Body>
                <Modal.Footer>
                    <Button bsSize="sm" onClick={this.handleClose}>
                        {this.i18n.t('user.account.cancel')}
                    </Button>
                    <Button bsStyle="primary" bsSize="sm" onClick={this.handleSave}>
                        {this.i18n.t('user.account.save')}
                    </Button>
                </Modal.Footer>
            </Modal>
        );
    }

}

UserAccountPopup.propTypes = {
    popupMode: PropTypes.string,
    cancelAction: PropTypes.func,
    isOpenUserAccountPopup: PropTypes.bool
};

UserAccountPopup.defaultProps = {
    popupMode: 'modify',
    cancelAction: undefined,
    isOpenUserAccountPopup: false
};

export default withAdminCommonHOC(UserAccountPopup, i18nResource);
