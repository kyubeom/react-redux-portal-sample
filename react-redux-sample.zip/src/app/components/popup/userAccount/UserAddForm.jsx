import React, { Component } from 'react';

/* eslint-disable import/no-unresolved */
import { withI18n } from '~/common/hoc';
/* eslint-disable import/no-unresolved */

import i18nResource from './i18n.json';

class UserAddForm extends Component {

    constructor(props) {
        super(props);

        const { i18n } = props;
        this.i18n = i18n;
    }

    render() {
        return (
            <div>

                <div className="m_panel">

                    <div className="m_title">
                        <h2>
                            {this.i18n.t('user.account.add.subTitle.normalInfo')}
                        </h2>
                        <div className="clearfix" />
                    </div>

                    <div className="m_content">
                        <table className="no-border1">
                            <colgroup>
                                <col className="col1" />
                                <col className="col2" />
                                <col className="col3" />
                                <col className="col4" />
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th>
                                        {this.i18n.t('user.account.add.userSectCd')}
                                    </th>
                                    <td>
                                        <div className="form-inline">
                                            <div className="radio">
                                                <label>
                                                    <input type="radio" checked="checked" name="optionsRadios1" />
                                                    <span className="label-text">
                                                        {this.i18n.t('user.account.add.userSectCd')}
                                                    </span>
                                                </label>
                                            </div>
                                            <div className="radio">
                                                <label>
                                                    <input type="radio" name="optionsRadios1" />
                                                    <span className="label-text">
                                                        {this.i18n.t('user.account.add.userSectCd')}
                                                    </span>
                                                </label>
                                            </div>
                                        </div>
                                    </td>
                                    <th />
                                    <td />
                                </tr>
                                <tr>
                                    <th>
                                        {this.i18n.t('user.account.add.emailAddr')}
                                        <span className="critical_items" title="필수항목" />
                                    </th>
                                    <td>
                                        <div className="form-inline">
                                            <input type="email" className="form-control" id="user_email" />
                                            <button type="button" className="btn btn-default">
                                                {this.i18n.t('user.account.add.emailAddr.check.duplicate')}
                                            </button>
                                        </div>
                                    </td>
                                    <th />
                                    <td />
                                </tr>
                                <tr>
                                    <th>
                                        {this.i18n.t('user.account.add.loginId')}
                                    </th>
                                    <td>
                                        <input type="text" className="form-control" disabled="disabled" />
                                    </td>
                                    <th />
                                    <td />
                                </tr>
                                <tr>
                                    <th>
                                        {this.i18n.t('user.account.add.name')}
                                        <span className="critical_items" title="필수항목" />
                                    </th>
                                    <td>
                                        <input type="text" className="form-control" />
                                    </td>
                                    <th>
                                        {this.i18n.t('user.account.add.engName')}
                                        <span className="critical_items" title="필수항목" />
                                    </th>
                                    <td>
                                        <input type="text" className="form-control" />
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {this.i18n.t('user.account.add.corp')}
                                    </th>
                                    <td>
                                        <input type="text" className="form-control" />
                                    </td>
                                    <th>
                                        {this.i18n.t('user.account.add.engCorp')}
                                    </th>
                                    <td>
                                        <input type="text" className="form-control" />
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {this.i18n.t('user.account.add.company')}
                                    </th>
                                    <td>
                                        <input type="text" className="form-control" disabled="disabled" />
                                    </td>
                                    <th />
                                    <td />
                                </tr>
                                <tr>
                                    <th>
                                        {this.i18n.t('user.account.add.dept')}
                                        <span className="critical_items" title="필수항목" />
                                    </th>
                                    <td>
                                        <div className="form-inline">
                                            <input type="text" className="form-control" />
                                            <button type="button" className="btn btn-primary">
                                                <span className="glyphicon glyphicon-search" aria-hidden="true" />
                                            </button>
                                        </div>
                                    </td>
                                    <th />
                                    <td />
                                </tr>
                                <tr>
                                    <th>
                                        {this.i18n.t('user.account.add.company.number')}
                                    </th>
                                    <td>
                                        <input type="text" className="form-control" />
                                    </td>
                                    <th>
                                        {this.i18n.t('user.account.add.mobile.number')}
                                    </th>
                                    <td>
                                        <input type="text" className="form-control" />
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>


                <div className="m_panel">

                    <div className="m_title">
                        <h2>
                            {this.i18n.t('user.account.add.subTitle.state')}
                        </h2>
                        <div className="clearfix" />
                    </div>

                    <div className="m_content">
                        <table className="no-border1">
                            <colgroup>
                                <col className="col1" />
                                <col className="col2" />
                                <col className="col3" />
                                <col className="col4" />
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th>
                                        {this.i18n.t('user.account.add.state')}
                                    </th>
                                    <td>
                                        <input type="text" className="form-control" id="user_state" disabled="disabled" value="활성" />
                                    </td>
                                    <th>
                                        {this.i18n.t('user.account.add.product.type')}
                                    </th>
                                    <td>
                                        <select className="form-control">
                                            <option>
                                                {this.i18n.t('user.account.add.product.type')}
                                            </option>
                                            <option selected="selected">
                                                {this.i18n.t('user.account.add.product.type')}
                                            </option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {this.i18n.t('user.account.add.storage.assign')}
                                    </th>
                                    <td>
                                        <select className="form-control">
                                            <option>
                                                {this.i18n.t('user.account.add.storage.assign')}
                                            </option>
                                            <option selected="selected">
                                                {this.i18n.t('user.account.add.storage.assign')}
                                            </option>
                                            <option>
                                                {this.i18n.t('user.account.add.storage.assign')}
                                            </option>
                                        </select>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>


                <div className="m_panel">

                    <div className="m_title">
                        <h2>
                            {this.i18n.t('user.account.add.subTitle.autoUpdate')}
                        </h2>
                        <div className="clearfix" />
                    </div>

                    <div className="m_content">
                        <table className="no-border1">
                            <colgroup>
                                <col className="col1" />
                                <col className="col2" />
                                <col className="col3" />
                                <col className="col4" />
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th>
                                        {this.i18n.t('user.account.add.autoUpdate.target')}
                                    </th>
                                    <td>
                                        <div className="form-inline">
                                            <div className="radio">
                                                <label>
                                                    <input type="radio" checked="checked" name="optionsRadios2" />
                                                    <span className="label-text">
                                                        {this.i18n.t('user.account.add.autoUpdate.target')}
                                                    </span>
                                                </label>
                                            </div>
                                            <div className="radio">
                                                <label>
                                                    <input type="radio" name="optionsRadios2" />
                                                    <span className="label-text">
                                                        {this.i18n.t('user.account.add.autoUpdate.target')}
                                                    </span>
                                                </label>
                                            </div>
                                            <button
                                                type="button"
                                                rel="tooltip"
                                                className="btn btn-xs"
                                                data-toggle="tooltip"
                                                data-placement="top"
                                                title=""
                                                data-original-title="관리자에 의해 수동으로 정보 <br>변경 후, 유예대상을 선택하는 <br>경우, 입력된 기간까지는 시스템에 의해 자동 갱신되지 않습니다.">
                                                <i className="fa fa-question" />
                                            </button>
                                        </div>
                                    </td>
                                    <th>
                                        {this.i18n.t('user.account.add.autoUpdate.maximum.period')}
                                    </th>
                                    <td>
                                        <div className="form-inline">
                                            <div className="checkbox ">
                                                <label>
                                                    <input type="checkbox" checked="checked" disabled="disabled" />
                                                    <span className="label-text">
                                                        {this.i18n.t('user.account.add.autoUpdate.maximum.period')}
                                                    </span>
                                                </label>
                                            </div>

                                            <div className="form-group">
                                                <div className="input-group date" id="myDatepicker2">
                                                    <input type="text" className="form-control width-default" />
                                                    <span className="input-group-addon">
                                                        <span className="glyphicon glyphicon-calendar" />
                                                    </span>
                                                </div>
                                            </div>

                                        </div>

                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        );
    }

}

export default withI18n(UserAddForm, i18nResource);
