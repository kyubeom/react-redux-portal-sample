/* eslint-disable */
import React, {Component} from 'react';

class AdminDialog extends Component{

    constructor(){
        
    }

}

export default AdminDialog;
/* eslint-disable */