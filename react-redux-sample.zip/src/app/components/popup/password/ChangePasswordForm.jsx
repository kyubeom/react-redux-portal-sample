import React from 'react';
import { Col, Form, FormGroup, ControlLabel, FormControl, HelpBlock } from 'react-bootstrap';

const PasswordForm = context => {
    const { handleChangeCurrent, handleChangeNew, handleChangeConfirm, i18n } = context;
    const { t } = i18n;

    return (
        <Form horizontal={true}>
            <FormGroup controlId="currnet-password">
                <Col componentClass={ControlLabel} sm={3}>
                    <ControlLabel bsClass="form_label">
                        {t('change-password.current-password')}
                    </ControlLabel>
                </Col>
                <Col sm={9}>
                    <FormControl
                        type="password"
                        maxLength="50"
                        onChange={handleChangeCurrent} />
                </Col>
            </FormGroup>
            <FormGroup controlId="new-password">
                <Col componentClass={ControlLabel} sm={3}>
                    <ControlLabel bsClass="form_label">
                        {t('change-password.new-password')}
                    </ControlLabel>
                </Col>
                <Col sm={9}>
                    <FormControl
                        type="password"
                        maxLength="50"
                        onChange={handleChangeNew} />
                </Col>
            </FormGroup>
            <FormGroup controlId="confirm-password">
                <Col componentClass={ControlLabel} sm={3}>
                    <ControlLabel bsClass="form_label">
                        {t('change-password.confirm-password')}
                    </ControlLabel>
                </Col>
                <Col sm={9}>
                    <FormControl
                        type="password"
                        maxLength="50"
                        onChange={handleChangeConfirm} />
                </Col>
            </FormGroup>
            <HelpBlock bsClass="help_block">
                {t('change-password.first-rule')}
            </HelpBlock>
            <br />
            <HelpBlock bsClass="help_block">
                {t('change-password.second-rule')}
            </HelpBlock>
        </Form>
    );
};

export default PasswordForm;
