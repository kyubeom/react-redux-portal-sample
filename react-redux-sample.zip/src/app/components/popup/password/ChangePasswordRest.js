import { $http } from '~/common'; /* eslint-disable-line import/no-unresolved */

class PasswordRest {

    static changePassword(origin, change) {
        const config = { params: {
            mode: 'MOD',
            adminPwd: change,
            crntPwd: origin
        } };
        return $http.get('/adm/cmm/apmain/updateAdminPwd', config);
    }

}

export default PasswordRest;
