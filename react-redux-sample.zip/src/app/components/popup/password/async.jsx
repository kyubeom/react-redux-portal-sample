import React from 'react';
import Loadable from 'react-loadable';

const LoadableOtherComponent = Loadable({
    loader: () => import(/* webpackChunkName: "dialog_change_password" */'./ChangePassword.jsx'), // eslint-disable-line
    loading: () => <React.Fragment />
});

export default () => <LoadableOtherComponent />;