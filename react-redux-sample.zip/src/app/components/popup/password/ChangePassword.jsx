import React, { Component } from 'react';
import { isNil as _isNil } from 'lodash';
import { Modal, Button } from 'react-bootstrap';

/* eslint-disable import/no-unresolved */
import { withAdminCommonHOC } from '~/common/hoc';
/* eslint-disable import/no-unresolved */

import PasswordRest from './ChangePasswordRest';
import PasswordForm from './ChangePasswordForm';
import i18nResource from './i18n.json';
import './changePassword.scss';

const numberContinuePattern = /(012)|(123)|(234)|(345)|(456)|(567)|(678)|(789)|(890)/;
const equal3CharsPattern = /(\w)\1\1/;
const passwordPattern = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*\W).{8,12}$/;

function isValidPassword(password) {
    return !_isNil(password) && password !== ''
        && passwordPattern.test(password)
        && !equal3CharsPattern.test(password)
        && !numberContinuePattern.test(password);
}

class ChangePassword extends Component {

    constructor(props) {
        super(props);
        this.handleChangeCurrent = this.handleChangeCurrent.bind(this);
        this.handleChangeNew = this.handleChangeNew.bind(this);
        this.handleChangeConfirm = this.handleChangeConfirm.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.handleSave = this.handleSave.bind(this);

        const { dialog, i18n } = this.props;
        this.dialog = dialog;
        this.i18n = i18n || { t: f => f };
        this.state = {
            show: false
        };
        this.currentPassword = '';
        this.newPassword = '';
        this.confirmPassword = '';
    }

    UNSAFE_componentWillReceiveProps(nextProps) { // eslint-disable-line
        const { show } = this.state;
        if (nextProps.openDialogForChangePassword && !show) {
            this.setState({ show: true });
        }
    }

    handleChangeCurrent(e) {
        this.currentPassword = e.target.value;
    }

    handleChangeNew(e) {
        this.newPassword = e.target.value;
    }

    handleChangeConfirm(e) {
        this.confirmPassword = e.target.value;
    }

    handleClose() {
        this.setState({ show: false });
    }

    handleSave() {
        const { alert } = this.dialog;
        const { t } = this.i18n;

        if (_isNil(this.currentPassword)) {
            alert(t('change-password.enter-current-password')); return;
        }
        if (_isNil(this.newPassword)) {
            alert(t('change-password.enter-new-password')); return;
        }
        if (_isNil(this.confirmPassword)) {
            alert(t('change-password.re-enter-new-password')); return;
        }
        if (!isValidPassword(this.newPassword)) {
            alert(t('change-password.alert.notPasswordPattern')); return;
        }
        if (this.newPassword !== this.confirmPassword) {
            alert(t('change-password.alert.notMatchNewPassword')); return;
        }

        PasswordRest.changePassword(this.currentPassword, this.newPassword).then(result => {
            const { resultCode } = result;
            if (resultCode === 200) {
                alert(t('change-password.alert.success'), { okAction: this.handleClose });
            } else if (resultCode === 70404) {
                alert(t('change-password.alert.notMatchOriginPassword'));
            }
            alert('occured exception.');
        }, () => {
            alert('occured exception.');
        });
    }

    render() {
        const { show } = this.state;
        return (
            <Modal show={show} onHide={this.handleClose} dialogClassName="custom-dialog">
                <Modal.Header className="width_500">
                    <Modal.Title>
                        {this.i18n.t('change-password.title')}
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {PasswordForm(this)}
                </Modal.Body>
                <Modal.Footer>
                    <Button bsSize="sm" onClick={this.handleClose}>
                        {this.i18n.t('change-password.cancel')}
                    </Button>
                    <Button bsStyle="primary" bsSize="sm" onClick={this.handleSave}>
                        {this.i18n.t('change-password.save')}
                    </Button>
                </Modal.Footer>
            </Modal>
        );
    }

}

export default withAdminCommonHOC(ChangePassword, i18nResource);
