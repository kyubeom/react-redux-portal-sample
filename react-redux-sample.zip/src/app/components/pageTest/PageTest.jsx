/* eslint-disable */
import React, {Component} from 'react';

import { PageNation, SearchInputBox } from '../../common/views/index';

class PageTest extends Component {

    constructor(props) {
        super(props);

        this.state = {
            totalNum:175,
            pageLimitNum:10,
            selectedNum:1,
            forceAction:false,
            pageActionFunc:this.pageActionFunc.bind(this)
        }

        this.searchActionFunc = this.searchActionFunc.bind(this);
        this.watchInputKeyword = this.watchInputKeyword.bind(this);
    }

    pageActionFunc(num) {
        this.setState({
            selectedNum:num
        })

    }

    watchInputKeyword(keyword) {
        console.log("watch key : ", keyword)
    }

    searchActionFunc(keyWord) {
        console.log("do search! : ", keyWord);
    }

    render() {

        let searchStyle = {width:120}

        return (
            <div>
                <SearchInputBox searchActionFunc={this.searchActionFunc} watchInputKeyword={this.watchInputKeyword} styles={searchStyle}> </SearchInputBox>
                <PageNation {...this.state} ></PageNation>
            </div>
        );

    }
}

export default PageTest;