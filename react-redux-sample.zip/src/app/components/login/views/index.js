import IdPassword from './IdPassword';
import LangAndTimezone from './LangAndTimezone';
import Otp from './Otp';

export {
    IdPassword, LangAndTimezone, Otp
};
