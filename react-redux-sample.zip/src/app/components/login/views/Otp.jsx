import React, { Component } from 'react';
import PropTypes from 'prop-types';

import { Timer } from '~/common/views'; // eslint-disable-line import/no-unresolved
import styles from '../Login.scss';

class Otp extends Component {

    constructor(props) {
        super(props);
        this.enterKeyDownForOtp = this.enterKeyDownForOtp.bind(this);
    }

    componentDidUpdate() {
        const { doneRequestOtp } = this.props;
        if (doneRequestOtp) {
            setTimeout(() => this.optInputEl && this.optInputEl.focus(), 400);
        }
    }

    enterKeyDownForOtp(e) {
        if (e.keyCode === 13) {
            const { login } = this.props;
            login();
        }
    }

    render() {
        const { changeOtp, otpTimeout, doneRequestOtp, login } = this.props;
        const secondsForTimer = 300;

        return [
            <div key="login-otp-input" className="login-basic-color">
                <label className={styles.login_panel}>
                    <i className={[styles.icon, styles.password].join(' ')} />
                    <input
                        type="password"
                        placeholder="One Time Password"
                        maxLength="50"
                        onChange={changeOtp}
                        onKeyDown={this.enterKeyDownForOtp}
                        ref={el => { this.optInputEl = el; }}
                        disabled={!doneRequestOtp} />
                </label>
                { doneRequestOtp && <Timer className={styles.login_opt_timer} operatingTime={secondsForTimer} whenTimeZeroFunction={otpTimeout} /> }
            </div>,
            <button
                type="button"
                key="login-confirm-otp-button"
                className={styles.login_button}
                onClick={login}
                disabled={!doneRequestOtp}>
                {'Login'}
            </button>
        ];
    }

}

export default Otp;

Otp.propTypes = {
    doneRequestOtp: PropTypes.bool.isRequired,
    login: PropTypes.func.isRequired,
    changeOtp: PropTypes.func.isRequired,
    otpTimeout: PropTypes.func
};

Otp.defaultProps = {
    otpTimeout: () => {}
};
