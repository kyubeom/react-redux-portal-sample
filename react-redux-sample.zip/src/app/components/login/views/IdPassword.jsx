import React, { Component } from 'react';
import { isNil } from 'lodash';
import PropTypes from 'prop-types';
import styles from '../Login.scss';

class IdPasswordPanel extends Component {

    componentDidMount() {
        this.loginIdInput.focus();
    }

    componentDidUpdate() {
        const { doneRequestOtp } = this.props;
        if (doneRequestOtp === false) { // otp 만료
            setTimeout(() => {
                if (!isNil(this.loginIdInput)) {
                    this.loginIdInput.value = null;
                    this.passwordInput.value = null;
                    this.loginIdInput.focus();
                }
            }, 400);
        }
    }

    enterKeyDownForPassword(e) {
        if (e.keyCode === 13) {
            const { issueOtp } = this.props;
            issueOtp();
        }
    }

    render() {
        const { issueOtp, changeID, changePassword, doneRequestOtp } = this.props;

        return [
            <div key="login-id-password-input">
                <label className={styles.login_panel}>
                    <i className={[styles.icon, styles.id].join(' ')} />
                    <input
                        type="text"
                        placeholder="Login ID"
                        maxLength="50"
                        ref={el => { this.loginIdInput = el; }}
                        onChange={changeID}
                        disabled={doneRequestOtp} />
                </label>
                <label className={styles.login_panel}>
                    <i className={[styles.icon, styles.password].join(' ')} />
                    <input
                        type="password"
                        placeholder="Password"
                        maxLength="50"
                        onChange={changePassword}
                        ref={el => { this.passwordInput = el; }}
                        onKeyDown={event => this.enterKeyDownForPassword(event)}
                        disabled={doneRequestOtp} />
                </label>
            </div>,
            <button
                type="button"
                key="login-otp-button"
                className={styles.otp_button}
                onClick={issueOtp}
                disabled={doneRequestOtp}>
                {'Get OTP'}
            </button>
        ];
    }

}

export default IdPasswordPanel;

IdPasswordPanel.propTypes = {
    doneRequestOtp: PropTypes.bool.isRequired,
    issueOtp: PropTypes.func.isRequired,
    changeID: PropTypes.func.isRequired,
    changePassword: PropTypes.func.isRequired
};
