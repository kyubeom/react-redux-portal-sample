import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { isArray, isNil, isEmpty } from 'lodash';

import { SelectBox } from '~/common/views'; // eslint-disable-line import/no-unresolved
import { CODE_TABLE_MAPPING_RULE_FOR_SELECTBOX } from '~/common/utils/Language'; // eslint-disable-line import/no-unresolved
import styles from '../Login.scss';

function isNeedUpdateState(prev, next) {
    if (isNil(prev) && !isNil(next)) {
        return true;
    }

    if (isArray(prev) && isArray(next) && prev.length !== next.length) {
        return true;
    }

    return false;
}

class LangAndTimezone extends Component {

    constructor(props) {
        super(props);

        const { timezoneItems, langItems, langCode, timezone } = this.props;

        this.state = {
            timezoneItems: timezoneItems || [],
            langItems: langItems || [],
            langCode,
            timezone
        };
    }

    static getDerivedStateFromProps(nextProps, currentStatus) {
        let changed = {};

        if (isNeedUpdateState(currentStatus.timezoneItems, nextProps.timezoneItems)) {
            changed = Object.assign(changed, { timezoneItems: nextProps.timezoneItems });
        }

        if (isNeedUpdateState(currentStatus.langItems, nextProps.langItems)) {
            changed = Object.assign(changed, { langItems: nextProps.langItems });
        }

        if (!isEmpty(changed)) {
            return changed;
        }

        return null;
    }

    render() {
        const { changeTimezone, changeLanguage } = this.props;
        const { timezoneItems, langItems, timezone, langCode } = this.state;

        return (
            <div className={styles.login_box_container}>
                <table className={[styles.login_box_item, styles.login_box_layout, styles.login_table_plain, styles.left].join(' ')}>
                    <tbody>
                        <tr>
                            <td>
                                <SelectBox
                                    options={timezoneItems}
                                    onChange={value => changeTimezone(value)}
                                    defaultValue={timezone}
                                    configs={{ 'mappingRule': CODE_TABLE_MAPPING_RULE_FOR_SELECTBOX }}
                                    className={styles.login_selectbox} />
                            </td>
                        </tr>
                    </tbody>
                </table>
                <table className={[styles.login_box_item, styles.login_box_layout, styles.login_table_plain, styles.right].join(' ')}>
                    <tbody>
                        <tr>
                            <td>
                                <SelectBox
                                    options={langItems}
                                    onChange={value => changeLanguage(value)}
                                    defaultValue={langCode}
                                    configs={{ 'mappingRule': CODE_TABLE_MAPPING_RULE_FOR_SELECTBOX }}
                                    className={styles.login_selectbox} />
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        );
    }

}

export default LangAndTimezone;


LangAndTimezone.propTypes = {
    timezoneItems: PropTypes.array.isRequired,
    langItems: PropTypes.array.isRequired,
    langCode: PropTypes.string,
    timezone: PropTypes.string,
    changeTimezone: PropTypes.func.isRequired,
    changeLanguage: PropTypes.func.isRequired
};

LangAndTimezone.defaultProps = {
    langCode: '001',
    timezone: '186'
};
