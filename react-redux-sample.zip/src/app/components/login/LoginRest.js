import { $http } from '~/common'; // eslint-disable-line import/no-unresolved

class LoginRest {

    static loggingForInvalidOtp(loginId) {
        if (!loginId) {
            return false;
        }

        const params = { loginId };
        return $http.get('/adm/cmm/ap/invalidOtp', { params });
    }

}

export default LoginRest;
