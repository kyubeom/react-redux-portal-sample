import React, { Component } from 'react';
import { isNil as _isNil } from 'lodash';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';

/* eslint-disable import/no-unresolved */
import AuthenticationRest from '~/common/service/auth/AuthenticationRest';
import { withAdminCommonHOC } from '~/common/hoc';
import { sessionOperations } from '~/state/session';
import { localeOperations } from '~/state/locale';
/* eslint-disable import/no-unresolved */

import LoginService from './LoginService';
import LoginRest from './LoginRest';
import { IdPassword, LangAndTimezone, Otp } from './views';

import styles from './Login.scss';
import i18nResource from './i18n.json';

class Login extends Component {

    constructor(props) {
        super(props);
        const defaultLanguge = { code: '001', name: '한국어' };

        this.state = {
            doneRequestOtp: false,
            langItems: [],
            timezoneItems: [],
            langCode: defaultLanguge.code,
            timezoneCode: '186',
        };

        this.i18n = props.i18n;
        this.dialog = props.dialog;
        this.redux = props.redux;

        this.changeID = this.changeID.bind(this);
        this.changePassword = this.changePassword.bind(this);
        this.changeOtp = this.changeOtp.bind(this);
        this.changeLanguage = this.changeLanguage.bind(this);
        this.changeTimezone = this.changeTimezone.bind(this);
        this.issueOtp = this.issueOtp.bind(this);
        this.login = this.login.bind(this);
        this.otpTimeout = this.otpTimeout.bind(this);
    }

    componentDidMount() {
        LoginService.retriveLangAndTimeZone().then(data => {
            this.languageMap = data.lang.map;
            this.setState({ langItems: data.lang.items });

            this.timezoneMap = data.timezone.map;
            this.setState({ timezoneItems: data.timezone.items });
        });
    }

    static getDerivedStateFromProps(nextProps, currentStatus) {
        if (!_isNil(nextProps.language) && nextProps.language.code !== currentStatus.langCode) {
            return { langCode: nextProps.language.code };
        }
        return null;
    }

    changeID(event) {
        this.id = event.target.value;
    }

    changePassword(event) {
        this.password = event.target.value;
    }

    changeOtp(event) {
        this.otp = event.target.value;
    }

    changeLanguage(changed) {
        const { langCode } = this.state;
        if (langCode !== changed) {
            this.redux.changeLanguage({
                code: changed,
                name: this.languageMap.get(changed)
            });
        }
    }

    changeTimezone(changed) {
        const { timezoneCode } = this.state;
        if (timezoneCode !== changed) {
            this.setState({ changed });
        }
    }

    otpTimeout() {
        LoginRest.loggingForInvalidOtp(this.id).then(() => {
            this.dialog.alert(this.i18n.t('login.otp.expired'), {
                okAction: () => { this.setState({ doneRequestOtp: false }); }
            });
        });
    }

    issueOtp() {
        const { id, password } = this;
        const { langCode, timezoneCode } = this.state;

        if (_isNil(id) || _isNil(password)) {
            this.dialog.alert(this.i18n.t('login.authentication.error.70491'));
            return;
        }

        AuthenticationRest
            .login({ id, password, langCode, timezoneCode })
            .then(() => {
                const okAction = () => {
                    this.setState({ doneRequestOtp: true });
                };
                this.dialog.alert(this.i18n.t('login.otp.send.success'), { okAction });
            }).catch(error => {
                LoginService.alertForAuthenticationException(error, this);
            });
    }

    login() {
        const { id, password, otp } = this;

        if (_isNil(otp)) {
            this.dialog.alert(this.i18n.t('login.authentication.error.70496'));
            return;
        }

        const { langCode, timezoneCode } = this.state;
        const langName = this.languageMap.get(langCode);
        const timezoneName = this.timezoneMap.get(timezoneCode);
        AuthenticationRest.confirmOtp({ id, password, langCode, timezoneCode, otp, langName, timezoneName }).then(response => {
            LoginService.actionAfterOtpConfirmSuccess(response, this);
        }, error => {
            LoginService.alertForAuthenticationException(error, this);
        });
    }

    render() {
        return (
            <div className={styles.login_container}>
                <div className={styles.login_inline}>
                    <IdPassword
                        {...this.state}
                        changeID={this.changeID}
                        changePassword={this.changePassword}
                        issueOtp={this.issueOtp} />
                    <Otp
                        {...this.state}
                        changeOtp={this.changeOtp}
                        otpTimeout={this.otpTimeout}
                        login={this.login} />
                    <LangAndTimezone
                        changeLanguage={this.changeLanguage}
                        changeTimezone={this.changeTimezone}
                        {...this.state} />
                </div>
            </div>
        );
    }

}


const mapStateToProps = state => ({ language: state.locale.language });

const mapDispatchToProps = dispatch => ({
    'redux': {
        activeSession(session) {
            dispatch(sessionOperations.activeSession(session));
        },
        changeLanguage(language) {
            dispatch(localeOperations.changeLanguage(language));
        },
        changeTimezone(timezone) {
            dispatch(localeOperations.changeTimezone(timezone));
        }
    }
});


const connected = connect(mapStateToProps, mapDispatchToProps)(Login);
const withHOC = withAdminCommonHOC(withRouter(connected), i18nResource);

export default withHOC;
