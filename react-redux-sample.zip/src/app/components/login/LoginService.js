import { isNil } from 'lodash';

import { AuthenticationService } from '../../common/service/auth';
import { LanguageRest, TimeZoneRest } from '../../common/service/locale';
import { CODE_TABLE_MAPPING_RULE_FOR_SELECTBOX } from '../../common/utils/Language';

class LoginService {

    static getDefaultMessageKey({ i18n, desc }) {
        return i18n.t('login.authentication.error.unexcepted') + (isNil(desc) ? '' : (` : ${desc}`));
    }

    // static isLoginSuccess(responseData) {
    //     return !!responseData && !!responseData.adminTuid && responseData.adminStatCd === 'A';
    // }

    static actionAfterOtpConfirmSuccess(data, context) {
        AuthenticationService.activateSession(data).then(session => {
            const { redux, timezoneCode } = context;
            redux.activeSession(session);
            redux.changeLanguage({
                code: session.locale.language.code,
                name: session.locale.language.name
            });
            redux.changeTimezone({
                'offset': data.SESSION.timeDiff,
                'name': data.SESSION.timeZoneNm,
                'code': timezoneCode
            });
        });
    }

    static alertForAuthenticationException({ resultCode, desc }, context) {
        const { dialog, i18n, otpTimeout } = context;

        if (resultCode === '70495') {
            otpTimeout();
            return;
        }

        let message = i18n.t(`login.authentication.error.${resultCode}`);
        if (isNil(message)) {
            message = this.getDefaultMessageKey({ i18n, desc });
        }
        dialog.alert(message);
    }

    static retriveLangAndTimeZone() {
        return Promise.all([LanguageRest.retrieve(), TimeZoneRest.retrieve()]).then(values => {
            const langItems = values[0];
            const langMap = new Map();
            langItems.forEach(lang => {
                langMap.set(lang[CODE_TABLE_MAPPING_RULE_FOR_SELECTBOX.value], lang[CODE_TABLE_MAPPING_RULE_FOR_SELECTBOX.text]);
            });

            const timezoneItems = values[1];
            const timezoneMap = new Map();
            timezoneItems.forEach(tiemzone => {
                timezoneMap.set(tiemzone[CODE_TABLE_MAPPING_RULE_FOR_SELECTBOX.value], tiemzone[CODE_TABLE_MAPPING_RULE_FOR_SELECTBOX.text]);
            });

            return {
                lang: { items: langItems, map: langMap },
                timezone: { items: timezoneItems, map: timezoneMap }
            };
        });
    }

}

export default LoginService;
