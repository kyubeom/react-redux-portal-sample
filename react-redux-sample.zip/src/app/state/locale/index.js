import reducer from './reducers';

import * as localeOperations from './operations';

export {
    localeOperations
};

export default reducer;
