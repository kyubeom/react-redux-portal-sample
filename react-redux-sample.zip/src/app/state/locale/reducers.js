import * as types from './types';

import { isNil } from 'lodash';
import { LOCALE_KEY } from '~/common/utils/Language'; // eslint-disable-line import/no-unresolved

const defaultState = {
    language: {
        key: 'ko',
        code: '001',
        name: '한국어'
    },
    timezone: {
        code: '186',
        name: 'UTC +9 Korea standard',
        offset: 540
    }
};

const locale = (state = {}, action = {}) => {
    switch (action.type) {
    case types.CHANGE_LANGUAGE: {
        const { language } = action;
        if (!isNil(language.code) && isNil(language.key)) {
            language.key = LOCALE_KEY[language.code];
        }
        return Object.assign({}, defaultState, state, { language });
    }
    case types.CHANGE_TIMEZONE:
        return Object.assign({}, defaultState, state, {
            timezone: action.timezone
        });
    default:
        return state;
    }
};

export default locale;
