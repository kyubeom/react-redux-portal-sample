/* eslint-disable */
export const CHANGE_TIMEZONE = 'CHANGE_TIMEZONE';
export const CHANGE_LANGUAGE = 'CHANGE_LANGUAGE';