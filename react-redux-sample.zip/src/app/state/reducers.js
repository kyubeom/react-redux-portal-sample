import { combineReducers } from 'redux';
import session from './session';
import locale from './locale';
import loading from './loading';
import userAccount from './userAccount';

export default combineReducers({
    session,
    locale,
    loading,
    userAccount
});
