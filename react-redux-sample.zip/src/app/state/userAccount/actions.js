import * as types from './types';

export function requestUserSearchParam() {
    return {
        type: types.REQUEST_USER_SEARCH_PARAM,
        payload: {}
    };
}

export function requestUserList(params) {
    return {
        type: types.REQUEST_USER_SEARCH,
        payload: params
    };
}
