import { all, call, put, takeLatest } from 'redux-saga/effects';

import * as types from './types';
import UserAccountRest from '../../components/userAccount/UserAccountRest';

// all : 여러 비동기 호출을 묶어서 처리 (promise.all 같은 것)
// call : 비동기 요청 promise 처리 호출 함수.
// put : event 등록 함수 - redux reducer 에 이벤트 전달을 하는 역할
function* requestUserSearchParam() {
    yield put({ type: types.EXECUTE_SELECT_USER_SEARCH_PARAM });

    try {
        // 필요시 action.payload 에 필요한 파라미터를 보낸다. (redux payload 처럼)
        const userSearchParam = yield all({
            userStateList: call(UserAccountRest.getUserStateList),
            userSectList: call(UserAccountRest.getUserSectList),
            billingSectList: call(UserAccountRest.getBliingSectList)
        });
        yield put({ type: types.DONE_SELECT_USER_SEARCH_PARAM, userSearchParam });
    } catch (e) {
        yield put({ type: types.FAIL_SELECT_USER_SEARCH_PARAM });
    }
}

function* requestUserList(actions) {
    yield put({ type: types.EXECUTE_SELECT_USER_LIST });
    try {
        // 필요시 action.payload 에 필요한 파라미터를 보낸다. (redux payload 처럼)
        const userList = yield call(UserAccountRest.getUserList, actions.payload);
        yield put({ type: types.DONE_SELECT_USER_LIST, userList });
    } catch (e) {
        yield put({ type: types.FAIL_SELECT_USER_LIST });
    }
}

// takeEvery : 들어온 모든 요청을 처리한다.
// function* userAccountSaga() {
//     yield takeEvery("USER_SEARCH_PARAM_REQUESTED", requestUserSearchParam);
// }

// takeLatest : 기존 요청을 취소하고 마지막 들어온 요청만 처리한다.
function* userAccountSaga() {
    yield all([
        takeLatest(types.REQUEST_USER_SEARCH_PARAM, requestUserSearchParam),
        takeLatest(types.REQUEST_USER_SEARCH, requestUserList)
    ]);
}

// function* userAccountSaga() {
//     yield takeLatest(types.REQUEST_USER_SEARCH, requestUserList);
// }

export default userAccountSaga;
