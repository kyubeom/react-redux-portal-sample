import * as types from './types';

const defaultState = {
    userSearchParam: {},
    userListResultMap: {}
};

const userAccount = (state = {}, action = {}) => {
    switch (action.type) {
    case types.DONE_SELECT_USER_SEARCH_PARAM:
        return Object.assign({}, defaultState, state, { userSearchParam: action.userSearchParam });
    case types.FAIL_SELECT_USER_SEARCH_PARAM:
        return Object.assign({}, defaultState, state, action);
    case types.DONE_SELECT_USER_LIST:
        return Object.assign({}, defaultState, state, { userListResultMap: action.userList });
    case types.FAIL_SELECT_USER_LIST:
        return Object.assign({}, defaultState, state, action);
    default:
        return Object.assign({}, defaultState, state);
    }
};

export default userAccount;
