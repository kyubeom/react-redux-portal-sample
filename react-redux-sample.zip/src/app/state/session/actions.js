import * as types from './types';
import SessionConstant from '~/common/utils/SessionConstant'; // eslint-disable-line import/no-unresolved

const SESSION_STATE_NONE = {
    authToken: null,
    state: SessionConstant.SESSION_STATE.NONE,
    access: {},
    adminUser: {},
    environment: {},
    locale: {
        language: {},
        timezone: {},
    },
};

export function activeSession(session) {
    return {
        type: types.ACTIVATE_SESSION,
        session: Object.assign(session, { state: SessionConstant.SESSION_STATE.ACTIVE })
    };
}

export function removeSession() {
    return {
        type: types.REMOVE_SESSION,
        session: SESSION_STATE_NONE
    };
}

export function changeSessionTenent(tenantId) {
    return {
        type: types.CHANGE_SESSION_TENENT,
        session: { adminUser: { tenantId } }
    };
}

export function verifyingSession() {
    return {
        type: types.VERIFYING_SESSION,
        session: { state: SessionConstant.SESSION_STATE.CHECKING }
    };
}
