import * as types from './types';

const defaultState = {
    activeSession: false
};

const session = (state = {}, action = {}) => {
    switch (action.type) {
    case types.ACTIVATE_SESSION:
        return Object.assign({}, defaultState, state, action.session);
    case types.REMOVE_SESSION:
        return Object.assign({}, defaultState, state, action.session);
    case types.CHANGE_SESSION_TENENT:
        return Object.assign({}, defaultState, state, action.session);
    case types.VERIFYING_SESSION:
        return Object.assign({}, defaultState, state, action.session);
    default:
        return state;
    }
};

export default session;
