/* eslint-disable */
export const LOADING_DATA = 'LOADING_DATA';
export const LOADING_COMPLETED = 'LOADING_COMPLETED';