import * as types from './types';

export function loadingData(from) {
    return {
        type: types.LOADING_DATA,
        from
    };
}

export function completeLoading(from) {
    return {
        type: types.LOADING_COMPLETED,
        from
    };
}
