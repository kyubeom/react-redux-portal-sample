import { isEmpty } from 'lodash';

import * as types from './types';

const FETCH_LIST = {};
const defaultState = {
    going: false
};
const loading = (state = {}, action = {}) => {
    switch (action.type) {
    case types.LOADING_DATA: {
        const hasPrevLoading = !isEmpty(FETCH_LIST);
        FETCH_LIST[action.from] = true;
        if (hasPrevLoading) {
            return state;
        }
        return Object.assign({}, defaultState, state, { going: true });
    }
    case types.LOADING_COMPLETED: {
        delete FETCH_LIST[action.from];
        if (isEmpty(FETCH_LIST)) {
            return Object.assign({}, defaultState, state, { going: false });
        }
        return state;
    }
    default:
        return state;
    }
};

export default loading;
