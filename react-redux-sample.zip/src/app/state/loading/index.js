import reducer from './reducers';

import * as loadingOperations from './operations';

export {
    loadingOperations
};

export default reducer;
