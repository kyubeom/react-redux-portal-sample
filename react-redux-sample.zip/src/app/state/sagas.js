import { fork } from 'redux-saga/effects';

import userAccountSaga from './userAccount/sagas';

function* rootSaga() {
    yield [
        fork(userAccountSaga)
    ];
}

export default rootSaga;
