const CODE_TABLE_MAPPING_RULE_FOR_SELECTBOX = {
    'value': 'cdValidVal',
    'text': 'th1CdValidValNm',
};

const LOCALE_KEY = {
    '001': 'ko',
    '002': 'en',
    '003': 'zh',
};

export { CODE_TABLE_MAPPING_RULE_FOR_SELECTBOX, LOCALE_KEY };
