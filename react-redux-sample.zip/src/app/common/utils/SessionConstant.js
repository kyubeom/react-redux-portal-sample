const SESSION_COOKIE_NAME = 'efss_admin_session';
const SESSION_STATE = {
    ACTIVE: 'ACTIVE',
    NONE: 'NONE',
    CHECKING: 'CHECKING'
};

export default {
    SESSION_COOKIE_NAME,
    SESSION_STATE
};
