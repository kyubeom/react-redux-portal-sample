import axios from 'axios';
import Cookies from 'js-cookie';

/* eslint-disable import/no-unresolved */
import store from '~/state/store';
import { sessionOperations } from '~/state/session';
import { loadingOperations } from '~/state/loading';
/* eslint-disable import/no-unresolved */

import AuthenticationService from './service/auth/AuthenticationService';

axios.defaults.headers.post['Content-Type'] = 'application/json';

// Add a request interceptor
axios.interceptors.request.use(config => {
    const configAddedToken = config;
    configAddedToken.headers.authToken = Cookies.get('authToken');
    store.dispatch(loadingOperations.loadingData(config.url));
    return configAddedToken;
}, error => Promise.reject(error.response.data));

// Add a response interceptor
axios.interceptors.response.use(
    success => {
        const { data, config } = success;
        store.dispatch(loadingOperations.completeLoading(config.url));
        return data;
    },
    error => {
        const { response, config } = error;
        if (response.data === 70000) {
            AuthenticationService.removeWebappSession().then(() => store.dispatch(sessionOperations.removeSession()));
        }
        store.dispatch(loadingOperations.completeLoading(config.url));
        return Promise.reject(response.data);
    }
);

class $http {

    constructor() {
        throw new Error('Cannot construct singleton');
    }

    static request(config) {
        return axios.request(config);
    }

    static get(uri, config) {
        return axios.get(uri, config);
    }

    static post(uri, data, config) {
        return axios.post(uri, data, config);
    }

    static put(uri, data, config) {
        return axios.put(uri, data, config);
    }

    static delete(uri, config) {
        return axios.delete(uri, config);
    }

    static head(uri, config) {
        return axios.head(uri, config);
    }

    static options(uri, config) {
        return axios.options(uri, config);
    }

    static patch(uri, config) {
        return axios.patch(uri, config);
    }

}

export default $http;
