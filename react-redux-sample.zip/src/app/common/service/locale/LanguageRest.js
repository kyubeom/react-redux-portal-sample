import { isEmpty, isArray } from 'lodash';
import $http from '../../Http';

let langauges = [];

class LanguageRest {

    static retrieve({ page = 1, start = 0, limit = 25 } = {}) {
        if (isArray(langauges) && !isEmpty(langauges)) {
            return Promise.resolve(langauges);
        }

        const params = { page, start, limit };
        return $http.get('/adm/cmm/ap/selectListLanguage', { params }).then(langs => {
            if (isArray(langs) && !isEmpty(langs)) {
                langauges = langs;
            }
            return langs;
        });
    }

}

export default LanguageRest;
