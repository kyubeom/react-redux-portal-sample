import { isEmpty, isArray } from 'lodash';
import $http from '../../Http';

let timezones = [];

class TimeZoneRest {

    static retrieve() {
        if (isArray(timezones) && !isEmpty(timezones)) {
            return Promise.resolve(timezones);
        }
        return $http.get('/adm/cmm/ap/selectListTimezone').then(data => {
            if (isArray(data) && !isEmpty(data)) {
                timezones = data;
            }
            return data;
        });
    }

}

export default TimeZoneRest;
