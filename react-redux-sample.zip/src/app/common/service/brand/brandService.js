
class BrandService {

    static setBrandNameAyDocumentTitle(name) {
        document.title = name;
    }

}

export default BrandService;
