import { isNil } from 'lodash';
import $http from '../../Http';

let brandName;

class BrandRest {

    static retrieveName() {
        if (!isNil(brandName)) {
            return Promise.resolve(brandName);
        }

        return $http.get('/adm/cmm/ap/selectBrand').then(name => {
            brandName = name;
            return name;
        });
    }

}

export default BrandRest;
