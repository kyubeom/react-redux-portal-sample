import BrandRest from './brandRest';
import BrandService from './brandService';

export { BrandRest, BrandService };
