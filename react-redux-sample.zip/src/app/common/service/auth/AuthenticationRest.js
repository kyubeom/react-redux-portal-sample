import { $http } from '~/common'; // eslint-disable-line import/no-unresolved

class AuthenticationRest {

    static login({ id, password, langCode, timezoneCode, }) {
        const body = {
            'adminLoginId': id,
            'adminPwd': password,
            'langCd': langCode,
            'timeZoneCd': timezoneCode
        };
        return $http.post('/adm/cmm/ap/getOtp', body);
    }

    static confirmOtp({ id, password, langCode, timezoneCode, otp, langName, timezoneName }) {
        const body = {
            'adminLoginId': id,
            'adminPwd': password,
            'langCd': langCode,
            'timeZoneCd': timezoneCode,
            'otp': otp,
            'langNm': langName,
            'timeZoneNm': timezoneName
        };
        return $http.post('/adm/cmm/ap/login', body);
    }

    static logout() {
        return $http.post('/adm/cmm/apmain/logout');
    }

}


export default AuthenticationRest;
