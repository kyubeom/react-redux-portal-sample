import Cookies from 'js-cookie';
import LegacyService from '../LegacyService';
import SessionConstant from '../../utils/SessionConstant';

class AuthenticationService {

    static removeWebappSession() {
        LegacyService.removeSessionCookie();
        Cookies.remove(SessionConstant.SESSION_COOKIE_NAME);
        return Promise.resolve();
    }


    static activateSession(auth) {
        return LegacyService.setSessionCookieForLegacy(auth).then(() => {
            const session = {
                authToken: auth.SESSION.authToken,
                state: SessionConstant.SESSION_STATE.ACTIVE,
                access: {
                    ip: auth.SESSION.accessIp,
                    dateTime: auth.SESSION.lastActDtm,
                    userAgent: auth.SESSION.userAgent,
                },
                adminUser: {
                    email: auth.adminEmailAddr,
                    userId: auth.adminUserId,
                    loginId: auth.SESSION.adminLoginId,
                    tenantId: auth.SESSION.coCdVal,
                },
                environment: {
                    serviceType: auth.SVR_TYPE || 'internal',
                    moblieSupport: auth.MOBILE_SUPPORT_YN === 'Y',
                },
                locale: {
                    language: {
                        'code': auth.LANG_CD,
                        'name': auth.LANG_NM,
                    },
                    timezone: {
                        'offset': parseInt(auth.SESSION.timeDiff, 10),
                        'name': auth.TIMEZONE_NM,
                        'code': auth.TIMEZONE_CD,
                    },
                },
            };

            this.setSessionCookie(session);
            return Promise.resolve(session);
        });
    }

    static setSessionCookie(session) {
        const secure = window.location.protocol === 'https:';
        Cookies.set(SessionConstant.SESSION_COOKIE_NAME, JSON.stringify(session), { secure });
    }

    static changeTenantInCookie(tenantId) {
        const session = Cookies.get(SessionConstant.SESSION_COOKIE_NAME);
        if (session !== undefined && session !== null) {
            const changed = JSON.parse(session);
            changed.adminUser.tenantId = tenantId;
            AuthenticationService.setSessionCookie(changed);
            LegacyService.setTenantIdInCookie(tenantId);
        }
        return Promise.resolve(true);
    }

}

export default AuthenticationService;
