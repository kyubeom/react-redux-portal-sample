import Cookies from 'js-cookie';

const secure = window.location.protocol === 'https:';

function encrypt(theText) {
    let output = '';
    const Temp = [];
    const Temp2 = [];
    const TextSize = theText.length;
    for (let i = 0; i < TextSize; i += 1) {
        const rnd = Math.round(Math.random() * 122) + 68;
        Temp[i] = theText.charCodeAt(i) + rnd;
        Temp2[i] = rnd;
    }
    for (let i = 0; i < TextSize; i += 1) {
        output += String.fromCharCode(Temp[i], Temp2[i]);
    }
    return output;
}

const setSessionCookieForLegacy = authResponse => {
    const response = authResponse;
    response.SESSION.A1 = encrypt(response.SESSION.adminLoginId);
    delete response.SESSION.adminStatCd;

    Cookies.set('authToken', response.SESSION.authToken, { secure });
    Cookies.set('auth_token', response.SESSION.authToken, { secure });
    Cookies.set('langCd', response.SESSION.langCd, { secure });
    Cookies.set('svrType', response.SVR_TYPE, { secure });
    Cookies.set('mobileSupportYn', response.MOBILE_SUPPORT_YN, { secure });
    Cookies.set('today', response.TODAY, { secure });
    Cookies.set('coCdVal', response.SESSION.coCdVal, { secure });

    const jsonString = JSON.stringify(authResponse.SESSION);
    const encoded = encodeURIComponent(jsonString);
    const CookiesWithNotEncodingValue = Cookies.withConverter({
        read: f => f,
        write: value => value
    });
    CookiesWithNotEncodingValue.set('SESSION', encoded, { secure });

    return Promise.resolve(response).then(data => data);
};

const removeSessionCookie = () => {
    Cookies.remove('SESSION');
    Cookies.remove('auth_token');
    Cookies.remove('langCd');
    Cookies.remove('svrType');
    Cookies.remove('mobileSupportYn');
    Cookies.remove('today');
    Cookies.remove('coCdVal');
};

const setBrandNameAtCookie = name => {
    Cookies.set('brandName', name);
};

const setTenantIdInCookie = tenantId => {
    Cookies.set('coCdVal', tenantId, { secure });
};

const addApiCallEventListener = action => {
    window.addEventListener('message', action);
};

const LegacyService = {
    removeSessionCookie,
    setSessionCookieForLegacy,
    setBrandNameAtCookie,
    setTenantIdInCookie,
    addApiCallEventListener
};

export default LegacyService;
