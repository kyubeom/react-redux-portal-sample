import React, { Component } from 'react';
import Dialog from 'react-bootstrap-dialog';
import $ from 'jquery';
import { noop as _noop } from 'lodash';
import PropTypes from 'prop-types';

class DialogComponent extends Component {

    constructor(props) {
        super(props);
        this.alert = this.alert.bind(this);
        this.confirm = this.confirm.bind(this);

        this.i18n = props.i18n || { t: f => f };

        Dialog.setOptions({
            defaultOkLabel: this.i18n.t('dialog.ok'),
            defaultCancelLabel: this.i18n.t('dialog.cancel')
        });
    }

    alert(message, { okAction, bsSize } = {}) {
        const okFunc = okAction || _noop;

        this.dialog.show({
            body: message,
            actions: [
                Dialog.OKAction(() => okFunc())
            ],
            bsSize
        });

        // alert창 open후에 ok버튼 포커싱 위해, 추후 리팩토링 요소..
        setTimeout(() => {
            $('div[role = dialog] button').focus();
        });
    }

    confirm(message, { okAction, cancelAction, bsSize } = {}) {
        const okFunc = okAction || _noop;
        const cancelFunc = cancelAction || _noop;

        this.dialog.show({
            body: message,
            actions: [
                Dialog.Action(
                    this.i18n.t('dialog.cancel'),
                    cancelFunc
                ),
                Dialog.Action(
                    this.i18n.t('dialog.ok'),
                    okFunc,
                    'btn-primary'
                )
            ],
            bsSize
        });
    }


    render() {
        const dialog = {
            alert: this.alert,
            confirm: this.confirm,
        };

        const { render } = this.props;

        return (
            <React.Fragment>
                <Dialog ref={el => { this.dialog = el; }} />
                { render(dialog) }
            </React.Fragment>
        );
    }

}

export default DialogComponent;

DialogComponent.propTypes = {
    render: PropTypes.func.isRequired
};
