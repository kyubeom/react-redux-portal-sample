import React, { Component } from 'react';

import withI18n from '../i18n/Message';
import i18nResource from './i18n.json';
import DialogComponent from './Dialog';

const DialogComponentWithI18n = withI18n(DialogComponent, i18nResource);

function withDialog(Target) {
    return class extends Component { // eslint-disable-line react/prefer-stateless-function

        render() {
            return (
                <DialogComponentWithI18n render={dialog => (
                    <Target {...this.props} dialog={dialog} />
                )} />
            );
        }

    };
}

export default withDialog;
