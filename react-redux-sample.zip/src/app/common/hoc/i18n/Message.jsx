import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { isNil, get } from 'lodash';

const PLACE_HOLDER = /\${([\d]+?|[a-zA-Z][a-zA-Z0-9]*?(?:\.[a-zA-Z0-9]+?)*?)\}/g;

function setMessageWithLocale(key, i18nResource) {
    if (isNil(i18nResource) || isNil(i18nResource[key])) {
        return {};
    }
    return i18nResource[key];
}


class I18n extends Component {

    constructor(props) {
        super(props);
        const { i18nResource, language } = this.props;
        this.state = {
            i18nMsgMap: setMessageWithLocale(language.key, i18nResource),
            languageKey: language.key // eslint-disable-line react/no-unused-state
        };
        this.getMessage = this.getMessage.bind(this);
        this.generateProps = this.generateProps.bind(this);
    }

    static getDerivedStateFromProps(nextProps, currentState) {
        const { language, i18nResource } = nextProps;
        if (!isNil(language) && currentState.languageKey !== language.key) {
            return {
                i18nMsgMap: setMessageWithLocale(language.key, i18nResource),
                languageKey: language.key
            };
        }
        return null;
    }

    getMessage(key, params = {}) {
        if (isNil(key)) { return ''; }

        const languageKey = get(this.props, 'language.key');
        const { i18nMsgMap } = this.state;
        const msg = i18nMsgMap[key];
        if (isNil(msg)) {
            const currentLanguage = isNil(languageKey) ? '' : languageKey;
            return `${currentLanguage}:${key}`;
        }
        return msg.replace(PLACE_HOLDER, (matcher, placeHolder) => {
            const token = params[placeHolder];
            if (token === null || token === undefined) {
                return '';
            }
            return token;
        });
    }

    generateProps() {
        const sanitizedProps = Object.assign({}, this.props);
        delete sanitizedProps.sourceComponent;
        delete sanitizedProps.i18nResource;
        delete sanitizedProps.language;
        delete sanitizedProps.dispatch;
        return sanitizedProps;
    }

    render() {
        const i18n = { t: this.getMessage };
        const { SourceComponent } = this.props;
        const sanitizedProps = this.generateProps();
        return <SourceComponent i18n={i18n} {...sanitizedProps} />;
    }

}

const mapStateToProps = state => ({ language: state.locale.language });

const Connected = connect(mapStateToProps, null)(I18n);

const withI18n = (component, resource) => props => (<Connected i18nResource={resource} SourceComponent={component} {...props} />);

export default withI18n;

I18n.propTypes = {
    i18nResource: PropTypes.object.isRequired,
    SourceComponent: PropTypes.func.isRequired,
    language: PropTypes.object,
};

I18n.defaultProps = {
    language: { key: 'ko' }
};
