import withI18n from './Message';

export default withI18n;
