import { compose } from 'redux';
import withI18n from './i18n';
import withDialog from './dialog';

export default (component, i18nResource) => compose(
    withDialog,
    composed => withI18n(composed, i18nResource)
)(component);
