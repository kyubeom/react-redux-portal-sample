import $http from './Http';

export { $http }; // eslint-disable-line import/prefer-default-export
