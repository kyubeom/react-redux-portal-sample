import React, { Component } from 'react';
import PropTypes from 'prop-types';
import uuidv1 from 'uuid/v1';

import SelectBoxOption from './SelectBoxOption';

class SelectBox extends Component {

    constructor(props) {
        super(props);
        const { defaultValue, onChange } = props;
        this.state = { 'selectedValue': defaultValue };
        this.onChange = onChange;
    }

    changeSelectedItem(event) {
        if (this.onChange instanceof Function) {
            this.onChange(event.target.value);
        }

        this.setState({ 'selectedValue': event.target.value });
    }

    render() {
        const { options = [], className = '', disabled = false, configs = {} } = this.props;
        const { mappingRule, selectedStyle } = configs;
        const { selectedValue } = this.state;

        let converted = options;
        if (mappingRule instanceof Object) {
            const textProperty = mappingRule.text;
            const valueProperty = mappingRule.value;

            converted = options.map(item => {
                const newItem = {};
                newItem.text = item[textProperty];
                newItem.value = item[valueProperty];
                return newItem;
            });
        }

        return (
            <select
                className={className}
                name="admin-select-name"
                disabled={disabled}
                value={selectedValue}
                onChange={e => this.changeSelectedItem(e)}>
                { converted.map(item => <SelectBoxOption key={uuidv1()} option={item} selectedStyle={item.value === selectedValue ? selectedStyle : ''} />) }
            </select>
        );
    }

}

SelectBox.defaultProps = {
    disabled: false,
    className: '',
    configs: {},
    options: [],
    onChange: undefined,
    defaultValue: '',
};

SelectBox.propTypes = {
    defaultValue: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.number
    ]),
    onChange: PropTypes.func,
    options: PropTypes.array,
    className: PropTypes.string,
    disabled: PropTypes.bool,
    configs: PropTypes.object,
};

export default SelectBox;
