import React, { Component } from 'react';
import { isNil } from 'lodash';
import PropTypes from 'prop-types';

class Timer extends Component {

    constructor(props) {
        super(props);

        this.state = {
            renderedTime: '',
            initTimer: false // eslint-disable-line react/no-unused-state
        };
        const { operatingTime } = this.props;
        this.currentLeftSeconds = operatingTime;
        this.setTimer = this.setTimer.bind(this);
    }

    componentDidMount() {
        this.setTimer();
    }

    componentWillUnmount() {
        clearInterval(this.intervalObject);
    }

    setTimer() {
        this.intervalObject = setInterval(() => {
            if (this.currentLeftSeconds === 0) {
                this.stopTimer();
                const { whenTimeZeroFunction } = this.props;
                whenTimeZeroFunction();
                return;
            }
            this.currentLeftSeconds = this.currentLeftSeconds - 1;
            this.setState({ renderedTime: Timer.renderTime(this.currentLeftSeconds) });
        }, 1000);
    }

    UNSAFE_componentWillReceiveProps(nextProps) { // eslint-disable-line
        if (nextProps.initTimer) {
            this.currentLeftSeconds = nextProps.operatingTime + 1;
        }
    }

    stopTimer() {
        if (!isNil(this.intervalObject)) {
            clearInterval(this.intervalObject);
        }
    }

    static renderTime(leftSeconds) {
        // TODO timeFormat 어떤 게 있는거지....
        let minutes = Math.floor(leftSeconds / 60);
        let seconds = leftSeconds % 60;
        if (minutes < 10) {
            minutes = `0${minutes}`;
        }
        if (seconds < 10) {
            seconds = `0${seconds}`;
        }
        return `${minutes}:${seconds}`;
    }

    render() {
        const { className } = this.props;
        const { renderedTime } = this.state;
        return (
            <label className={className}>
                { renderedTime }
            </label>
        );
    }

}

export default Timer;


Timer.propTypes = {
    operatingTime: PropTypes.oneOfType([
        PropTypes.number,
        PropTypes.object
    ]),
    // timeFormat: PropTypes.string,
    whenTimeZeroFunction: PropTypes.func,
    className: PropTypes.string
};

Timer.defaultProps = {
    operatingTime: 60,
    // timeFormat: '',
    whenTimeZeroFunction: (() => {}),
    className: ''
};
