import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Pagination } from 'react-bootstrap';

import './PageNation.scss';

class PageNation extends Component {

    constructor(props) {
        super(props);
        const { forceAction, pageActionFunc } = props;
        this.forceAction = forceAction;
        this.pageActionFunc = pageActionFunc;

        this.pageClickEvent = this.pageClickEvent.bind(this);
        this.pageForwardMoveEvent = this.pageForwardMoveEvent.bind(this);
        this.pageBackworkMoveEvent = this.pageBackworkMoveEvent.bind(this);
    }

    getPageItems() {
        const totalPageCount = this.calculateTotalPageNum();
        const showPage = this.caculateShowPageNum(totalPageCount);

        const { selectedNum } = this.props;
        const items = [];

        items.push(
            <Pagination.First key={Math.random()} disabled={selectedNum === 1} onClick={() => this.pageBackworkMoveEvent(true)} />
        );

        items.push(
            <Pagination.Prev key={Math.random()} disabled={selectedNum === 1} onClick={() => this.pageBackworkMoveEvent()} />
        );

        for (let number = showPage.pageShowStartNum; number <= showPage.pageShowLastNum; number += 1) {
            items.push(
                <Pagination.Item key={Math.random()} active={selectedNum === number} onClick={() => this.pageClickEvent(number)}>
                    {number}
                </Pagination.Item>
            );
        }

        items.push(
            <Pagination.Next key={Math.random()} disabled={selectedNum === totalPageCount} onClick={() => this.pageForwardMoveEvent(totalPageCount)} />
        );

        items.push(
            <Pagination.Last key={Math.random()} disabled={selectedNum === totalPageCount} onClick={() => this.pageForwardMoveEvent(totalPageCount, true)} />
        );

        return items;
    }

    pageClickEvent(key) {
        const { selectedNum } = this.props;

        if (selectedNum !== key || this.forceAction) {
            this.pageActionFunc(key);
        }
    }

    pageForwardMoveEvent(totalPageCount, toLast) {
        const { selectedNum } = this.props;

        if (totalPageCount > selectedNum) {
            if (toLast) {
                this.pageActionFunc(totalPageCount);
            } else {
                this.pageActionFunc(selectedNum + 1);
            }
        }
    }

    pageBackworkMoveEvent(toFirst) {
        const { selectedNum } = this.props;

        if (selectedNum > 1) {
            if (toFirst) {
                this.pageActionFunc(1);
            } else {
                this.pageActionFunc(selectedNum - 1);
            }
        }
    }

    calculateTotalPageNum() {
        const { totalNum, pageLimitNum } = this.props;
        const totalPageCount = Math.ceil(totalNum / pageLimitNum);
        // 조회 총수가 아예 없을때에 페이지 1은 보여준다.
        return totalPageCount < 1 ? 1 : totalPageCount;
    }

    caculateShowPageNum(totalPageCount) {
        const { selectedNum } = this.props;
        // 선택된 번호가 양쪽 boundary 가 아니라면 항상 가운데 오도록 한다.
        let pageShowStartNum = selectedNum - 5;
        pageShowStartNum = pageShowStartNum < 1 ? 1 : (pageShowStartNum + 9);
        pageShowStartNum = pageShowStartNum >= totalPageCount ? totalPageCount - 9 : pageShowStartNum;
        const pageShowLastNum = totalPageCount > 10 ? (pageShowStartNum + 9) : totalPageCount;

        pageShowStartNum = pageShowStartNum < 1 ? 1 : pageShowStartNum;

        return {
            pageShowStartNum,
            pageShowLastNum
        };
    }

    render() {
        const pageItems = this.getPageItems();

        return (
            <Pagination>
                {pageItems}
            </Pagination>
        );
    }

}

// totalNum : 페이지 대상 카운트 총 수
// pageLimitNum : 한페이지 당 보여줄 갯수
// selectedNum : 현재 페이지 선택 번호
// forceAction : 같은 page 번호 눌러도 동작할것인가 여부
// pageActionFunc : 페이지 클릭시 동작 함수
PageNation.propTypes = {
    totalNum: PropTypes.number,
    pageLimitNum: PropTypes.number,
    selectedNum: PropTypes.number,
    forceAction: PropTypes.bool,
    pageActionFunc: PropTypes.func
};

// selectedNum : 최초 선택 번호 : 1, 버튼클릭시
// Force action : false (같은 page 번호 눌러도 동작할것인가 여부)
PageNation.defaultProps = {
    totalNum: 1,
    pageLimitNum: 10,
    selectedNum: 1,
    forceAction: false,
    pageActionFunc: undefined,
};

export default PageNation;
