import React from 'react';
import PropTypes from 'prop-types';

import rolling from '../../../assets/images/icon/rolling.svg';

const Loading = props => {
    const { isLoading } = props;
    if (isLoading) {
        return <img src={rolling} className="loading" alt="Loading" />;
    }
    return <React.Fragment />;
};

Loading.propTypes = {
    isLoading: PropTypes.bool,
};
Loading.defaultProps = {
    isLoading: false
};

export default Loading;

const withLoading = Component => {
    const wrapped = ({ isLoading, ...rest }) => (
        <Component {...rest}>
            <Loading isLoading={isLoading} />
        </Component>
    );
    wrapped.propTypes = {
        isLoading: PropTypes.bool.isRequired,
    };
    return wrapped;
};

withLoading.propTypes = {
    rest: PropTypes.object,
};

withLoading.defaultProps = {
    rest: {}
};

export { withLoading };
