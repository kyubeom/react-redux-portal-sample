import React, { Component } from 'react';

import PropTypes from 'prop-types';
import i18nResource from './i18n.json';
import { withAdminCommonHOC } from '../hoc/index';

import './SearchInputBox.scss';

class SearchInputBox extends Component {

    constructor(props) {
        super(props);
        this.searchKeyword = '';

        const { watchInputKeyword, minKeyWordLength, searchActionFunc, styles, maxLength, dialog, i18n } = props;
        this.watchInputKeyword = watchInputKeyword;
        this.minKeyWordLength = minKeyWordLength;
        this.searchActionFunc = searchActionFunc;
        this.styles = styles;
        this.maxLength = maxLength;
        this.dialog = dialog;
        this.i18n = i18n;

        this.inputOnChange = this.inputOnChange.bind(this);
        this.inputKeyDownEvent = this.inputKeyDownEvent.bind(this);
        this.doSearchEvent = this.doSearchEvent.bind(this);
    }

    shouldComponentUpdate(nextProps) {
        const { searchActionFunc, styles } = nextProps;
        if (searchActionFunc !== this.searchActionFunc) {
            return true;
        }

        if (styles !== this.styles) {
            return true;
        }

        return false;
    }

    inputOnChange(e) {
        this.searchKeyword = e.target.value;

        if (typeof this.watchInputKeyword === 'function') {
            this.watchInputKeyword(this.searchKeyword);
        }
    }

    inputKeyDownEvent(e) {
        if (e.keyCode === 13) this.doSearchEvent();
    }

    doSearchEvent() {
        if (this.searchKeyword.length < this.minKeyWordLength) {
            this.dialog.alert(this.i18n.t('views.searchInputBox.shortKeyword'), {
                okAction: () => { }
            });
        } else {
            this.searchActionFunc(this.searchKeyword);
        }
    }

    render() {
        return (
            <div>
                <div className="search_input_wrapper">
                    <input className="form-control" style={this.styles} maxLength={this.maxLength} onChange={e => this.inputOnChange(e)} onKeyUp={e => this.inputKeyDownEvent(e)} />
                </div>
                <div className="glyphicon glyphicon-search search_input_icon" aria-hidden="true" onClick={this.doSearchEvent} />
            </div>
        );
    }

}


// searchActionFunc : 찾기 동작시 수행할 함수 (키워드값을 파라미터로 받는다.)
SearchInputBox.propTypes = {
    searchActionFunc: PropTypes.func.isRequired,
    minKeyWordLength: PropTypes.number,
    styles: PropTypes.object,
    maxLength: PropTypes.number,
    watchInputKeyword: PropTypes.func,
};

// maxLength : input 값 최대 크기
// input style Object
// minKeyWordLength : 최소 검색 입력 글자 수
SearchInputBox.defaultProps = {
    maxLength: 100,
    styles: { width: 160 },
    minKeyWordLength: 2,
    watchInputKeyword: undefined,
};

export default withAdminCommonHOC(SearchInputBox, i18nResource);
