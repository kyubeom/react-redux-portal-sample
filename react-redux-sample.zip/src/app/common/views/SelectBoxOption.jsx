import React, { Component } from 'react';
import PropTypes from 'prop-types';

class SelectBoxOption extends Component {

    constructor(props) {
        super(props);
        const { option, selectedStyle } = props;
        this.option = option;
        this.selectedStyle = selectedStyle;
    }

    render() {
        return (
            <option key={this.option.value} value={this.option.value} className={this.selectedStyle}>
                {this.option.text}
            </option>
        );
    }

}

SelectBoxOption.propTypes = {
    option: PropTypes.object,
    selectedStyle: PropTypes.string,
};

SelectBoxOption.defaultProps = {
    option: {},
    selectedStyle: '',
};

export default SelectBoxOption;
