import React from 'react';
import { render } from 'react-dom';
import { Provider } from 'react-redux';
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.css'; // eslint-disable-line import/no-extraneous-dependencies

import App from './components/layout/App';
import store from './state/store';

const AdminApp = (
    <Provider store={store}>
        <App />
    </Provider>
);

render(AdminApp, document.body);
